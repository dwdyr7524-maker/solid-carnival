package com.example

import com.example.data.ai.CloudHealthCheckState
import com.example.data.ai.NexusAiErrorMapper
import com.example.data.ai.VisualDiagnosisUiState
import com.example.data.local.AutomationEntity
import com.example.data.model.AppDiagnosticInfo
import com.example.data.model.AppFilterMode
import com.example.data.model.AppSortMode
import com.example.data.model.AssistantActionType
import com.example.data.model.AutomationStepType
import com.example.data.model.BatteryTelemetry
import com.example.data.model.DeviceIdentity
import com.example.data.model.HealthSeverity
import com.example.data.model.NetworkTelemetry
import com.example.data.model.RamTelemetry
import com.example.data.model.StorageTelemetry
import com.example.data.model.SystemTelemetry
import com.example.data.system.AssistantCommandParser
import com.example.data.system.SecurityAuditor
import com.example.data.system.formatBytes
import com.example.data.system.formatUptime
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NexusPureUnitTests {

  private fun sampleTelemetry(): SystemTelemetry =
    SystemTelemetry(
      battery =
        BatteryTelemetry(
          levelPercent = 87,
          isCharging = false,
          chargeSource = "פריקה (סוללה)",
          temperatureC = 31.5f,
          voltageMv = 4120,
          healthLabel = "תקינה",
          technology = "Li-ion",
          isPowerSaveMode = false,
          isAbnormal = false,
          alertMessage = null
        ),
      ram =
        RamTelemetry(
          totalBytes = 4L * 1024L * 1024L * 1024L,
          availableBytes = 1_800_000_000L,
          usedBytes = 2_494_967_296L,
          usedPercent = 58,
          isLowMemory = false
        ),
      storage =
        StorageTelemetry(
          totalBytes = 64L * 1024L * 1024L * 1024L,
          freeBytes = 32_400_000_000L,
          usedBytes = 36_319_476_736L,
          usedPercent = 52,
          allocatableBytes = 32_400_000_000L
        ),
      network =
        NetworkTelemetry(
          isConnected = true,
          transportLabel = "Wi-Fi",
          isMetered = false,
          downstreamKbps = 120_000,
          upstreamKbps = 45_000,
          wifiRssiDbm = -52,
          wifiLinkSpeedMbps = 433
        ),
      device =
        DeviceIdentity(
          manufacturer = "Samsung",
          model = "SM-T545",
          androidRelease = "10",
          sdkInt = 29,
          securityPatch = "2022-01-01",
          uptimeMillis = 120_000L,
          isSamsungDevice = true,
          hasSamsungDeviceCare = true,
          isDeviceSecureLock = true
        ),
      healthScore = 96,
      healthStatusLabel = "מערכת יציבה ואופטימלית",
      issues = emptyList(),
      hasUsageAccessPermission = true,
      authorizedFolderCount = 1,
      capturedAtMillis = 1_000_000L
    )

  @Test
  fun formatBytes_formatsZeroKbMbGbAccurately() {
    assertEquals("0 B", formatBytes(0L))
    assertEquals("512 B", formatBytes(512L))
    assertEquals("1 KB", formatBytes(1024L))
    assertEquals("10.0 MB", formatBytes(10L * 1024L * 1024L))
    assertEquals("2.00 GB", formatBytes(2L * 1024L * 1024L * 1024L))
  }

  @Test
  fun formatUptime_formatsHebrewMinutesHoursDays() {
    assertEquals("15 דקות", formatUptime(15L * 60_000L))
    assertEquals("2 שעות, 5 דקות", formatUptime((2L * 60L + 5L) * 60_000L))
    assertEquals("1 ימים, 3 שעות", formatUptime((27L * 60L) * 60_000L))
  }

  @Test
  fun securityAuditor_flagsBackgroundLocationInstallPermissionAndMissingLock() {
    val auditor = SecurityAuditor()
    val device = sampleTelemetry().device.copy(isDeviceSecureLock = false)
    val apps =
      listOf(
        AppDiagnosticInfo(
          packageName = "com.test.tracker",
          appName = "Tracker App",
          versionName = "1.0",
          isSystemApp = false,
          apkSizeBytes = 2048L,
          appDataBytes = null,
          cacheBytes = null,
          totalSizeBytes = 2048L,
          firstInstallTime = 1L,
          lastUpdateTime = 1L,
          requestedPermissions = emptyList(),
          grantedSensitivePermissions =
            listOf(
              "android.permission.ACCESS_BACKGROUND_LOCATION",
              "android.permission.REQUEST_INSTALL_PACKAGES",
              "android.permission.CAMERA"
            ),
          hasCameraPermission = true,
          hasMicPermission = false,
          hasLocationPermission = true,
          hasBackgroundLocation = true,
          canDrawOverlays = false,
          canRequestInstalls = true
        )
      )

    val report = auditor.buildAuditReport(apps, device)
    assertFalse(report.isDeviceSecureLock)
    assertEquals(1, report.totalAppsAudited)
    assertEquals(1, report.cameraAppsCount)
    assertEquals(1, report.locationAppsCount)
    assertEquals(1, report.specialPermissionAppsCount)
    assertTrue(report.findings.any { it.severity == HealthSeverity.CRITICAL })
    assertTrue(report.findings.any { it.packageName == "com.test.tracker" })
  }

  @Test
  fun assistantCommandParser_parsesAllRequestedHebrewCommandsAndAutomations() {
    val telemetry = sampleTelemetry()

    val rStatus = AssistantCommandParser.parseAndRespond("בדוק את מצב הטאבלט שלי", telemetry, emptyList(), null, emptyList())
    assertEquals(AssistantActionType.RUN_SYSTEM_CHECK, rStatus.pendingAction?.actionType)
    assertTrue(rStatus.replyText.contains("96%"))

    val rApps = AssistantCommandParser.parseAndRespond("מצא אפליקציות שתופסות הרבה מקום", telemetry, emptyList(), null, emptyList())
    assertEquals(AssistantActionType.NAVIGATE_APPS_BY_SIZE, rApps.pendingAction?.actionType)

    val rClean = AssistantCommandParser.parseAndRespond("אני רוצה לנקות את המכשיר", telemetry, emptyList(), null, emptyList())
    assertEquals(AssistantActionType.REQUEST_START_CLEAN, rClean.pendingAction?.actionType)
    assertTrue(rClean.pendingAction!!.requiresConfirmation)

    val rBattery = AssistantCommandParser.parseAndRespond("פתח את הגדרות הסוללה", telemetry, emptyList(), null, emptyList())
    assertEquals(AssistantActionType.OPEN_BATTERY_SETTINGS, rBattery.pendingAction?.actionType)
    assertTrue(rBattery.pendingAction!!.requiresConfirmation)

    val rPerms = AssistantCommandParser.parseAndRespond("בדוק אילו הרשאות יש לאפליקציות", telemetry, emptyList(), null, emptyList())
    assertEquals(AssistantActionType.NAVIGATE_SECURITY, rPerms.pendingAction?.actionType)

    val rStorage = AssistantCommandParser.parseAndRespond("מה מצב האחסון שלי?", telemetry, emptyList(), null, emptyList())
    assertEquals(AssistantActionType.OPEN_STORAGE_SETTINGS, rStorage.pendingAction?.actionType)

    val rInternet = AssistantCommandParser.parseAndRespond("פתח את הגדרות האינטרנט", telemetry, emptyList(), null, emptyList())
    assertEquals(AssistantActionType.OPEN_INTERNET_SETTINGS, rInternet.pendingAction?.actionType)

    val customAuto =
      AutomationEntity(
        id = 42L,
        name = "בדיקת שטח",
        voicePhrase = "בדיקת שטח",
        description = "סריקה מהירה",
        stepsSerialized = "SYSTEM_SCAN",
        isBuiltIn = false
      )
    val rCustom = AssistantCommandParser.parseAndRespond("תריץ בדיקת שטח", telemetry, emptyList(), null, listOf(customAuto))
    assertEquals(AssistantActionType.RUN_AUTOMATION, rCustom.pendingAction?.actionType)
    assertEquals(42L, rCustom.pendingAction?.automationId)
  }

  @Test
  fun automationSteps_enforceConfirmationOnSensitiveSystemActions() {
    assertTrue(AutomationStepType.CLEAR_NEXUS_CACHE.requiresConfirm)
    assertTrue(AutomationStepType.OPEN_STORAGE_SETTINGS.requiresConfirm)
    assertTrue(AutomationStepType.OPEN_BATTERY_SETTINGS.requiresConfirm)
    assertTrue(AutomationStepType.OPEN_NETWORK_SETTINGS.requiresConfirm)
    assertFalse(AutomationStepType.SYSTEM_SCAN.requiresConfirm)
    assertFalse(AutomationStepType.BATTERY_CHECK.requiresConfirm)
  }

  @Test
  fun aiErrorMapper_mapsTimeoutQuotaAppCheckNetworkAndPermissionErrorsToHebrew() {
    val permErr = NexusAiErrorMapper.toHebrewError("transcribe", SecurityException("Missing RECORD_AUDIO"))
    assertTrue(permErr.messageHe.contains("RECORD_AUDIO") || permErr.messageHe.contains("הרשאת"))
    assertTrue(permErr.canRetry)

    val timeoutErr = NexusAiErrorMapper.toHebrewError("flash", IllegalStateException("Timeout waiting for response"))
    assertTrue(timeoutErr.messageHe.contains("זמן"))

    val appCheckErr = NexusAiErrorMapper.toHebrewError("live", IllegalStateException("HTTP 403 AppCheck rejected"))
    assertTrue(appCheckErr.messageHe.contains("App Check"))

    val quotaErr = NexusAiErrorMapper.toHebrewError("flash", IllegalStateException("HTTP 429 RESOURCE_EXHAUSTED"))
    assertTrue(quotaErr.messageHe.contains("מכסת"))

    val networkErr = NexusAiErrorMapper.toHebrewError("flash", IllegalStateException("Unable to resolve host"))
    assertTrue(networkErr.messageHe.contains("רשת"))
  }

  @Test
  fun assistantCommandParser_producesPlannedStepsForComplexCommands() {
    val telemetry = sampleTelemetry()
    val rClean = AssistantCommandParser.parseAndRespond("אני רוצה לנקות את המכשיר", telemetry, emptyList(), null, emptyList())
    assertTrue(rClean.plannedSteps.size >= 2)
    val rStatus = AssistantCommandParser.parseAndRespond("בדוק את מצב הטאבלט שלי", telemetry, emptyList(), null, emptyList())
    assertTrue(rStatus.plannedSteps.isNotEmpty())
  }
}

class NexusStage2ModelTests {
  @Test
  fun stage2Models_supportDormantAppsAndScheduledAutomations() {
    assertTrue(AppSortMode.entries.contains(AppSortMode.LEAST_USED))
    assertTrue(AppFilterMode.entries.contains(AppFilterMode.DORMANT))

    val auto =
      AutomationEntity(
        id = 7L,
        name = "תחזוקה לילית",
        voicePhrase = "תחזוקה לילית",
        description = "סריקה אוטומטית",
        stepsSerialized = "SYSTEM_SCAN,MAINTENANCE_REPORT",
        isBuiltIn = false,
        scheduleIntervalHours = 24
      )
    assertEquals(24, auto.scheduleIntervalHours)

    val dormantApp =
      AppDiagnosticInfo(
        packageName = "com.example.dormant",
        appName = "Dormant App",
        versionName = "1.0",
        isSystemApp = false,
        apkSizeBytes = 1024L,
        appDataBytes = null,
        cacheBytes = null,
        totalSizeBytes = 1024L,
        firstInstallTime = 1L,
        lastUpdateTime = 1L,
        requestedPermissions = emptyList(),
        grantedSensitivePermissions = emptyList(),
        hasCameraPermission = false,
        hasMicPermission = false,
        hasLocationPermission = false,
        hasBackgroundLocation = false,
        canDrawOverlays = false,
        canRequestInstalls = false,
        lastTimeUsedMillis = 1_000L,
        totalTimeInForegroundMillis = 0L,
        isDormant = true
      )
    assertTrue(dormantApp.isDormant)
    assertEquals(1_000L, dormantApp.lastTimeUsedMillis)

    val healthy =
      CloudHealthCheckState.Healthy(
        latencyMs = 140L,
        modelChecked = "gemini-3.5-flash-lite",
        summaryHe = "חיבור תקין",
        checkedAtMillis = 100L
      )
    assertEquals(140L, healthy.latencyMs)
    assertEquals(VisualDiagnosisUiState.Idle, VisualDiagnosisUiState.Idle)
  }
}
