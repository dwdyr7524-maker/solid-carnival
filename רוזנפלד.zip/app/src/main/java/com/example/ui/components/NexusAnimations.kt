package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LocalPerformanceMode
import com.example.ui.theme.NexusBorderSubtle
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusNeonCyan
import com.example.ui.theme.NexusObsidian
import com.example.ui.theme.NexusTitaniumCard
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

fun Modifier.nexusPressable(scaleDown: Float = 0.965f): Modifier = composed {
  val interactionSource = remember { MutableInteractionSource() }
  val isPressed by interactionSource.collectIsPressedAsState()
  val perfMode = LocalPerformanceMode.current
  val scale by
    animateFloatAsState(
      targetValue = if (isPressed && !perfMode) scaleDown else 1f,
      animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
      label = "press_scale"
    )
  this.graphicsLayer {
    scaleX = scale
    scaleY = scale
  }
}

@Composable
fun Nexus3DGyroLoader(
  modifier: Modifier = Modifier,
  size: Dp = 84.dp,
  active: Boolean = true,
  accentColor: Color = NexusNeonCyan
) {
  val perfMode = LocalPerformanceMode.current
  val inf = rememberInfiniteTransition(label = "gyro_3d")
  val rotY by
    inf.animateFloat(
      initialValue = 0f,
      targetValue = if (active && !perfMode) 360f else 0f,
      animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing)),
      label = "gyro_rotY"
    )
  val rotX by
    inf.animateFloat(
      initialValue = 0f,
      targetValue = if (active && !perfMode) 360f else 0f,
      animationSpec = infiniteRepeatable(tween(3400, easing = LinearEasing)),
      label = "gyro_rotX"
    )

  Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
    Canvas(
      modifier =
        Modifier.fillMaxSize().graphicsLayer {
          rotationY = rotY
          rotationX = rotX * 0.45f
          cameraDistance = 14f * density
        }
    ) {
      drawArc(
        brush = Brush.sweepGradient(listOf(Color.Transparent, accentColor, NexusElectricBlue)),
        startAngle = 0f,
        sweepAngle = 250f,
        useCenter = false,
        style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round)
      )
    }
    Canvas(
      modifier =
        Modifier.size(size * 0.72f).graphicsLayer {
          rotationY = -rotY * 1.2f
          rotationX = -rotX * 0.6f
          cameraDistance = 12f * density
        }
    ) {
      drawArc(
        brush = Brush.sweepGradient(listOf(Color.Transparent, NexusElectricBlue, accentColor)),
        startAngle = 90f,
        sweepAngle = 210f,
        useCenter = false,
        style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
      )
    }
  }
}

@Composable
fun NexusScanBeamOverlay(
  isScanning: Boolean,
  modifier: Modifier = Modifier,
  beamColor: Color = NexusNeonCyan
) {
  if (!isScanning) return
  val perfMode = LocalPerformanceMode.current
  val inf = rememberInfiniteTransition(label = "scan_beam")
  val progress by
    inf.animateFloat(
      initialValue = 0f,
      targetValue = 1f,
      animationSpec =
        infiniteRepeatable(
          animation = tween(if (perfMode) 1800 else 1250, easing = LinearEasing),
          repeatMode = RepeatMode.Reverse
        ),
      label = "beam_y"
    )

  Canvas(modifier = modifier.fillMaxSize()) {
    val y = size.height * progress
    val bandHeight = 44.dp.toPx()
    drawRect(
      brush =
        Brush.verticalGradient(
          colors = listOf(Color.Transparent, beamColor.copy(alpha = 0.22f), Color.Transparent),
          startY = y - bandHeight,
          endY = y + bandHeight
        ),
      topLeft = Offset(0f, (y - bandHeight).coerceAtLeast(0f)),
      size = androidx.compose.ui.geometry.Size(size.width, bandHeight * 2f)
    )
    drawLine(
      color = beamColor.copy(alpha = 0.9f),
      start = Offset(0f, y),
      end = Offset(size.width, y),
      strokeWidth = 2.dp.toPx()
    )
  }
}

@Composable
fun NexusCleaningEnergyOverlay(
  isCleaning: Boolean,
  modifier: Modifier = Modifier
) {
  if (!isCleaning) return
  val perfMode = LocalPerformanceMode.current
  val inf = rememberInfiniteTransition(label = "clean_energy")
  val phase by
    inf.animateFloat(
      initialValue = 0f,
      targetValue = 1f,
      animationSpec = infiniteRepeatable(tween(if (perfMode) 1800 else 1100, easing = LinearEasing)),
      label = "energy_phase"
    )

  Canvas(modifier = modifier.fillMaxSize()) {
    val cx = size.width / 2f
    val cy = size.height / 2f
    val maxR = size.minDimension * 0.48f
    val particleCount = if (perfMode) 12 else 26

    // Ascending luminous cleaning particles + shockwave ring
    drawCircle(
      color = NexusEmerald.copy(alpha = (1f - phase) * 0.55f),
      radius = maxR * phase,
      center = Offset(cx, cy),
      style = Stroke(width = 3.dp.toPx())
    )
    for (i in 0 until particleCount) {
      val angle = (i * (360f / particleCount) + phase * 180f) * (PI.toFloat() / 180f)
      val r = maxR * ((i % 4) / 4f + 0.25f) * (1f - phase * 0.4f)
      val x = cx + cos(angle) * r
      val y = cy + sin(angle) * r - phase * 30f
      drawCircle(
        color = if (i % 2 == 0) NexusNeonCyan else NexusEmerald,
        radius = if (i % 3 == 0) 4.dp.toPx() else 2.5.dp.toPx(),
        center = Offset(x, y)
      )
    }
  }
}

@Composable
fun NexusSuccessShockwave(
  visible: Boolean,
  modifier: Modifier = Modifier,
  size: Dp = 76.dp
) {
  if (!visible) return
  val anim = remember { Animatable(0f) }
  LaunchedEffect(visible) {
    anim.snapTo(0f)
    anim.animateTo(1f, tween(700, easing = FastOutSlowInEasing))
  }
  val v = anim.value
  Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      drawCircle(
        color = NexusEmerald.copy(alpha = (1f - v) * 0.7f),
        radius = (this.size.minDimension / 2f) * (0.45f + 0.55f * v),
        style = Stroke(width = 3.dp.toPx())
      )
    }
    Box(
      modifier =
        Modifier
          .size(size * 0.68f)
          .graphicsLayer {
            scaleX = 0.6f + 0.4f * v
            scaleY = 0.6f + 0.4f * v
          }
          .clip(CircleShape)
          .background(
            Brush.linearGradient(listOf(NexusEmerald, NexusNeonCyan))
          ),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = Icons.Rounded.Check,
        contentDescription = "בוצע בהצלחה",
        tint = NexusObsidian,
        modifier = Modifier.size(size * 0.4f)
      )
    }
  }
}

@Composable
fun NexusShimmerBox(
  modifier: Modifier = Modifier,
  height: Dp = 64.dp
) {
  val perfMode = LocalPerformanceMode.current
  val offset =
    if (!perfMode) {
      val inf = rememberInfiniteTransition(label = "hud_shimmer")
      val v by
        inf.animateFloat(
          initialValue = -0.3f,
          targetValue = 1.3f,
          animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing)),
          label = "shimmer_x"
        )
      v
    } else {
      0.5f
    }

  Box(
    modifier =
      modifier
        .fillMaxWidth()
        .height(height)
        .clip(RoundedCornerShape(14.dp))
        .background(
          Brush.horizontalGradient(
            colors =
              listOf(
                NexusTitaniumCard.copy(alpha = 0.5f),
                NexusNeonCyan.copy(alpha = 0.14f),
                NexusTitaniumCard.copy(alpha = 0.5f)
              ),
            startX = (offset - 0.3f) * 900f,
            endX = (offset + 0.3f) * 900f
          )
        )
        .border(1.dp, NexusBorderSubtle.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
  )
}

@Composable
fun NexusToggleSwitch(
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
  modifier: Modifier = Modifier
) {
  val trackColor by
    animateColorAsState(
      targetValue = if (checked) NexusNeonCyan.copy(alpha = 0.25f) else NexusTitaniumCard,
      label = "switch_track"
    )
  val borderColor by
    animateColorAsState(
      targetValue = if (checked) NexusNeonCyan else NexusBorderSubtle,
      label = "switch_border"
    )
  val thumbOffset by
    animateDpAsState(
      targetValue = if (checked) 22.dp else 2.dp,
      animationSpec = spring(stiffness = Spring.StiffnessMedium),
      label = "switch_thumb"
    )

  Box(
    modifier =
      modifier
        .width(52.dp)
        .height(30.dp)
        .clip(RoundedCornerShape(16.dp))
        .background(trackColor)
        .border(1.5.dp, borderColor, RoundedCornerShape(16.dp))
        .clickable { onCheckedChange(!checked) }
        .padding(2.dp),
    contentAlignment = Alignment.CenterStart
  ) {
    Box(
      modifier =
        Modifier
          .offset(x = thumbOffset)
          .size(22.dp)
          .clip(CircleShape)
          .background(if (checked) NexusNeonCyan else NexusBorderSubtle)
    )
  }
}
