package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.model.RobotMood
import com.example.ui.theme.LocalPerformanceMode
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusCharcoal
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusNeonCyan
import com.example.ui.theme.NexusObsidian
import com.example.ui.theme.NexusTitaniumElevated
import kotlin.math.sin
import kotlinx.coroutines.delay

@Composable
fun NexusRobotAvatar(
  mood: RobotMood,
  modifier: Modifier = Modifier,
  size: Dp = 128.dp
) {
  val perfMode = LocalPerformanceMode.current
  val inf = rememberInfiniteTransition(label = "robot_avatar")

  val bobOffset by
    inf.animateFloat(
      initialValue = -4f,
      targetValue = 4f,
      animationSpec =
        infiniteRepeatable(
          animation = tween(if (perfMode) 2800 else 1900, easing = FastOutSlowInEasing),
          repeatMode = RepeatMode.Reverse
        ),
      label = "robot_bob"
    )
  val pulse by
    inf.animateFloat(
      initialValue = 0.6f,
      targetValue = 1f,
      animationSpec =
        infiniteRepeatable(
          animation = tween(1400, easing = FastOutSlowInEasing),
          repeatMode = RepeatMode.Reverse
        ),
      label = "robot_pulse"
    )
  val wavePhase by
    inf.animateFloat(
      initialValue = 0f,
      targetValue = 6.283f,
      animationSpec = infiniteRepeatable(tween(800, easing = LinearEasing)),
      label = "wave_phase"
    )

  var isBlinking by remember { mutableStateOf(false) }
  LaunchedEffect(perfMode) {
    if (perfMode) return@LaunchedEffect
    while (true) {
      delay(3400)
      isBlinking = true
      delay(130)
      isBlinking = false
    }
  }

  val accentColor =
    when (mood) {
      RobotMood.ALERT -> NexusCrimson
      RobotMood.SUCCESS -> NexusEmerald
      RobotMood.LISTENING -> NexusAmber
      RobotMood.THINKING,
      RobotMood.SPEAKING,
      RobotMood.IDLE -> NexusNeonCyan
    }

  Canvas(modifier = modifier.size(size)) {
    val w = this.size.width
    val h = this.size.height
    val cx = w / 2f
    val floatY = if (perfMode) 0f else bobOffset * (h / 128.dp.toPx())

    // Holographic Pedestal at bottom
    val pedY = h * 0.87f
    drawOval(
      brush =
        Brush.radialGradient(
          colors = listOf(accentColor.copy(alpha = 0.45f * pulse), Color.Transparent),
          center = Offset(cx, pedY),
          radius = w * 0.42f
        ),
      topLeft = Offset(cx - w * 0.40f, pedY - h * 0.08f),
      size = Size(w * 0.80f, h * 0.16f)
    )
    drawOval(
      color = accentColor.copy(alpha = 0.75f * pulse),
      topLeft = Offset(cx - w * 0.30f, pedY - h * 0.045f),
      size = Size(w * 0.60f, h * 0.09f),
      style = Stroke(width = 2.dp.toPx())
    )

    // Torso / Shoulders
    val torsoTop = h * 0.61f + floatY
    val torsoW = w * 0.44f
    val torsoH = h * 0.20f
    drawRoundRect(
      brush =
        Brush.verticalGradient(
          colors = listOf(NexusTitaniumElevated, NexusCharcoal)
        ),
      topLeft = Offset(cx - torsoW / 2f, torsoTop),
      size = Size(torsoW, torsoH),
      cornerRadius = CornerRadius(w * 0.14f, w * 0.14f)
    )
    drawRoundRect(
      color = accentColor.copy(alpha = 0.55f),
      topLeft = Offset(cx - torsoW / 2f, torsoTop),
      size = Size(torsoW, torsoH),
      cornerRadius = CornerRadius(w * 0.14f, w * 0.14f),
      style = Stroke(width = 1.6.dp.toPx())
    )
    // Chest core reactor
    drawCircle(
      color = accentColor.copy(alpha = pulse),
      radius = w * 0.045f,
      center = Offset(cx, torsoTop + torsoH * 0.50f)
    )

    // Antenna
    val headTop = h * 0.19f + floatY
    drawLine(
      color = NexusTitaniumElevated,
      start = Offset(cx, headTop),
      end = Offset(cx, headTop - h * 0.09f),
      strokeWidth = 3.dp.toPx(),
      cap = StrokeCap.Round
    )
    drawCircle(
      color = accentColor.copy(alpha = pulse),
      radius = w * 0.04f,
      center = Offset(cx, headTop - h * 0.105f)
    )

    // Side ear pods
    val headW = w * 0.56f
    val headH = h * 0.40f
    val headLeft = cx - headW / 2f
    drawRoundRect(
      color = NexusElectricBlue.copy(alpha = 0.85f),
      topLeft = Offset(headLeft - w * 0.05f, headTop + headH * 0.30f),
      size = Size(w * 0.06f, headH * 0.40f),
      cornerRadius = CornerRadius(6f, 6f)
    )
    drawRoundRect(
      color = NexusElectricBlue.copy(alpha = 0.85f),
      topLeft = Offset(headLeft + headW - w * 0.01f, headTop + headH * 0.30f),
      size = Size(w * 0.06f, headH * 0.40f),
      cornerRadius = CornerRadius(6f, 6f)
    )

    // Head Shell
    drawRoundRect(
      brush =
        Brush.linearGradient(
          colors = listOf(NexusTitaniumElevated, NexusCharcoal),
          start = Offset(headLeft, headTop),
          end = Offset(headLeft + headW, headTop + headH)
        ),
      topLeft = Offset(headLeft, headTop),
      size = Size(headW, headH),
      cornerRadius = CornerRadius(w * 0.16f, w * 0.16f)
    )
    drawRoundRect(
      color = accentColor.copy(alpha = 0.7f * pulse),
      topLeft = Offset(headLeft, headTop),
      size = Size(headW, headH),
      cornerRadius = CornerRadius(w * 0.16f, w * 0.16f),
      style = Stroke(width = 1.8.dp.toPx())
    )

    // Dark Glass Visor
    val visorPadX = headW * 0.12f
    val visorPadY = headH * 0.18f
    val visorW = headW - visorPadX * 2f
    val visorH = headH * 0.64f
    drawRoundRect(
      color = NexusObsidian,
      topLeft = Offset(headLeft + visorPadX, headTop + visorPadY),
      size = Size(visorW, visorH),
      cornerRadius = CornerRadius(w * 0.10f, w * 0.10f)
    )

    // Expressive Eyes inside Visor
    val eyeY = headTop + visorPadY + visorH * 0.42f
    val leftEyeX = cx - visorW * 0.24f
    val rightEyeX = cx + visorW * 0.24f
    val eyeRadius = w * 0.055f

    if (isBlinking) {
      drawLine(
        color = accentColor,
        start = Offset(leftEyeX - eyeRadius, eyeY),
        end = Offset(leftEyeX + eyeRadius, eyeY),
        strokeWidth = 2.5.dp.toPx(),
        cap = StrokeCap.Round
      )
      drawLine(
        color = accentColor,
        start = Offset(rightEyeX - eyeRadius, eyeY),
        end = Offset(rightEyeX + eyeRadius, eyeY),
        strokeWidth = 2.5.dp.toPx(),
        cap = StrokeCap.Round
      )
    } else {
      drawCircle(color = accentColor, radius = eyeRadius, center = Offset(leftEyeX, eyeY))
      drawCircle(color = accentColor, radius = eyeRadius, center = Offset(rightEyeX, eyeY))
      drawCircle(color = Color.White, radius = eyeRadius * 0.38f, center = Offset(leftEyeX - 2f, eyeY - 2f))
      drawCircle(color = Color.White, radius = eyeRadius * 0.38f, center = Offset(rightEyeX - 2f, eyeY - 2f))
    }

    // Mouth / Audio Waveform when speaking or listening
    val mouthY = headTop + visorPadY + visorH * 0.78f
    if (mood == RobotMood.SPEAKING || mood == RobotMood.LISTENING || mood == RobotMood.THINKING) {
      val wavePath = Path()
      val mouthHalf = visorW * 0.26f
      val steps = 16
      for (i in 0..steps) {
        val t = i / steps.toFloat()
        val x = cx - mouthHalf + (mouthHalf * 2f * t)
        val amp = if (mood == RobotMood.SPEAKING) 4.dp.toPx() else 2.2.dp.toPx()
        val y = mouthY + sin(wavePhase + t * 9f) * amp
        if (i == 0) wavePath.moveTo(x, y) else wavePath.lineTo(x, y)
      }
      drawPath(
        path = wavePath,
        color = accentColor,
        style = Stroke(width = 2.2.dp.toPx(), cap = StrokeCap.Round)
      )
    } else {
      drawLine(
        color = accentColor.copy(alpha = 0.85f),
        start = Offset(cx - visorW * 0.16f, mouthY),
        end = Offset(cx + visorW * 0.16f, mouthY),
        strokeWidth = 2.dp.toPx(),
        cap = StrokeCap.Round
      )
    }
  }
}
