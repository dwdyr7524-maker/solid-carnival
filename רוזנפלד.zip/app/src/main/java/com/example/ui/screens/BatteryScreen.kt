package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.BatterySaver
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Thermostat
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.local.TelemetrySnapshotEntity
import com.example.data.model.SystemTelemetry
import com.example.ui.components.NexusHudCard
import com.example.ui.components.NexusLiveTrendChart
import com.example.ui.components.NexusMetricArcGauge
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusBorderGlow
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusNeonCyan
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BatteryScreen(
  telemetry: SystemTelemetry,
  snapshots: List<TelemetrySnapshotEntity>,
  backgroundAlertsEnabled: Boolean,
  alertIntervalMinutes: Long,
  onToggleBackgroundAlerts: (Boolean) -> Unit,
  onSelectAlertInterval: (Long) -> Unit,
  onRunBackgroundCheckNow: () -> Unit,
  onOpenBatterySettings: () -> Unit,
  onRecordSnapshotNow: () -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)

  val context = LocalContext.current
  val notificationPermissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
      if (granted) {
        onToggleBackgroundAlerts(true)
      }
    }

  val b = telemetry.battery
  val ordered = snapshots.reversed()
  val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
  val labels = ordered.map { timeFmt.format(Date(it.timestampMillis)) }
  val levelValues = ordered.map { it.batteryPercent.toFloat() }
  val tempValues = ordered.map { it.batteryTempC }

  BoxWithConstraints(modifier = modifier.fillMaxSize()) {
    val isWide = maxWidth >= 740.dp

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      if (b.isAbnormal && b.alertMessage != null) {
        item {
          NexusHudCard(isAlert = true, accentColor = NexusCrimson) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Rounded.WarningAmber, contentDescription = null, tint = NexusCrimson)
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text("התראת סוללה חריגה", style = MaterialTheme.typography.titleMedium, color = NexusCrimson)
                Text(b.alertMessage, style = MaterialTheme.typography.bodyMedium, color = NexusTextPrimary)
              }
            }
          }
        }
      }

      item {
        NexusHudCard(accentColor = if (b.isAbnormal) NexusCrimson else NexusEmerald) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("BATTERY INTELLIGENCE", style = MaterialTheme.typography.headlineMedium, color = NexusEmerald)
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = "${b.levelPercent}% • ${b.chargeSource}",
                style = MaterialTheme.typography.headlineLarge,
                color = NexusTextPrimary
              )
              Text(
                text = "טמפרטורה: ${String.format(Locale.US, "%.1f", b.temperatureC)}°C | מתח: ${b.voltageMv} mV | בריאות: ${b.healthLabel}",
                style = MaterialTheme.typography.bodyMedium,
                color = NexusTextSecondary
              )
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = "טכנולוגיה: ${b.technology} | מצב חיסכון בסוללה: ${if (b.isPowerSaveMode) "פעיל" else "כבוי"}",
                style = MaterialTheme.typography.bodyMedium,
                color = if (b.isPowerSaveMode) NexusAmber else NexusNeonCyan
              )
            }
            Spacer(modifier = Modifier.width(12.dp))
            NexusMetricArcGauge(
              percent = b.levelPercent,
              accentColor = if (b.isCharging) NexusNeonCyan else NexusEmerald,
              centerText = "${b.levelPercent}%",
              size = 96.dp
            )
          }

          Spacer(modifier = Modifier.height(14.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            Button(
              onClick = onOpenBatterySettings,
              modifier = Modifier.weight(1f).testTag("battery_open_settings"),
              colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue),
              shape = RoundedCornerShape(14.dp)
            ) {
              Icon(Icons.Rounded.BatterySaver, contentDescription = null)
              Spacer(modifier = Modifier.width(6.dp))
              Text("הגדרות וחיסכון בסוללה")
            }
            OutlinedButton(
              onClick = onRecordSnapshotNow,
              modifier = Modifier.weight(1f).testTag("battery_record_snapshot"),
              border = BorderStroke(1.dp, NexusBorderGlow.copy(alpha = 0.5f)),
              shape = RoundedCornerShape(14.dp)
            ) {
              Icon(Icons.Rounded.BatteryChargingFull, contentDescription = null, tint = NexusNeonCyan)
              Spacer(modifier = Modifier.width(6.dp))
              Text("דגום מדד כעת", color = NexusNeonCyan)
            }
          }
        }
      }

      item {
        if (isWide) {
          Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            NexusHudCard(modifier = Modifier.weight(1f)) {
              Text("מגמת אחוזי סוללה לאורך זמן", style = MaterialTheme.typography.titleMedium, color = NexusTextPrimary)
              Spacer(modifier = Modifier.height(8.dp))
              NexusLiveTrendChart(
                values = levelValues.ifEmpty { listOf(b.levelPercent.toFloat()) },
                labels = labels,
                lineColor = NexusEmerald,
                unitSuffix = "%"
              )
            }
            NexusHudCard(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Thermostat, contentDescription = null, tint = NexusAmber)
                Spacer(modifier = Modifier.width(6.dp))
                Text("מגמת טמפרטורה (°C)", style = MaterialTheme.typography.titleMedium, color = NexusTextPrimary)
              }
              Spacer(modifier = Modifier.height(8.dp))
              NexusLiveTrendChart(
                values = tempValues.ifEmpty { listOf(b.temperatureC) },
                labels = labels,
                lineColor = NexusAmber,
                unitSuffix = "°C"
              )
            }
          }
        } else {
          Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            NexusHudCard {
              Text("מגמת אחוזי סוללה לאורך זמן", style = MaterialTheme.typography.titleMedium, color = NexusTextPrimary)
              Spacer(modifier = Modifier.height(8.dp))
              NexusLiveTrendChart(
                values = levelValues.ifEmpty { listOf(b.levelPercent.toFloat()) },
                labels = labels,
                lineColor = NexusEmerald,
                unitSuffix = "%"
              )
            }
            NexusHudCard {
              Text("מגמת טמפרטורה (°C)", style = MaterialTheme.typography.titleMedium, color = NexusTextPrimary)
              Spacer(modifier = Modifier.height(8.dp))
              NexusLiveTrendChart(
                values = tempValues.ifEmpty { listOf(b.temperatureC) },
                labels = labels,
                lineColor = NexusAmber,
                unitSuffix = "°C"
              )
            }
          }
        }
      }

      item {
        NexusHudCard(accentColor = NexusNeonCyan) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
              Icon(Icons.Rounded.NotificationsActive, contentDescription = null, tint = NexusNeonCyan)
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text("ניטור רקע והתראות חום (WorkManager)", style = MaterialTheme.typography.titleMedium, color = NexusTextPrimary)
                Text(
                  "התרעה אוטומטית כשהסוללה מתחממת מעל 42°C, יורדת מתחת ל-15% או שהאחסון מלא, וכן סנכרון הווידג׳ט.",
                  style = MaterialTheme.typography.bodyMedium,
                  color = NexusTextSecondary
                )
              }
            }
            Switch(
              checked = backgroundAlertsEnabled,
              onCheckedChange = { wantEnable ->
                if (wantEnable && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                  val granted =
                    ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
                      PackageManager.PERMISSION_GRANTED
                  if (!granted) {
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    return@Switch
                  }
                }
                onToggleBackgroundAlerts(wantEnable)
              },
              colors =
                SwitchDefaults.colors(
                  checkedThumbColor = NexusNeonCyan,
                  checkedTrackColor = NexusElectricBlue.copy(alpha = 0.5f)
                )
            )
          }

          Spacer(modifier = Modifier.height(10.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            listOf(15L to "כל 15 דק׳", 30L to "כל 30 דק׳", 60L to "כל שעה").forEach { (mins, label) ->
              FilterChip(
                selected = alertIntervalMinutes == mins,
                onClick = { onSelectAlertInterval(mins) },
                label = { Text(label) },
                colors =
                  FilterChipDefaults.filterChipColors(
                    selectedContainerColor = NexusElectricBlue.copy(alpha = 0.35f),
                    selectedLabelColor = NexusNeonCyan
                  )
              )
            }
          }
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedButton(
            onClick = {
              if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
              ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
              } else {
                onRunBackgroundCheckNow()
              }
            },
            border = BorderStroke(1.dp, NexusBorderGlow.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().testTag("battery_test_worker_button")
          ) {
            Text("בצע בדיקת רקע, שלח התראת דוגמה ועדכן וידג׳ט", color = NexusNeonCyan)
          }
        }
      }

      item {
        Surface(
          color = NexusElectricBlue.copy(alpha = 0.10f),
          shape = RoundedCornerShape(14.dp),
          border = BorderStroke(1.dp, NexusElectricBlue.copy(alpha = 0.35f))
        ) {
          Text(
            text = "טיפ תחזוקה: בטאבלט Samsung Galaxy Tab Active Pro מומלץ להימנע מהפעלת עומס גרפי כבד בזמן טעינה מהירה כאשר הטמפרטורה עולה מעל 40°C.",
            style = MaterialTheme.typography.bodyMedium,
            color = NexusTextSecondary,
            modifier = Modifier.padding(14.dp)
          )
        }
      }
    }
  }
}
