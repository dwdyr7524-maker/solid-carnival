package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoMode
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.AutomationEntity
import com.example.data.model.AutomationStepType
import com.example.ui.components.NexusConfirmationDialog
import com.example.ui.components.NexusHudCard
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusBorderGlow
import com.example.ui.theme.NexusBorderSubtle
import com.example.ui.theme.NexusCharcoal
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusNeonCyan
import com.example.ui.theme.NexusObsidian
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.example.ui.theme.NexusTitaniumCard
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val scheduleOptions =
  listOf(
    0 to "ידני",
    6 to "כל 6 ש׳",
    12 to "כל 12 ש׳",
    24 to "פעם ביום",
    168 to "שבועי"
  )

private fun scheduleLabelHe(hours: Int): String =
  when (hours) {
    0 -> "ידני"
    6 -> "כל 6 שעות"
    12 -> "כל 12 שעות"
    24 -> "פעם ביום"
    168 -> "פעם בשבוע"
    else -> "כל $hours שעות"
  }

@Composable
fun AutomationScreen(
  automations: List<AutomationEntity>,
  pendingConfirmation: AutomationEntity?,
  onRequestRun: (AutomationEntity) -> Unit,
  onConfirmRun: (AutomationEntity) -> Unit,
  onDismissConfirm: () -> Unit,
  onCreateAutomation: (String, String, List<AutomationStepType>, Int) -> Unit,
  onUpdateSchedule: (AutomationEntity, Int) -> Unit,
  onDeleteCustom: (Long) -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)

  var showCreatorDialog by remember { mutableStateOf(false) }

  if (pendingConfirmation != null) {
    NexusConfirmationDialog(
      title = "אישור הפעלת אוטומציה",
      message =
        "האוטומציה \"${pendingConfirmation.name}\" כוללת פעולה רגישה או מעבר למסכי מערכת:\n${pendingConfirmation.description}",
      confirmText = "אשר והפעל",
      onConfirm = { onConfirmRun(pendingConfirmation) },
      onDismiss = onDismissConfirm
    )
  }

  if (showCreatorDialog) {
    CreateAutomationDialog(
      onSave = { name, phrase, steps, intervalHours ->
        onCreateAutomation(name, phrase, steps, intervalHours)
        showCreatorDialog = false
      },
      onDismiss = { showCreatorDialog = false }
    )
  }

  val fmt = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    item {
      NexusHudCard(accentColor = NexusNeonCyan) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text("SMART AUTOMATION", style = MaterialTheme.typography.headlineMedium, color = NexusNeonCyan)
            Text(
              text = "בנה רצפי תחזוקה, הפעל קולית או תזמן ריצה אוטומטית ברקע באמצעות WorkManager.",
              style = MaterialTheme.typography.bodyMedium,
              color = NexusTextSecondary
            )
          }
          Button(
            onClick = { showCreatorDialog = true },
            colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.testTag("create_automation_button")
          ) {
            Icon(Icons.Rounded.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("פקודה חדשה")
          }
        }
      }
    }

    items(automations, key = { it.id }) { item ->
      val hasUiSteps = item.stepsSerialized.contains("OPEN_")
      NexusHudCard(accentColor = if (item.isBuiltIn) NexusElectricBlue else NexusEmerald) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Icon(
              Icons.Rounded.AutoMode,
              contentDescription = null,
              tint = if (item.isBuiltIn) NexusNeonCyan else NexusEmerald
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(item.name, style = MaterialTheme.typography.titleMedium, color = NexusTextPrimary)
              Text("פקודה קולית: \"${item.voicePhrase}\"", style = MaterialTheme.typography.labelSmall, color = NexusNeonCyan)
              Text(item.description, style = MaterialTheme.typography.bodyMedium, color = NexusTextSecondary)
              item.lastRunMillis?.let { last ->
                Text("הופעלה לאחרונה: ${fmt.format(Date(last))}", style = MaterialTheme.typography.labelSmall, color = NexusTextSecondary)
              }
            }
          }
          Row(verticalAlignment = Alignment.CenterVertically) {
            if (!item.isBuiltIn) {
              IconButton(onClick = { onDeleteCustom(item.id) }) {
                Icon(Icons.Rounded.DeleteOutline, contentDescription = "מחק אוטומציה", tint = NexusTextSecondary)
              }
            }
            Button(
              onClick = { onRequestRun(item) },
              colors = ButtonDefaults.buttonColors(containerColor = NexusNeonCyan),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.testTag("run_automation_${item.id}")
            ) {
              Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = NexusObsidian)
              Spacer(modifier = Modifier.width(4.dp))
              Text("הפעל", color = NexusObsidian)
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            Icons.Rounded.Schedule,
            contentDescription = null,
            tint = if (item.scheduleIntervalHours > 0) NexusEmerald else NexusTextSecondary
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "תזמון רקע: ${scheduleLabelHe(item.scheduleIntervalHours)}",
            style = MaterialTheme.typography.labelLarge,
            color = if (item.scheduleIntervalHours > 0) NexusEmerald else NexusTextSecondary
          )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          scheduleOptions.forEach { (hours, label) ->
            FilterChip(
              selected = item.scheduleIntervalHours == hours,
              onClick = { onUpdateSchedule(item, hours) },
              label = { Text(label) },
              colors =
                FilterChipDefaults.filterChipColors(
                  selectedContainerColor = NexusElectricBlue.copy(alpha = 0.35f),
                  selectedLabelColor = NexusNeonCyan
                ),
              modifier = Modifier.testTag("automation_schedule_${item.id}_$hours")
            )
          }
        }
        if (item.scheduleIntervalHours > 0 && hasUiSteps) {
          Text(
            text = "הערה: בהרצה מתוזמנת ברקע שלבי פתיחת מסכי הגדרות ידולגו אוטומטית.",
            style = MaterialTheme.typography.labelSmall,
            color = NexusAmber
          )
        }
      }
    }
  }
}

@Composable
private fun CreateAutomationDialog(
  onSave: (String, String, List<AutomationStepType>, Int) -> Unit,
  onDismiss: () -> Unit
) {
  var name by remember { mutableStateOf("") }
  var phrase by remember { mutableStateOf("") }
  var selectedScheduleHours by remember { mutableIntStateOf(0) }
  val selectedSteps = remember { mutableStateListOf(AutomationStepType.SYSTEM_SCAN) }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = NexusTitaniumCard,
    shape = RoundedCornerShape(22.dp),
    title = {
      Text("יצירת רצף אוטומציה ופקודה אישית", style = MaterialTheme.typography.titleLarge, color = NexusNeonCyan)
    },
    text = {
      Column(
        modifier = Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("שם האוטומציה") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("automation_name_input"),
          colors =
            OutlinedTextFieldDefaults.colors(
              focusedBorderColor = NexusNeonCyan,
              unfocusedBorderColor = NexusBorderSubtle,
              focusedTextColor = NexusTextPrimary,
              unfocusedTextColor = NexusTextPrimary,
              focusedContainerColor = NexusCharcoal,
              unfocusedContainerColor = NexusCharcoal
            )
        )
        OutlinedTextField(
          value = phrase,
          onValueChange = { phrase = it },
          label = { Text("מילת הפעלה בעוזר החכם") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("automation_phrase_input"),
          colors =
            OutlinedTextFieldDefaults.colors(
              focusedBorderColor = NexusNeonCyan,
              unfocusedBorderColor = NexusBorderSubtle,
              focusedTextColor = NexusTextPrimary,
              unfocusedTextColor = NexusTextPrimary,
              focusedContainerColor = NexusCharcoal,
              unfocusedContainerColor = NexusCharcoal
            )
        )
        Text("תזמון אוטומטי ברקע:", style = MaterialTheme.typography.labelLarge, color = NexusTextPrimary)
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          scheduleOptions.forEach { (hours, label) ->
            FilterChip(
              selected = selectedScheduleHours == hours,
              onClick = { selectedScheduleHours = hours },
              label = { Text(label) },
              colors =
                FilterChipDefaults.filterChipColors(
                  selectedContainerColor = NexusElectricBlue.copy(alpha = 0.35f),
                  selectedLabelColor = NexusNeonCyan
                )
            )
          }
        }
        Text("בחר פעולות ברצף:", style = MaterialTheme.typography.labelLarge, color = NexusTextPrimary)
        AutomationStepType.entries.forEach { step ->
          val checked = step in selectedSteps
          Row(
            modifier =
              Modifier
                .fillMaxWidth()
                .clickable {
                  if (checked) selectedSteps.remove(step) else selectedSteps.add(step)
                },
            verticalAlignment = Alignment.CenterVertically
          ) {
            Checkbox(
              checked = checked,
              onCheckedChange = {
                if (checked) selectedSteps.remove(step) else selectedSteps.add(step)
              },
              colors = CheckboxDefaults.colors(checkedColor = NexusNeonCyan)
            )
            Text(
              text = step.titleHe + if (step.requiresConfirm) " (דורש אישור)" else "",
              style = MaterialTheme.typography.bodyMedium,
              color = NexusTextSecondary
            )
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = { onSave(name, phrase, selectedSteps.toList(), selectedScheduleHours) },
        enabled = name.isNotBlank() && selectedSteps.isNotEmpty(),
        colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue),
        modifier = Modifier.testTag("save_automation_button")
      ) {
        Text("שמור פקודה")
      }
    },
    dismissButton = {
      OutlinedButton(
        onClick = onDismiss,
        border = BorderStroke(1.dp, NexusBorderGlow.copy(alpha = 0.4f))
      ) {
        Text("ביטול", color = NexusTextSecondary)
      }
    }
  )
}
