package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NexusObsidian = Color(0xFF050810)
val NexusCharcoal = Color(0xFF0A101E)
val NexusTitaniumDark = Color(0xFF10192C)
val NexusTitaniumCard = Color(0xFF152138)
val NexusTitaniumElevated = Color(0xFF1B2B47)

val NexusElectricBlue = Color(0xFF1E90FF)
val NexusElectricDeep = Color(0xFF1164D8)
val NexusNeonCyan = Color(0xFF00E5FF)
val NexusGlowSky = Color(0xFF38BDF8)

val NexusTextPrimary = Color(0xFFF3F8FF)
val NexusTextSecondary = Color(0xFFA7B8D4)
val NexusTextMuted = Color(0xFF6B80A3)

val NexusEmerald = Color(0xFF10E89A)
val NexusAmber = Color(0xFFFFB020)
val NexusCrimson = Color(0xFFFF4D6D)

val NexusBorderSubtle = Color(0xFF233658)
val NexusBorderGlow = Color(0xFF00C2FF)
