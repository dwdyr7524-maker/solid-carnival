package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LocalPerformanceMode
import com.example.ui.theme.NexusBorderGlow
import com.example.ui.theme.NexusCharcoal
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusGlowSky
import com.example.ui.theme.NexusNeonCyan
import com.example.ui.theme.NexusObsidian
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.example.ui.theme.NexusTitaniumCard
import com.example.ui.theme.SpaceGroteskFontFamily
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.delay

@Composable
fun NexusLogoMark(
  modifier: Modifier = Modifier,
  size: Dp = 42.dp,
  animated: Boolean = true
) {
  val perfMode = LocalPerformanceMode.current
  val pulse =
    if (animated && !perfMode) {
      val inf = rememberInfiniteTransition(label = "logo_pulse")
      val v by
        inf.animateFloat(
          initialValue = 0.65f,
          targetValue = 1f,
          animationSpec =
            infiniteRepeatable(
              animation = tween(1800, easing = FastOutSlowInEasing),
              repeatMode = RepeatMode.Reverse
            ),
          label = "pulse_alpha"
        )
      v
    } else {
      0.85f
    }

  Canvas(modifier = modifier.size(size)) {
    val w = this.size.width
    val h = this.size.height
    val cx = w / 2f
    val cy = h / 2f

    // Outer hexagonal/octagonal glowing frame
    drawCircle(
      brush =
        Brush.radialGradient(
          colors = listOf(NexusNeonCyan.copy(alpha = 0.28f * pulse), Color.Transparent),
          center = Offset(cx, cy),
          radius = w * 0.65f
        )
    )

    val frame = Path().apply {
      moveTo(cx, h * 0.05f)
      lineTo(w * 0.92f, h * 0.25f)
      lineTo(w * 0.92f, h * 0.75f)
      lineTo(cx, h * 0.95f)
      lineTo(w * 0.08f, h * 0.75f)
      lineTo(w * 0.08f, h * 0.25f)
      close()
    }
    drawPath(
      path = frame,
      brush =
        Brush.linearGradient(
          colors = listOf(NexusTitaniumCard, NexusCharcoal),
          start = Offset(0f, 0f),
          end = Offset(w, h)
        )
    )
    drawPath(
      path = frame,
      brush =
        Brush.linearGradient(
          colors = listOf(NexusNeonCyan.copy(alpha = pulse), NexusElectricBlue.copy(alpha = 0.7f)),
          start = Offset(0f, 0f),
          end = Offset(w, h)
        ),
      style = Stroke(width = w * 0.05f, join = StrokeJoin.Round)
    )

    // Sculpted 3D geometric N
    val nPath = Path().apply {
      moveTo(w * 0.29f, h * 0.73f)
      lineTo(w * 0.29f, h * 0.27f)
      lineTo(w * 0.41f, h * 0.27f)
      lineTo(w * 0.60f, h * 0.56f)
      lineTo(w * 0.60f, h * 0.27f)
      lineTo(w * 0.71f, h * 0.27f)
      lineTo(w * 0.71f, h * 0.73f)
      lineTo(w * 0.59f, h * 0.73f)
      lineTo(w * 0.40f, h * 0.44f)
      lineTo(w * 0.40f, h * 0.73f)
      close()
    }
    drawPath(
      path = nPath,
      brush =
        Brush.linearGradient(
          colors = listOf(NexusNeonCyan, NexusElectricBlue, NexusGlowSky),
          start = Offset(w * 0.2f, h * 0.2f),
          end = Offset(w * 0.8f, h * 0.8f)
        )
    )
    drawPath(
      path = nPath,
      color = Color.White.copy(alpha = 0.45f * pulse),
      style = Stroke(width = w * 0.022f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )
  }
}

@Composable
fun NexusCommandHeader(
  title: String,
  deviceLabel: String,
  batteryPercent: Int,
  showBackButton: Boolean,
  performanceMode: Boolean,
  isScanning: Boolean,
  onNavigateBack: () -> Unit,
  onTogglePerformanceMode: () -> Unit,
  onRefreshTelemetry: () -> Unit,
  modifier: Modifier = Modifier
) {
  Row(
    modifier =
      modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 10.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
      if (showBackButton) {
        IconButton(
          onClick = onNavigateBack,
          modifier =
            Modifier
              .size(42.dp)
              .clip(CircleShape)
              .background(NexusTitaniumCard)
              .border(1.dp, NexusBorderGlow.copy(alpha = 0.4f), CircleShape)
              .testTag("header_back_button")
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
            contentDescription = "חזור ללוח הפיקוד",
            tint = NexusNeonCyan
          )
        }
        Spacer(modifier = Modifier.width(8.dp))
      }
      NexusLogoMark(size = 42.dp)
      Spacer(modifier = Modifier.width(12.dp))
      Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "NEXUS AI",
            style =
              MaterialTheme.typography.titleLarge.copy(
                fontFamily = SpaceGroteskFontFamily,
                fontWeight = FontWeight.Bold
              ),
            color = NexusNeonCyan
          )
          Spacer(modifier = Modifier.width(8.dp))
          Box(
            modifier =
              Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(NexusElectricBlue.copy(alpha = 0.18f))
                .border(1.dp, NexusBorderGlow.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(
              text = title,
              style = MaterialTheme.typography.labelSmall,
              color = NexusTextPrimary
            )
          }
        }
        Text(
          text = deviceLabel,
          style = MaterialTheme.typography.bodyMedium,
          color = NexusTextSecondary
        )
      }
    }

    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      Surface(
        color = NexusEmerald.copy(alpha = 0.14f),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, NexusEmerald.copy(alpha = 0.45f))
      ) {
        Text(
          text = "סוללה $batteryPercent%",
          style = MaterialTheme.typography.labelSmall,
          color = NexusEmerald,
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
        )
      }

      Surface(
        modifier =
          Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onTogglePerformanceMode)
            .testTag("performance_mode_chip"),
        color =
          if (performanceMode) NexusEmerald.copy(alpha = 0.16f)
          else NexusTitaniumCard.copy(alpha = 0.85f),
        shape = RoundedCornerShape(12.dp),
        border =
          androidx.compose.foundation.BorderStroke(
            1.dp,
            if (performanceMode) NexusEmerald.copy(alpha = 0.7f)
            else NexusBorderGlow.copy(alpha = 0.35f)
          )
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Rounded.Bolt,
            contentDescription = "מצב ביצועים",
            tint = if (performanceMode) NexusEmerald else NexusGlowSky,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = if (performanceMode) "מצב ביצועים" else "אנימציות מלא",
            style = MaterialTheme.typography.labelSmall,
            color = if (performanceMode) NexusEmerald else NexusTextPrimary
          )
        }
      }

      IconButton(
        onClick = onRefreshTelemetry,
        modifier =
          Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(NexusTitaniumCard)
            .border(1.dp, NexusBorderGlow.copy(alpha = 0.4f), CircleShape)
            .testTag("refresh_telemetry_button")
      ) {
        Icon(
          imageVector = Icons.Rounded.Refresh,
          contentDescription = "רענן נתוני מערכת",
          tint = if (isScanning) NexusEmerald else NexusNeonCyan
        )
      }
    }
  }
}

private data class LightParticle(
  val startAngle: Float,
  val startRadiusFactor: Float,
  val targetOffsetX: Float,
  val targetOffsetY: Float,
  val size: Float,
  val isCyan: Boolean
)

@Composable
fun NexusParticleSplash(
  onSplashFinished: () -> Unit,
  modifier: Modifier = Modifier
) {
  val perfMode = LocalPerformanceMode.current
  val progress = remember { Animatable(0f) }

  val particles = remember(perfMode) {
    val count = if (perfMode) 36 else 84
    List(count) { idx ->
      val angle = (idx * (360f / count)) * (PI.toFloat() / 180f)
      val radiusFactor = 0.42f + ((idx % 7) * 0.08f)
      val col = (idx % 6) / 5f - 0.5f
      val row = ((idx / 6) % 6) / 5f - 0.5f
      LightParticle(
        startAngle = angle,
        startRadiusFactor = radiusFactor,
        targetOffsetX = col * 0.24f,
        targetOffsetY = row * 0.24f,
        size = if (idx % 3 == 0) 4.5f else 2.8f,
        isCyan = idx % 2 == 0
      )
    }
  }

  LaunchedEffect(Unit) {
    progress.animateTo(
      targetValue = 1f,
      animationSpec = tween(durationMillis = if (perfMode) 1100 else 1900, easing = FastOutSlowInEasing)
    )
    delay(350)
    onSplashFinished()
  }

  val p = progress.value

  Box(
    modifier =
      modifier
        .fillMaxSize()
        .background(
          Brush.radialGradient(
            colors = listOf(Color(0xFF0A1B36), NexusObsidian),
            radius = 900f
          )
        )
        .clickable(onClick = onSplashFinished)
        .testTag("nexus_splash_screen"),
    contentAlignment = Alignment.Center
  ) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val cx = size.width / 2f
      val cy = size.height / 2f - 40f
      val maxDist = size.minDimension * 0.55f

      // Converging light particles forming the NEXUS core
      val converge = (1f - p).coerceIn(0f, 1f)
      particles.forEach { pt ->
        val currentR = maxDist * pt.startRadiusFactor * converge
        val swirl = pt.startAngle + (1f - converge) * 1.4f
        val x = cx + cos(swirl) * currentR + pt.targetOffsetX * size.minDimension * (1f - converge)
        val y = cy + sin(swirl) * currentR + pt.targetOffsetY * size.minDimension * (1f - converge)
        val color = if (pt.isCyan) NexusNeonCyan else NexusElectricBlue
        drawCircle(
          color = color.copy(alpha = (0.35f + 0.65f * p).coerceIn(0f, 1f)),
          radius = pt.size * (0.7f + 0.8f * (1f - converge)),
          center = Offset(x, y)
        )
      }

      // Expanding core energy shockwave when particles lock in
      if (p > 0.65f) {
        val burst = ((p - 0.65f) / 0.35f).coerceIn(0f, 1f)
        drawCircle(
          color = NexusNeonCyan.copy(alpha = (1f - burst) * 0.55f),
          radius = size.minDimension * 0.14f + burst * size.minDimension * 0.25f,
          center = Offset(cx, cy),
          style = Stroke(width = 3f)
        )
      }
    }

    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Box(contentAlignment = Alignment.Center) {
        Nexus3DGyroLoader(size = 160.dp, active = p < 0.98f)
        Box(
          modifier = Modifier.size((90 * p.coerceAtLeast(0.15f)).dp),
          contentAlignment = Alignment.Center
        ) {
          NexusLogoMark(size = 86.dp, animated = false)
        }
      }
      Spacer(modifier = Modifier.height(22.dp))
      Text(
        text = "NEXUS AI",
        style =
          MaterialTheme.typography.displayMedium.copy(
            fontFamily = SpaceGroteskFontFamily,
            fontWeight = FontWeight.Bold
          ),
        color = NexusTextPrimary.copy(alpha = p.coerceIn(0.2f, 1f))
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = "ULTIMATE DEVICE COMMAND CENTER",
        style = MaterialTheme.typography.labelMedium,
        color = NexusNeonCyan.copy(alpha = p.coerceIn(0.2f, 1f))
      )
      Spacer(modifier = Modifier.height(14.dp))
      Text(
        text = "טוען טלמטריית מערכת בזמן אמת...",
        style = MaterialTheme.typography.bodyMedium,
        color = NexusTextSecondary.copy(alpha = p)
      )
    }
  }
}
