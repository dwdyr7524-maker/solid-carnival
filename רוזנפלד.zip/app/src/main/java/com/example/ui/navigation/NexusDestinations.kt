package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Assessment
import androidx.compose.material.icons.rounded.AutoMode
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.ui.graphics.vector.ImageVector

enum class NexusDestination(
  val route: String,
  val labelHe: String,
  val shortLabelHe: String,
  val icon: ImageVector
) {
  DASHBOARD("dashboard", "לוח פיקוד מרכזי", "פיקוד", Icons.Rounded.Dashboard),
  DEEP_CLEAN("deep_clean", "NEXUS Deep Clean", "ניקוי", Icons.Rounded.CleaningServices),
  ASSISTANT("assistant", "עוזר אישי חכם", "עוזר", Icons.Rounded.SmartToy),
  SYSTEM_CONTROL("system_control", "מרכז שליטה", "שליטה", Icons.Rounded.Tune),
  BATTERY("battery", "מרכז סוללה", "סוללה", Icons.Rounded.BatteryChargingFull),
  APPS("apps", "אפליקציות ונפח", "אפליקציות", Icons.Rounded.Memory),
  SECURITY("security", "מרכז אבטחה", "אבטחה", Icons.Rounded.Security),
  AUTOMATION("automation", "אוטומציות חכמות", "אוטומציה", Icons.Rounded.AutoMode),
  REPORTS("reports", "דוחות וניתוח", "דוחות", Icons.Rounded.Assessment)
}
