package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.PrivacyTip
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.ai.CloudHealthCheckState
import com.example.data.model.HealthSeverity
import com.example.data.model.SecurityAuditReport
import com.example.ui.components.NexusConfirmationDialog
import com.example.ui.components.NexusHudCard
import com.example.ui.components.NexusShimmerBox
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusBorderGlow
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusGlowSky
import com.example.ui.theme.NexusNeonCyan
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary

@Composable
fun SecurityScreen(
  report: SecurityAuditReport?,
  cloudAiEnabled: Boolean,
  shareTelemetryWithAi: Boolean,
  cloudHealthCheckState: CloudHealthCheckState,
  onToggleCloudAi: () -> Unit,
  onToggleShareTelemetryWithAi: () -> Unit,
  onRunCloudHealthCheck: () -> Unit,
  onDeleteAllUserData: () -> Unit,
  onRefreshAudit: () -> Unit,
  onOpenPrivacySettings: () -> Unit,
  onOpenAppPermissions: (String, String) -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)

  var showDeleteDataDialog by remember { mutableStateOf(false) }

  if (showDeleteDataDialog) {
    NexusConfirmationDialog(
      title = "מחיקת כל הנתונים האישיים",
      message =
        "פעולה זו תמחק לצמיתות את היסטוריית הצ'אט, האוטומציות שיצרת, יומני הניקוי והגדרות המשתמש מתוך NEXUS. האם להמשיך?",
      confirmText = "מחק הכל",
      isDestructive = true,
      onConfirm = {
        showDeleteDataDialog = false
        onDeleteAllUserData()
      },
      onDismiss = { showDeleteDataDialog = false }
    )
  }

  BoxWithConstraints(modifier = modifier.fillMaxSize()) {
    val isWide = maxWidth >= 740.dp

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      item {
        NexusHudCard(accentColor = NexusNeonCyan) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("SECURITY & PERMISSION CENTER", style = MaterialTheme.typography.headlineMedium, color = NexusNeonCyan)
              Text(
                text = "ביקורת הרשאות אמיתית לפי נתוני מערכת Android — ללא סריקת וירוסים מדומה.",
                style = MaterialTheme.typography.bodyMedium,
                color = NexusTextSecondary
              )
            }
            Icon(Icons.Rounded.Security, contentDescription = null, tint = NexusNeonCyan)
          }
          Spacer(modifier = Modifier.height(12.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            Button(
              onClick = onOpenPrivacySettings,
              modifier = Modifier.weight(1f).testTag("security_open_privacy"),
              colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue),
              shape = RoundedCornerShape(14.dp)
            ) {
              Text("נהל הרשאות במערכת")
            }
            OutlinedButton(
              onClick = onRefreshAudit,
              modifier = Modifier.weight(1f).testTag("security_refresh_audit"),
              border = BorderStroke(1.dp, NexusBorderGlow.copy(alpha = 0.5f)),
              shape = RoundedCornerShape(14.dp)
            ) {
              Text("בצע ביקורת חוזרת", color = NexusNeonCyan)
            }
          }
        }
      }

      item {
        NexusHudCard(accentColor = NexusGlowSky) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.PrivacyTip, contentDescription = null, tint = NexusGlowSky)
            Spacer(modifier = Modifier.width(8.dp))
            Text("בקרת פרטיות ושמירת נתונים", style = MaterialTheme.typography.titleLarge, color = NexusTextPrimary)
          }
          Spacer(modifier = Modifier.height(10.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("שירותי בינה מלאכותית בענן (Firebase AI)", style = MaterialTheme.typography.titleMedium, color = NexusTextPrimary)
              Text("מאפשר עיבוד שפה טבעית, תמלול ושיחה קולית חיה. כיבוי יפעיל מנוע מקומי בלבד.", style = MaterialTheme.typography.bodyMedium, color = NexusTextSecondary)
            }
            Switch(
              checked = cloudAiEnabled,
              onCheckedChange = { onToggleCloudAi() },
              colors = SwitchDefaults.colors(checkedThumbColor = NexusNeonCyan, checkedTrackColor = NexusElectricBlue.copy(alpha = 0.5f))
            )
          }
          Spacer(modifier = Modifier.height(8.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("שיתוף מדדי מכשיר בהקשר העוזר", style = MaterialTheme.typography.titleMedium, color = NexusTextPrimary)
              Text("מצרף אחוז סוללה, אחסון ו-RAM לתשובות מדויקות; ללא שיתוף מידע אישי.", style = MaterialTheme.typography.bodyMedium, color = NexusTextSecondary)
            }
            Switch(
              checked = shareTelemetryWithAi,
              onCheckedChange = { onToggleShareTelemetryWithAi() },
              colors = SwitchDefaults.colors(checkedThumbColor = NexusNeonCyan, checkedTrackColor = NexusElectricBlue.copy(alpha = 0.5f))
            )
          }
          Spacer(modifier = Modifier.height(10.dp))
          OutlinedButton(
            onClick = onRunCloudHealthCheck,
            enabled = cloudHealthCheckState !is CloudHealthCheckState.Checking,
            border = BorderStroke(1.dp, NexusNeonCyan.copy(alpha = 0.65f)),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().testTag("security_cloud_health_check")
          ) {
            if (cloudHealthCheckState is CloudHealthCheckState.Checking) {
              CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = NexusNeonCyan)
              Spacer(modifier = Modifier.width(8.dp))
              Text("בודק חיבור Gemini Cloud ו-App Check...", color = NexusNeonCyan)
            } else {
              Icon(Icons.Rounded.CloudDone, contentDescription = null, tint = NexusNeonCyan)
              Spacer(modifier = Modifier.width(6.dp))
              Text("בדיקת תקינות ענן AI ו-App Check", color = NexusNeonCyan)
            }
          }
          when (cloudHealthCheckState) {
            CloudHealthCheckState.Idle -> Unit
            CloudHealthCheckState.Checking -> Unit
            is CloudHealthCheckState.Healthy -> {
              Spacer(modifier = Modifier.height(8.dp))
              Surface(
                color = NexusEmerald.copy(alpha = 0.14f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, NexusEmerald.copy(alpha = 0.55f)),
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier.padding(10.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = NexusEmerald)
                  Spacer(modifier = Modifier.width(8.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = "תקין (${cloudHealthCheckState.modelChecked} • ${cloudHealthCheckState.latencyMs} מ״ש)",
                      style = MaterialTheme.typography.titleSmall,
                      color = NexusEmerald
                    )
                    Text(
                      text = cloudHealthCheckState.summaryHe,
                      style = MaterialTheme.typography.bodyMedium,
                      color = NexusTextPrimary
                    )
                  }
                }
              }
            }
            is CloudHealthCheckState.Unhealthy -> {
              Spacer(modifier = Modifier.height(8.dp))
              Surface(
                color = NexusCrimson.copy(alpha = 0.14f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, NexusCrimson.copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier.padding(10.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(Icons.Rounded.ErrorOutline, contentDescription = null, tint = NexusCrimson)
                  Spacer(modifier = Modifier.width(8.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = "בדיקת ענן נכשלה (${cloudHealthCheckState.latencyMs} מ״ש)",
                      style = MaterialTheme.typography.titleSmall,
                      color = NexusCrimson
                    )
                    Text(
                      text = cloudHealthCheckState.error.messageHe,
                      style = MaterialTheme.typography.bodyMedium,
                      color = NexusTextPrimary
                    )
                  }
                }
              }
            }
          }
          Spacer(modifier = Modifier.height(10.dp))
          OutlinedButton(
            onClick = { showDeleteDataDialog = true },
            border = BorderStroke(1.dp, NexusCrimson.copy(alpha = 0.65f)),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().testTag("security_delete_all_data")
          ) {
            Icon(Icons.Rounded.DeleteForever, contentDescription = null, tint = NexusCrimson)
            Spacer(modifier = Modifier.width(6.dp))
            Text("מחק את כל הנתונים האישיים של NEXUS", color = NexusCrimson)
          }
        }
      }

      if (report == null) {
        items(4) { NexusShimmerBox(height = 76.dp) }
      } else {
        item {
          if (isWide) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
              PermSummaryTile("מצלמה", report.cameraAppsCount, Icons.Rounded.CameraAlt, NexusNeonCyan, Modifier.weight(1f))
              PermSummaryTile("מיקרופון", report.micAppsCount, Icons.Rounded.Mic, NexusGlowSky, Modifier.weight(1f))
              PermSummaryTile("מיקום", report.locationAppsCount, Icons.Rounded.LocationOn, NexusAmber, Modifier.weight(1f))
              PermSummaryTile("הרשאות מיוחדות", report.specialPermissionAppsCount, Icons.Rounded.Shield, NexusCrimson, Modifier.weight(1f))
            }
          } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PermSummaryTile("מצלמה", report.cameraAppsCount, Icons.Rounded.CameraAlt, NexusNeonCyan, Modifier.weight(1f))
                PermSummaryTile("מיקרופון", report.micAppsCount, Icons.Rounded.Mic, NexusGlowSky, Modifier.weight(1f))
              }
              Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PermSummaryTile("מיקום", report.locationAppsCount, Icons.Rounded.LocationOn, NexusAmber, Modifier.weight(1f))
                PermSummaryTile("הרשאות מיוחדות", report.specialPermissionAppsCount, Icons.Rounded.Shield, NexusCrimson, Modifier.weight(1f))
              }
            }
          }
        }

        item {
          Text("ממצאים והתראות אבטחה (${report.findings.size})", style = MaterialTheme.typography.titleLarge, color = NexusTextPrimary)
        }

        items(report.findings, key = { it.id }) { finding ->
          val color =
            when (finding.severity) {
              HealthSeverity.CRITICAL -> NexusCrimson
              HealthSeverity.WARNING -> NexusAmber
              HealthSeverity.NOTICE -> NexusGlowSky
              HealthSeverity.OPTIMAL -> NexusEmerald
            }
          NexusHudCard(
            isAlert = finding.severity == HealthSeverity.CRITICAL || finding.severity == HealthSeverity.WARNING,
            accentColor = color,
            contentPadding = 12.dp
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Rounded.WarningAmber, contentDescription = null, tint = color)
              Spacer(modifier = Modifier.width(10.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(finding.title, style = MaterialTheme.typography.titleMedium, color = NexusTextPrimary)
                Text(finding.description, style = MaterialTheme.typography.bodyMedium, color = NexusTextSecondary)
              }
              if (finding.packageName != null) {
                OutlinedButton(
                  onClick = { onOpenAppPermissions(finding.packageName, finding.appName ?: finding.packageName) },
                  border = BorderStroke(1.dp, color.copy(alpha = 0.6f))
                ) {
                  Text("ניהול", color = color)
                }
              }
            }
          }
        }

        item {
          Text("אפליקציות עם הרשאות רגישות (${report.sensitiveApps.size})", style = MaterialTheme.typography.titleLarge, color = NexusTextPrimary)
        }

        items(report.sensitiveApps.take(25), key = { it.packageName }) { app ->
          Surface(
            color = NexusElectricBlue.copy(alpha = 0.07f),
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, NexusBorderGlow.copy(alpha = 0.25f))
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(12.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(app.appName, style = MaterialTheme.typography.titleMedium, color = NexusTextPrimary)
                val tags =
                  buildList {
                    if (app.hasCameraPermission) add("מצלמה")
                    if (app.hasMicPermission) add("מיקרופון")
                    if (app.hasLocationPermission) add("מיקום")
                    if (app.hasBackgroundLocation) add("מיקום ברקע")
                    if (app.canDrawOverlays) add("שכבת על")
                    if (app.canRequestInstalls) add("התקנת חבילות")
                  }
                Text(tags.joinToString(" • "), style = MaterialTheme.typography.bodyMedium, color = NexusTextSecondary)
              }
              OutlinedButton(
                onClick = { onOpenAppPermissions(app.packageName, app.appName) },
                border = BorderStroke(1.dp, NexusBorderGlow.copy(alpha = 0.5f))
              ) {
                Text("הרשאות", color = NexusNeonCyan)
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun PermSummaryTile(
  label: String,
  count: Int,
  icon: ImageVector,
  accent: Color,
  modifier: Modifier = Modifier
) {
  NexusHudCard(modifier = modifier, accentColor = accent, contentPadding = 12.dp) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(icon, contentDescription = label, tint = accent)
      Spacer(modifier = Modifier.width(8.dp))
      Column {
        Text(text = "$count", style = MaterialTheme.typography.headlineMedium, color = NexusTextPrimary)
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = NexusTextSecondary)
      }
    }
  }
}
