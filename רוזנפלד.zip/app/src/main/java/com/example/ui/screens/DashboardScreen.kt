package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoMode
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.ActionAuditEntity
import com.example.data.local.CleanHistoryEntity
import com.example.data.model.HealthSeverity
import com.example.data.model.RobotMood
import com.example.data.model.SystemTelemetry
import com.example.data.system.formatBytes
import com.example.data.system.formatUptime
import com.example.ui.components.NexusHudCard
import com.example.ui.components.NexusMetricArcGauge
import com.example.ui.components.NexusRobotAvatar
import com.example.ui.components.NexusScanBeamOverlay
import com.example.ui.components.NexusSystemHealthRing
import com.example.ui.components.nexusPressable
import com.example.ui.navigation.NexusDestination
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusBorderGlow
import com.example.ui.theme.NexusBorderSubtle
import com.example.ui.theme.NexusCharcoal
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusGlowSky
import com.example.ui.theme.NexusNeonCyan
import com.example.ui.theme.NexusObsidian
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.example.ui.theme.NexusTitaniumElevated
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
  telemetry: SystemTelemetry,
  isRefreshing: Boolean,
  lastMaintenanceMillis: Long?,
  recentCleanHistory: List<CleanHistoryEntity>,
  recentAuditLogs: List<ActionAuditEntity>,
  onRefreshTelemetry: () -> Unit,
  onNavigate: (String) -> Unit,
  onQuickCleanLaunch: () -> Unit,
  onAssistantQuickCommand: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  BoxWithConstraints(modifier = modifier.fillMaxSize()) {
    val isTabletWide = maxWidth >= 760.dp

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Glowing Command Center Status Ribbon
      item {
        Surface(
          color = NexusElectricBlue.copy(alpha = 0.12f),
          shape = RoundedCornerShape(14.dp),
          border = BorderStroke(1.dp, NexusBorderGlow.copy(alpha = 0.45f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "שליטה חכמה • ביצועים מקסימליים • חוויית שימוש מושלמת",
              style = MaterialTheme.typography.labelLarge,
              color = NexusNeonCyan
            )
            Text(
              text = "Android ${telemetry.device.androidRelease} • API ${telemetry.device.sdkInt}",
              style = MaterialTheme.typography.labelSmall,
              color = NexusTextSecondary
            )
          }
        }
      }

      // Top Hero Command Strip (Tablet: 2-column HUD Health Core + Robot Assistant & Clean CTA)
      item {
        if (isTabletWide) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
          ) {
            HeroHealthCoreCard(
              telemetry = telemetry,
              isRefreshing = isRefreshing,
              onRefreshTelemetry = onRefreshTelemetry,
              onQuickCleanLaunch = onQuickCleanLaunch,
              modifier = Modifier.weight(1.15f)
            )
            HeroAssistantDockCard(
              telemetry = telemetry,
              lastMaintenanceMillis = lastMaintenanceMillis,
              onOpenAssistant = { onNavigate(NexusDestination.ASSISTANT.route) },
              onOpenControl = { onNavigate(NexusDestination.SYSTEM_CONTROL.route) },
              onQuickCommand = onAssistantQuickCommand,
              modifier = Modifier.weight(0.85f)
            )
          }
        } else {
          Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            HeroHealthCoreCard(
              telemetry = telemetry,
              isRefreshing = isRefreshing,
              onRefreshTelemetry = onRefreshTelemetry,
              onQuickCleanLaunch = onQuickCleanLaunch
            )
            HeroAssistantDockCard(
              telemetry = telemetry,
              lastMaintenanceMillis = lastMaintenanceMillis,
              onOpenAssistant = { onNavigate(NexusDestination.ASSISTANT.route) },
              onOpenControl = { onNavigate(NexusDestination.SYSTEM_CONTROL.route) },
              onQuickCommand = onAssistantQuickCommand
            )
          }
        }
      }

      // Live Telemetry Bento Grid: Battery, Storage, RAM, Network
      item {
        val batteryAlert = telemetry.battery.isAbnormal || telemetry.battery.levelPercent <= 15
        val storageAlert = telemetry.storage.usedPercent >= 85
        val ramAlert = telemetry.ram.isLowMemory || telemetry.ram.usedPercent >= 88

        if (isTabletWide) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
          ) {
            TelemetryMiniCard(
              title = "סוללה ואנרגיה",
              mainValue = "${telemetry.battery.levelPercent}%",
              subValue = "${telemetry.battery.chargeSource} • ${String.format(Locale.US, "%.1f", telemetry.battery.temperatureC)}°C",
              percent = telemetry.battery.levelPercent,
              accent = if (batteryAlert) NexusCrimson else NexusEmerald,
              icon = Icons.Rounded.BatteryChargingFull,
              isAlert = batteryAlert,
              onClick = { onNavigate(NexusDestination.BATTERY.route) },
              modifier = Modifier.weight(1f).testTag("card_battery")
            )
            TelemetryMiniCard(
              title = "אחסון פנימי",
              mainValue = formatBytes(telemetry.storage.freeBytes),
              subValue = "פנוי מתוך ${formatBytes(telemetry.storage.totalBytes)}",
              percent = telemetry.storage.usedPercent,
              accent = if (storageAlert) NexusAmber else NexusNeonCyan,
              icon = Icons.Rounded.Storage,
              isAlert = storageAlert,
              onClick = { onNavigate(NexusDestination.DEEP_CLEAN.route) },
              modifier = Modifier.weight(1f).testTag("card_storage")
            )
            TelemetryMiniCard(
              title = "זיכרון RAM",
              mainValue = "${telemetry.ram.usedPercent}%",
              subValue = "זמין: ${formatBytes(telemetry.ram.availableBytes)}",
              percent = telemetry.ram.usedPercent,
              accent = if (ramAlert) NexusAmber else NexusElectricBlue,
              icon = Icons.Rounded.Memory,
              isAlert = ramAlert,
              onClick = { onNavigate(NexusDestination.APPS.route) },
              modifier = Modifier.weight(1f).testTag("card_ram")
            )
            TelemetryMiniCard(
              title = "מצב רשת",
              mainValue = telemetry.network.transportLabel,
              subValue =
                if (telemetry.network.isConnected) {
                  telemetry.network.wifiLinkSpeedMbps?.let { "$it Mbps" }
                    ?: if (telemetry.network.isMetered) "חיבור מדוד" else "חיבור תקין"
                } else "ללא חיבור רשת",
              percent = if (telemetry.network.isConnected) 100 else 0,
              accent = if (telemetry.network.isConnected) NexusGlowSky else NexusCrimson,
              icon = Icons.Rounded.Wifi,
              isAlert = !telemetry.network.isConnected,
              onClick = { onNavigate(NexusDestination.SYSTEM_CONTROL.route) },
              modifier = Modifier.weight(1f).testTag("card_network")
            )
          }
        } else {
          Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
              TelemetryMiniCard(
                title = "סוללה",
                mainValue = "${telemetry.battery.levelPercent}%",
                subValue = "${String.format(Locale.US, "%.1f", telemetry.battery.temperatureC)}°C • ${telemetry.battery.chargeSource}",
                percent = telemetry.battery.levelPercent,
                accent = if (batteryAlert) NexusCrimson else NexusEmerald,
                icon = Icons.Rounded.BatteryChargingFull,
                isAlert = batteryAlert,
                onClick = { onNavigate(NexusDestination.BATTERY.route) },
                modifier = Modifier.weight(1f).testTag("card_battery")
              )
              TelemetryMiniCard(
                title = "אחסון פנוי",
                mainValue = formatBytes(telemetry.storage.freeBytes),
                subValue = "${telemetry.storage.usedPercent}% בשימוש",
                percent = telemetry.storage.usedPercent,
                accent = if (storageAlert) NexusAmber else NexusNeonCyan,
                icon = Icons.Rounded.Storage,
                isAlert = storageAlert,
                onClick = { onNavigate(NexusDestination.DEEP_CLEAN.route) },
                modifier = Modifier.weight(1f).testTag("card_storage")
              )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
              TelemetryMiniCard(
                title = "זיכרון RAM",
                mainValue = "${telemetry.ram.usedPercent}%",
                subValue = "פנוי: ${formatBytes(telemetry.ram.availableBytes)}",
                percent = telemetry.ram.usedPercent,
                accent = if (ramAlert) NexusAmber else NexusElectricBlue,
                icon = Icons.Rounded.Memory,
                isAlert = ramAlert,
                onClick = { onNavigate(NexusDestination.APPS.route) },
                modifier = Modifier.weight(1f).testTag("card_ram")
              )
              TelemetryMiniCard(
                title = "רשת",
                mainValue = telemetry.network.transportLabel,
                subValue = if (telemetry.network.isConnected) "מחובר" else "לא מחובר",
                percent = if (telemetry.network.isConnected) 100 else 0,
                accent = if (telemetry.network.isConnected) NexusGlowSky else NexusCrimson,
                icon = Icons.Rounded.Wifi,
                isAlert = !telemetry.network.isConnected,
                onClick = { onNavigate(NexusDestination.SYSTEM_CONTROL.route) },
                modifier = Modifier.weight(1f).testTag("card_network")
              )
            }
          }
        }
      }

      // Module Shortcut Hub Cards
      item {
        Text(
          text = "מערכות ניהול ואבחון",
          style = MaterialTheme.typography.titleLarge,
          color = NexusTextPrimary
        )
        Spacer(modifier = Modifier.height(10.dp))
        val modules =
          listOf(
            Triple(NexusDestination.DEEP_CLEAN, "סריקת אחסון, מטמון וקבצים כפולים", Icons.Rounded.CleaningServices),
            Triple(NexusDestination.SYSTEM_CONTROL, "12+ קיצורי דרך רשמיים ל-Android 10", Icons.Rounded.Tune),
            Triple(NexusDestination.APPS, "ניהול יישומים, נפח אחסון והרשאות", Icons.Rounded.Memory),
            Triple(NexusDestination.SECURITY, "ביקורת מצלמה, מיקרופון, מיקום ונעילה", Icons.Rounded.Security),
            Triple(NexusDestination.AUTOMATION, "רצפי פעולות חכמים ופקודות אישיות", Icons.Rounded.AutoMode),
            Triple(NexusDestination.REPORTS, "היסטוריית ניקויים וייצוא דוחות", Icons.Rounded.Storage)
          )

        if (isTabletWide) {
          Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            modules.chunked(3).forEach { rowItems ->
              Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                rowItems.forEach { (dest, desc, icon) ->
                  ModuleLaunchCard(
                    destination = dest,
                    description = desc,
                    icon = icon,
                    onClick = { onNavigate(dest.route) },
                    modifier = Modifier.weight(1f)
                  )
                }
              }
            }
          }
        } else {
          Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            modules.chunked(2).forEach { rowItems ->
              Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                rowItems.forEach { (dest, desc, icon) ->
                  ModuleLaunchCard(
                    destination = dest,
                    description = desc,
                    icon = icon,
                    onClick = { onNavigate(dest.route) },
                    modifier = Modifier.weight(1f)
                  )
                }
              }
            }
          }
        }
      }

      // System Info, Important Alerts & Recent Activity
      item {
        if (isTabletWide) {
          Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            ImportantAlertsCard(
              telemetry = telemetry,
              onNavigate = onNavigate,
              modifier = Modifier.weight(1f)
            )
            SystemAndActivityCard(
              telemetry = telemetry,
              recentCleanHistory = recentCleanHistory,
              recentAuditLogs = recentAuditLogs,
              onOpenReports = { onNavigate(NexusDestination.REPORTS.route) },
              modifier = Modifier.weight(1f)
            )
          }
        } else {
          Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            ImportantAlertsCard(telemetry = telemetry, onNavigate = onNavigate)
            SystemAndActivityCard(
              telemetry = telemetry,
              recentCleanHistory = recentCleanHistory,
              recentAuditLogs = recentAuditLogs,
              onOpenReports = { onNavigate(NexusDestination.REPORTS.route) }
            )
          }
        }
      }
    }
  }
}

@Composable
private fun HeroHealthCoreCard(
  telemetry: SystemTelemetry,
  isRefreshing: Boolean,
  onRefreshTelemetry: () -> Unit,
  onQuickCleanLaunch: () -> Unit,
  modifier: Modifier = Modifier
) {
  NexusHudCard(modifier = modifier, accentColor = NexusNeonCyan) {
    Box(modifier = Modifier.fillMaxWidth()) {
      NexusScanBeamOverlay(isScanning = isRefreshing)
      Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "ליבת מצב המערכת",
              style = MaterialTheme.typography.titleLarge,
              color = NexusNeonCyan
            )
            Text(
              text = "${telemetry.device.manufacturer} ${telemetry.device.model} • Android ${telemetry.device.androidRelease}",
              style = MaterialTheme.typography.bodyMedium,
              color = NexusTextSecondary
            )
          }
          Surface(
            color = NexusEmerald.copy(alpha = 0.14f),
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, NexusEmerald.copy(alpha = 0.4f))
          ) {
            Text(
              text = "זמן פעילות: ${formatUptime(telemetry.device.uptimeMillis)}",
              style = MaterialTheme.typography.labelSmall,
              color = NexusEmerald,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        NexusSystemHealthRing(
          score = telemetry.healthScore,
          statusLabel = telemetry.healthStatusLabel,
          isScanning = isRefreshing,
          onClick = onRefreshTelemetry,
          ringSize = 216.dp
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
          onClick = onQuickCleanLaunch,
          modifier =
            Modifier
              .fillMaxWidth()
              .height(54.dp)
              .nexusPressable()
              .testTag("dashboard_clean_all_button"),
          shape = RoundedCornerShape(16.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
          contentPadding = PaddingValues(0.dp)
        ) {
          Box(
            modifier =
              Modifier
                .fillMaxSize()
                .background(
                  Brush.horizontalGradient(listOf(NexusElectricBlue, NexusNeonCyan))
                ),
            contentAlignment = Alignment.Center
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Rounded.CleaningServices,
                contentDescription = "ניקוי מערכת",
                tint = NexusObsidian
              )
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = "CLEAN ALL — ניקוי מערכת",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = NexusObsidian
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun HeroAssistantDockCard(
  telemetry: SystemTelemetry,
  lastMaintenanceMillis: Long?,
  onOpenAssistant: () -> Unit,
  onOpenControl: () -> Unit,
  onQuickCommand: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val fmt = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
  val maintenanceText =
    lastMaintenanceMillis?.let { "תחזוקה אחרונה: ${fmt.format(Date(it))}" }
      ?: "טרם בוצעה תחזוקה יזומה"

  NexusHudCard(modifier = modifier, accentColor = NexusElectricBlue) {
    Column(
      modifier = Modifier.fillMaxWidth(),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        NexusRobotAvatar(
          mood = if (telemetry.issues.any { it.severity == HealthSeverity.CRITICAL }) RobotMood.ALERT else RobotMood.IDLE,
          size = 104.dp
        )
        Spacer(modifier = Modifier.width(12.dp))
        Surface(
          color = NexusTitaniumElevated.copy(alpha = 0.9f),
          shape = RoundedCornerShape(14.dp),
          border = BorderStroke(1.dp, NexusBorderGlow.copy(alpha = 0.45f)),
          modifier = Modifier.weight(1f)
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Text(
              text = "שלום! איך אפשר לעזור לך היום?",
              style = MaterialTheme.typography.titleMedium,
              color = NexusNeonCyan
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
              text =
                if (telemetry.issues.isEmpty()) "כל המערכות תקינות! בחר פעולה מהירה או דבר איתי."
                else "זיהיתי ${telemetry.issues.size} נושאים לבדיקה.",
              style = MaterialTheme.typography.bodyMedium,
              color = NexusTextSecondary
            )
          }
        }
      }

      // 4 instant Robot Command Chips directly on the Home Screen
      val homeChips =
        listOf(
          "בדוק את מצב הטאבלט שלי",
          "אני רוצה לנקות את המכשיר",
          "פתח את הגדרות הסוללה",
          "מצא אפליקציות שתופסות הרבה מקום"
        )
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        homeChips.chunked(2).forEach { pair ->
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            pair.forEach { cmd ->
              Surface(
                color = NexusCharcoal,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, NexusBorderSubtle),
                modifier =
                  Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { onQuickCommand(cmd) }
              ) {
                Text(
                  text = cmd,
                  style = MaterialTheme.typography.labelSmall,
                  color = NexusGlowSky,
                  maxLines = 1,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp)
                )
              }
            }
          }
        }
      }

      Surface(
        color = NexusCharcoal,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, NexusBorderSubtle)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = maintenanceText,
            style = MaterialTheme.typography.labelSmall,
            color = NexusGlowSky
          )
          Text(
            text = "תיקיות מאושרות: ${telemetry.authorizedFolderCount}",
            style = MaterialTheme.typography.labelSmall,
            color = NexusTextSecondary
          )
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Button(
          onClick = onOpenAssistant,
          modifier = Modifier.weight(1f).height(46.dp).testTag("open_assistant_button"),
          colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue),
          shape = RoundedCornerShape(14.dp)
        ) {
          Icon(Icons.Rounded.SmartToy, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("שיחה מלאה")
        }
        OutlinedButton(
          onClick = onOpenControl,
          modifier = Modifier.weight(1f).height(46.dp).testTag("open_control_button"),
          border = BorderStroke(1.dp, NexusBorderGlow.copy(alpha = 0.5f)),
          shape = RoundedCornerShape(14.dp)
        ) {
          Icon(Icons.Rounded.Tune, contentDescription = null, tint = NexusNeonCyan, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("מרכז שליטה", color = NexusTextPrimary)
        }
      }
    }
  }
}

@Composable
private fun TelemetryMiniCard(
  title: String,
  mainValue: String,
  subValue: String,
  percent: Int,
  accent: Color,
  icon: ImageVector,
  isAlert: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  NexusHudCard(
    modifier = modifier.nexusPressable().clickable(onClick = onClick),
    isAlert = isAlert,
    accentColor = accent,
    contentPadding = 14.dp
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(icon, contentDescription = title, tint = accent, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = title, style = MaterialTheme.typography.labelLarge, color = NexusTextSecondary)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = mainValue, style = MaterialTheme.typography.headlineMedium, color = NexusTextPrimary)
        Text(text = subValue, style = MaterialTheme.typography.bodyMedium, color = NexusTextSecondary)
      }
      Spacer(modifier = Modifier.width(8.dp))
      NexusMetricArcGauge(
        percent = percent,
        accentColor = accent,
        centerText = "$percent%",
        size = 58.dp
      )
    }
    Spacer(modifier = Modifier.height(8.dp))
    LinearProgressIndicator(
      progress = { (percent / 100f).coerceIn(0f, 1f) },
      modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(4.dp)),
      color = accent,
      trackColor = NexusBorderSubtle.copy(alpha = 0.4f)
    )
  }
}

@Composable
private fun ModuleLaunchCard(
  destination: NexusDestination,
  description: String,
  icon: ImageVector,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  NexusHudCard(
    modifier = modifier.nexusPressable().clickable(onClick = onClick).testTag("module_${destination.route}"),
    contentPadding = 14.dp
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Box(
        modifier =
          Modifier
            .size(42.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(NexusTitaniumElevated),
        contentAlignment = Alignment.Center
      ) {
        Icon(icon, contentDescription = destination.labelHe, tint = NexusNeonCyan)
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column {
        Text(text = destination.labelHe, style = MaterialTheme.typography.titleMedium, color = NexusTextPrimary)
        Text(text = description, style = MaterialTheme.typography.bodyMedium, color = NexusTextSecondary)
      }
    }
  }
}

@Composable
private fun ImportantAlertsCard(
  telemetry: SystemTelemetry,
  onNavigate: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val hasCritical = telemetry.issues.any { it.severity == HealthSeverity.CRITICAL || it.severity == HealthSeverity.WARNING }
  NexusHudCard(
    modifier = modifier,
    isAlert = hasCritical,
    accentColor = if (hasCritical) NexusAmber else NexusEmerald
  ) {
    Text(
      text = "התראות מערכת חשובות",
      style = MaterialTheme.typography.titleLarge,
      color = NexusTextPrimary
    )
    Spacer(modifier = Modifier.height(10.dp))
    if (telemetry.issues.isEmpty()) {
      Text(
        text = "לא זוהו התראות חריגות כרגע. כל המדדים בטווח התקין.",
        style = MaterialTheme.typography.bodyLarge,
        color = NexusEmerald
      )
    } else {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        telemetry.issues.forEach { issue ->
          val color =
            when (issue.severity) {
              HealthSeverity.CRITICAL -> NexusCrimson
              HealthSeverity.WARNING -> NexusAmber
              HealthSeverity.NOTICE -> NexusGlowSky
              HealthSeverity.OPTIMAL -> NexusEmerald
            }
          AnimatedVisibility(visible = true, enter = fadeIn() + slideInVertically()) {
            Surface(
              modifier = Modifier.fillMaxWidth().clickable { onNavigate(issue.targetRoute) },
              color = color.copy(alpha = 0.10f),
              shape = RoundedCornerShape(14.dp),
              border = BorderStroke(1.dp, color.copy(alpha = 0.45f))
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Rounded.WarningAmber, contentDescription = null, tint = color)
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(text = issue.title, style = MaterialTheme.typography.titleMedium, color = NexusTextPrimary)
                  Text(text = issue.detail, style = MaterialTheme.typography.bodyMedium, color = NexusTextSecondary)
                }
                Text(text = issue.actionLabel, style = MaterialTheme.typography.labelLarge, color = color)
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun SystemAndActivityCard(
  telemetry: SystemTelemetry,
  recentCleanHistory: List<CleanHistoryEntity>,
  recentAuditLogs: List<ActionAuditEntity>,
  onOpenReports: () -> Unit,
  modifier: Modifier = Modifier
) {
  val fmt = SimpleDateFormat("HH:mm dd/MM", Locale.getDefault())
  NexusHudCard(modifier = modifier) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(text = "פעילות אחרונה ונתוני חומרה", style = MaterialTheme.typography.titleLarge, color = NexusTextPrimary)
      Text(
        text = "לכל הדוחות",
        style = MaterialTheme.typography.labelLarge,
        color = NexusNeonCyan,
        modifier = Modifier.clickable(onClick = onOpenReports).padding(4.dp)
      )
    }
    Spacer(modifier = Modifier.height(10.dp))
    Text(
      text = "דגם: ${telemetry.device.manufacturer} ${telemetry.device.model} | אבטחה: ${telemetry.device.securityPatch}",
      style = MaterialTheme.typography.bodyMedium,
      color = NexusTextSecondary
    )
    Spacer(modifier = Modifier.height(10.dp))

    if (recentAuditLogs.isEmpty() && recentCleanHistory.isEmpty()) {
      Text(
        text = "יומן הפעילות ריק כרגע. הרץ סריקה או אוטומציה כדי לתעד תוצאות אמיתיות.",
        style = MaterialTheme.typography.bodyMedium,
        color = NexusTextSecondary
      )
    } else {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        recentAuditLogs.take(4).forEach { log ->
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "• ${log.actionTitle}: ${log.details}",
              style = MaterialTheme.typography.bodyMedium,
              color = if (log.succeeded) NexusTextPrimary else NexusCrimson,
              modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = fmt.format(Date(log.timestampMillis)),
              style = MaterialTheme.typography.labelSmall,
              color = NexusTextSecondary
            )
          }
        }
      }
    }
  }
}
