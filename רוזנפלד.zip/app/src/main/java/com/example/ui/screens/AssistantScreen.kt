package com.example.ui.screens

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.ImageSearch
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import android.net.Uri
import com.example.data.ai.LiveVoiceUiState
import com.example.data.ai.TranscriptionUiState
import com.example.data.ai.VisualDiagnosisUiState
import com.example.data.local.AssistantMessageEntity
import com.example.data.local.AutomationEntity
import com.example.data.model.PendingAssistantAction
import com.example.data.model.RobotMood
import com.example.ui.components.AudioTranscriptionPanel
import com.example.ui.components.LiveVoiceConversationPanel
import com.example.ui.components.NexusHudCard
import com.example.ui.components.NexusRobotAvatar
import com.example.ui.components.VisualDiagnosticsPanel
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusBorderGlow
import com.example.ui.theme.NexusBorderSubtle
import com.example.ui.theme.NexusCharcoal
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusNeonCyan
import com.example.ui.theme.NexusObsidian
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.example.ui.theme.NexusTitaniumCard
import com.example.ui.theme.NexusTitaniumElevated
import com.example.ui.viewmodel.AssistantUiState

private enum class AssistantSubMode(val titleHe: String) {
  CHAT("צ'אט חכם"),
  TRANSCRIBE("תמלול קולי"),
  LIVE_VOICE("שיחה קולית חיה"),
  VISUAL("אבחון תמונה")
}

private enum class MicTarget {
  SPEECH_INTENT,
  TRANSCRIBE_WAV,
  LIVE_VOICE
}

@Composable
fun AssistantScreen(
  assistantState: AssistantUiState,
  transcriptionState: TranscriptionUiState,
  liveVoiceState: LiveVoiceUiState,
  visualDiagnosisState: VisualDiagnosisUiState,
  messages: List<AssistantMessageEntity>,
  automations: List<AutomationEntity>,
  ttsEnabled: Boolean,
  cloudAiEnabled: Boolean,
  onSendCommand: (String) -> Unit,
  onRetryAiWithFallback: (String, Boolean) -> Unit,
  onDismissAiError: () -> Unit,
  onToggleTts: () -> Unit,
  onToggleCloudAi: () -> Unit,
  onClearHistory: () -> Unit,
  onSetListening: (Boolean) -> Unit,
  onConfirmPendingAction: (PendingAssistantAction) -> Unit,
  onDismissPendingAction: () -> Unit,
  onStartTranscribeRecord: () -> Unit,
  onStopAndTranscribe: () -> Unit,
  onCancelTranscribe: () -> Unit,
  onRetryTranscribe: () -> Unit,
  onResetTranscribe: () -> Unit,
  onStartLiveVoice: () -> Unit,
  onStopLiveVoice: () -> Unit,
  onSendLiveText: (String) -> Unit,
  onAnalyzeImage: (Uri, String) -> Unit,
  onResetVisualDiagnosis: () -> Unit,
  onVoiceError: (String) -> Unit,
  onNotifyInfo: (String) -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)

  val context = LocalContext.current
  var inputText by remember { mutableStateOf("") }
  var selectedMode by rememberSaveable { mutableStateOf(AssistantSubMode.CHAT) }
  var pendingMicTarget by remember { mutableStateOf(MicTarget.SPEECH_INTENT) }
  val listState = rememberLazyListState()

  LaunchedEffect(messages.size) {
    if (messages.isNotEmpty()) {
      listState.animateScrollToItem(messages.size - 1)
    }
  }

  val speechLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
      onSetListening(false)
      if (result.resultCode == Activity.RESULT_OK) {
        val spoken =
          result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) {
          onSendCommand(spoken)
        }
      }
    }

  val launchSpeechIntent = {
    val intent =
      Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "he-IL")
        putExtra(RecognizerIntent.EXTRA_PROMPT, "דבר אל העוזר של NEXUS...")
      }
    val ok =
      runCatching {
        onSetListening(true)
        speechLauncher.launch(intent)
        true
      }.getOrDefault(false)
    if (!ok) {
      onSetListening(false)
      onVoiceError("זיהוי קול מובנה אינו זמין — השתמש בכרטיסיית התמלול של Gemini 3.5.")
    }
  }

  val micPermissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
      if (granted) {
        when (pendingMicTarget) {
          MicTarget.SPEECH_INTENT -> launchSpeechIntent()
          MicTarget.TRANSCRIBE_WAV -> onStartTranscribeRecord()
          MicTarget.LIVE_VOICE -> onStartLiveVoice()
        }
      } else {
        onSetListening(false)
        onVoiceError("נדרשת הרשאת מיקרופון לשימוש בהקלטה, תמלול ושיחה קולית חיה.")
      }
    }

  val requestMicThenRun: (MicTarget, () -> Unit) -> Unit = { target, action ->
    val granted =
      ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
        PackageManager.PERMISSION_GRANTED
    if (granted) {
      action()
    } else {
      pendingMicTarget = target
      micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }
  }

  val quickCommands =
    remember(automations) {
      listOf(
        "בדוק את מצב הטאבלט שלי",
        "מה מצב האחסון שלי?",
        "מצא אפליקציות שתופסות הרבה מקום",
        "אני רוצה לנקות את המכשיר",
        "בדוק אילו הרשאות יש לאפליקציות",
        "פתח את הגדרות הסוללה",
        "פתח את הגדרות האינטרנט"
      ) + automations.filter { !it.isBuiltIn }.map { it.voicePhrase }
    }

  val activeRobotMood =
    when {
      liveVoiceState is LiveVoiceUiState.Active ->
        if (liveVoiceState.isSpeaking) RobotMood.SPEAKING else RobotMood.LISTENING
      transcriptionState is TranscriptionUiState.Recording -> RobotMood.LISTENING
      transcriptionState is TranscriptionUiState.Processing ||
        visualDiagnosisState is VisualDiagnosisUiState.Analyzing -> RobotMood.THINKING
      assistantState.isThinking -> RobotMood.THINKING
      else -> assistantState.robotMood
    }

  BoxWithConstraints(modifier = modifier.fillMaxSize()) {
    val isWide = maxWidth >= 740.dp

    if (isWide) {
      Row(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        NexusHudCard(modifier = Modifier.weight(0.36f), accentColor = NexusNeonCyan) {
          Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              NexusRobotAvatar(mood = activeRobotMood, size = 164.dp)
              Spacer(modifier = Modifier.height(8.dp))
              Text("NEXUS VOICE & AI CORE", style = MaterialTheme.typography.titleLarge, color = NexusNeonCyan)
              Text(
                text =
                  when {
                    liveVoiceState is LiveVoiceUiState.Active -> "שיחה קולית חיה פעילה"
                    transcriptionState is TranscriptionUiState.Recording -> "מקליט לתמלול..."
                    assistantState.isThinking -> "מנתח ומתכנן תשובה..."
                    assistantState.isListening -> "מאזין לפקודה שלך..."
                    assistantState.isSpeaking -> "מקריא תשובה..."
                    else -> assistantState.lastProviderLabel ?: "מוכן לפקודות בעברית"
                  },
                style = MaterialTheme.typography.bodyMedium,
                color = NexusTextSecondary
              )
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                  onClick = onToggleCloudAi,
                  border = BorderStroke(1.dp, NexusBorderGlow.copy(alpha = 0.5f)),
                  modifier = Modifier.weight(1f)
                ) {
                  Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = if (cloudAiEnabled) NexusNeonCyan else NexusTextSecondary)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(if (cloudAiEnabled) "Gemini AI" else "מקומי", color = NexusTextPrimary)
                }
                OutlinedButton(
                  onClick = onToggleTts,
                  border = BorderStroke(1.dp, NexusBorderGlow.copy(alpha = 0.5f)),
                  modifier = Modifier.weight(1f)
                ) {
                  Icon(
                    if (ttsEnabled) Icons.AutoMirrored.Rounded.VolumeUp else Icons.AutoMirrored.Rounded.VolumeOff,
                    contentDescription = "הקראה קולית",
                    tint = NexusNeonCyan
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(if (ttsEnabled) "הקראה" else "מושתק", color = NexusTextPrimary)
                }
              }
              OutlinedButton(
                onClick = onClearHistory,
                border = BorderStroke(1.dp, NexusBorderSubtle),
                modifier = Modifier.fillMaxWidth()
              ) {
                Icon(Icons.Rounded.DeleteSweep, contentDescription = null, tint = NexusTextSecondary)
                Spacer(modifier = Modifier.width(6.dp))
                Text("נקה היסטוריית שיחה", color = NexusTextSecondary)
              }
            }
          }
        }

        Column(modifier = Modifier.weight(0.64f).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          AssistantModeTabs(selectedMode = selectedMode, onSelect = { selectedMode = it })

          when (selectedMode) {
            AssistantSubMode.CHAT ->
              AssistantChatPane(
                assistantState = assistantState,
                messages = messages,
                listState = listState,
                quickCommands = quickCommands,
                pendingAction = assistantState.pendingAction,
                inputText = inputText,
                onInputChange = { inputText = it },
                onSend = {
                  onSendCommand(inputText)
                  inputText = ""
                },
                onChipClick = onSendCommand,
                onMicClick = { requestMicThenRun(MicTarget.SPEECH_INTENT, launchSpeechIntent) },
                onConfirmPendingAction = onConfirmPendingAction,
                onDismissPendingAction = onDismissPendingAction,
                onRetryAi = { q -> onRetryAiWithFallback(q, false) },
                onFallbackLocal = { q -> onRetryAiWithFallback(q, true) },
                onDismissAiError = onDismissAiError,
                modifier = Modifier.weight(1f)
              )

            AssistantSubMode.TRANSCRIBE ->
              AudioTranscriptionPanel(
                state = transcriptionState,
                onStartRecord = { requestMicThenRun(MicTarget.TRANSCRIBE_WAV, onStartTranscribeRecord) },
                onStopAndTranscribe = onStopAndTranscribe,
                onCancelRecord = onCancelTranscribe,
                onRetry = onRetryTranscribe,
                onUseInChat = { txt ->
                  selectedMode = AssistantSubMode.CHAT
                  onSendCommand(txt)
                  onResetTranscribe()
                },
                onCopySuccess = { onNotifyInfo("התמלול הועתק ללוח.") },
                onReset = onResetTranscribe,
                modifier = Modifier.weight(1f)
              )

            AssistantSubMode.LIVE_VOICE ->
              LiveVoiceConversationPanel(
                state = liveVoiceState,
                onStartLive = { requestMicThenRun(MicTarget.LIVE_VOICE, onStartLiveVoice) },
                onStopLive = onStopLiveVoice,
                onSendLiveText = onSendLiveText,
                modifier = Modifier.weight(1f)
              )

            AssistantSubMode.VISUAL ->
              VisualDiagnosticsPanel(
                state = visualDiagnosisState,
                cloudAiEnabled = cloudAiEnabled,
                onAnalyzeImage = onAnalyzeImage,
                onConfirmAction = onConfirmPendingAction,
                onReset = onResetVisualDiagnosis,
                modifier = Modifier.weight(1f)
              )
          }
        }
      }
    } else {
      Column(
        modifier = Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        NexusHudCard(contentPadding = 10.dp) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
              NexusRobotAvatar(mood = activeRobotMood, size = 64.dp)
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text("העוזר החכם של NEXUS", style = MaterialTheme.typography.titleMedium, color = NexusNeonCyan)
                Text(
                  text =
                    when {
                      liveVoiceState is LiveVoiceUiState.Active -> "שיחה קולית חיה פעילה"
                      assistantState.isThinking -> "מנתח תשובה..."
                      assistantState.isSpeaking -> "מקריא תשובה..."
                      else -> assistantState.lastProviderLabel ?: "זמין לפקודות אבחון ושליטה"
                    },
                  style = MaterialTheme.typography.bodyMedium,
                  color = NexusTextSecondary
                )
              }
            }
            Row {
              IconButton(onClick = onToggleCloudAi) {
                Icon(
                  Icons.Rounded.AutoAwesome,
                  contentDescription = "ענן או מקומי",
                  tint = if (cloudAiEnabled) NexusNeonCyan else NexusTextSecondary
                )
              }
              IconButton(onClick = onToggleTts) {
                Icon(
                  if (ttsEnabled) Icons.AutoMirrored.Rounded.VolumeUp else Icons.AutoMirrored.Rounded.VolumeOff,
                  contentDescription = "הפעל או השתק הקראה",
                  tint = if (ttsEnabled) NexusNeonCyan else NexusTextSecondary
                )
              }
              IconButton(onClick = onClearHistory) {
                Icon(Icons.Rounded.DeleteSweep, contentDescription = "נקה היסטוריית שיחה", tint = NexusTextSecondary)
              }
            }
          }
        }

        AssistantModeTabs(selectedMode = selectedMode, onSelect = { selectedMode = it })

        when (selectedMode) {
          AssistantSubMode.CHAT ->
            AssistantChatPane(
              assistantState = assistantState,
              messages = messages,
              listState = listState,
              quickCommands = quickCommands,
              pendingAction = assistantState.pendingAction,
              inputText = inputText,
              onInputChange = { inputText = it },
              onSend = {
                onSendCommand(inputText)
                inputText = ""
              },
              onChipClick = onSendCommand,
              onMicClick = { requestMicThenRun(MicTarget.SPEECH_INTENT, launchSpeechIntent) },
              onConfirmPendingAction = onConfirmPendingAction,
              onDismissPendingAction = onDismissPendingAction,
              onRetryAi = { q -> onRetryAiWithFallback(q, false) },
              onFallbackLocal = { q -> onRetryAiWithFallback(q, true) },
              onDismissAiError = onDismissAiError,
              modifier = Modifier.weight(1f)
            )

          AssistantSubMode.TRANSCRIBE ->
            AudioTranscriptionPanel(
              state = transcriptionState,
              onStartRecord = { requestMicThenRun(MicTarget.TRANSCRIBE_WAV, onStartTranscribeRecord) },
              onStopAndTranscribe = onStopAndTranscribe,
              onCancelRecord = onCancelTranscribe,
              onRetry = onRetryTranscribe,
              onUseInChat = { txt ->
                selectedMode = AssistantSubMode.CHAT
                onSendCommand(txt)
                onResetTranscribe()
              },
              onCopySuccess = { onNotifyInfo("התמלול הועתק ללוח.") },
              onReset = onResetTranscribe,
              modifier = Modifier.weight(1f)
            )

          AssistantSubMode.LIVE_VOICE ->
            LiveVoiceConversationPanel(
              state = liveVoiceState,
              onStartLive = { requestMicThenRun(MicTarget.LIVE_VOICE, onStartLiveVoice) },
              onStopLive = onStopLiveVoice,
              onSendLiveText = onSendLiveText,
              modifier = Modifier.weight(1f)
            )

          AssistantSubMode.VISUAL ->
            VisualDiagnosticsPanel(
              state = visualDiagnosisState,
              cloudAiEnabled = cloudAiEnabled,
              onAnalyzeImage = onAnalyzeImage,
              onConfirmAction = onConfirmPendingAction,
              onReset = onResetVisualDiagnosis,
              modifier = Modifier.weight(1f)
            )
        }
      }
    }
  }
}

@Composable
private fun AssistantModeTabs(
  selectedMode: AssistantSubMode,
  onSelect: (AssistantSubMode) -> Unit
) {
  Row(
    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    AssistantSubMode.entries.forEach { mode ->
      val icon =
        when (mode) {
          AssistantSubMode.CHAT -> Icons.Rounded.Chat
          AssistantSubMode.TRANSCRIBE -> Icons.Rounded.GraphicEq
          AssistantSubMode.LIVE_VOICE -> Icons.Rounded.RecordVoiceOver
          AssistantSubMode.VISUAL -> Icons.Rounded.ImageSearch
        }
      val tag =
        when (mode) {
          AssistantSubMode.CHAT -> "assistant_mode_chat"
          AssistantSubMode.TRANSCRIBE -> "assistant_mode_transcribe"
          AssistantSubMode.LIVE_VOICE -> "assistant_mode_live"
          AssistantSubMode.VISUAL -> "assistant_mode_visual"
        }
      FilterChip(
        selected = selectedMode == mode,
        onClick = { onSelect(mode) },
        leadingIcon = { Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp)) },
        label = { Text(mode.titleHe) },
        colors =
          FilterChipDefaults.filterChipColors(
            selectedContainerColor = NexusElectricBlue.copy(alpha = 0.35f),
            selectedLabelColor = NexusNeonCyan,
            selectedLeadingIconColor = NexusNeonCyan
          ),
        modifier = Modifier.testTag(tag)
      )
    }
  }
}

@Composable
private fun AssistantChatPane(
  assistantState: AssistantUiState,
  messages: List<AssistantMessageEntity>,
  listState: androidx.compose.foundation.lazy.LazyListState,
  quickCommands: List<String>,
  pendingAction: PendingAssistantAction?,
  inputText: String,
  onInputChange: (String) -> Unit,
  onSend: () -> Unit,
  onChipClick: (String) -> Unit,
  onMicClick: () -> Unit,
  onConfirmPendingAction: (PendingAssistantAction) -> Unit,
  onDismissPendingAction: () -> Unit,
  onRetryAi: (String) -> Unit,
  onFallbackLocal: (String) -> Unit,
  onDismissAiError: () -> Unit,
  modifier: Modifier = Modifier
) {
  NexusHudCard(modifier = modifier, contentPadding = 12.dp) {
    Column(modifier = Modifier.fillMaxSize().imePadding()) {
      if (assistantState.isThinking) {
        LinearProgressIndicator(
          modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
          color = NexusNeonCyan,
          trackColor = NexusCharcoal
        )
      }

      LazyColumn(
        state = listState,
        modifier = Modifier.weight(1f).fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(vertical = 6.dp)
      ) {
        items(messages, key = { it.id }) { msg ->
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = if (msg.isUser) Arrangement.Start else Arrangement.End
          ) {
            Surface(
              color = if (msg.isUser) NexusElectricBlue.copy(alpha = 0.25f) else NexusTitaniumElevated,
              shape = RoundedCornerShape(16.dp),
              border =
                BorderStroke(
                  1.dp,
                  if (msg.isUser) NexusElectricBlue.copy(alpha = 0.7f) else NexusBorderGlow.copy(alpha = 0.35f)
                ),
              modifier = Modifier.fillMaxWidth(0.86f)
            ) {
              Text(
                text = msg.text,
                style = MaterialTheme.typography.bodyLarge,
                color = NexusTextPrimary,
                modifier = Modifier.padding(12.dp)
              )
            }
          }
        }
      }

      if (assistantState.aiError != null) {
        val err = assistantState.aiError
        val failedQuery = assistantState.lastFailedInput
        Spacer(modifier = Modifier.height(6.dp))
        Surface(
          color = NexusCrimson.copy(alpha = 0.14f),
          shape = RoundedCornerShape(14.dp),
          border = BorderStroke(1.dp, NexusCrimson.copy(alpha = 0.7f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(err.messageHe, style = MaterialTheme.typography.bodyMedium, color = NexusTextPrimary)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              if (!failedQuery.isNullOrBlank()) {
                Button(
                  onClick = { onRetryAi(failedQuery) },
                  colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue)
                ) {
                  Text("נסה שוב")
                }
                OutlinedButton(onClick = { onFallbackLocal(failedQuery) }) {
                  Text("ענה מקומית", color = NexusNeonCyan)
                }
              }
              OutlinedButton(onClick = onDismissAiError) {
                Text("סגור", color = NexusTextSecondary)
              }
            }
          }
        }
      }

      if (pendingAction != null) {
        Spacer(modifier = Modifier.height(8.dp))
        Surface(
          color = NexusAmber.copy(alpha = 0.14f),
          shape = RoundedCornerShape(14.dp),
          border = BorderStroke(1.dp, NexusAmber.copy(alpha = 0.65f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text(text = pendingAction.title, style = MaterialTheme.typography.titleMedium, color = NexusAmber)
            Text(text = pendingAction.description, style = MaterialTheme.typography.bodyMedium, color = NexusTextSecondary)
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Button(
                onClick = { onConfirmPendingAction(pendingAction) },
                colors = ButtonDefaults.buttonColors(containerColor = NexusEmerald),
                modifier = Modifier.testTag("assistant_confirm_action")
              ) {
                Text("אשר ובצע", color = NexusObsidian)
              }
              OutlinedButton(onClick = onDismissPendingAction) {
                Text("בטל", color = NexusTextSecondary)
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))
      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        quickCommands.forEach { cmd ->
          Surface(
            color = NexusCharcoal,
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(1.dp, NexusBorderSubtle),
            modifier = Modifier.clip(RoundedCornerShape(20.dp)).clickable { onChipClick(cmd) }
          ) {
            Text(
              text = cmd,
              style = MaterialTheme.typography.labelSmall,
              color = NexusNeonCyan,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        IconButton(
          onClick = onMicClick,
          modifier =
            Modifier
              .size(48.dp)
              .clip(CircleShape)
              .background(NexusTitaniumElevated)
              .testTag("assistant_mic_button")
        ) {
          Icon(Icons.Rounded.Mic, contentDescription = "הקלדה קולית", tint = NexusNeonCyan)
        }
        OutlinedTextField(
          value = inputText,
          onValueChange = onInputChange,
          modifier = Modifier.weight(1f).testTag("assistant_input"),
          placeholder = { Text("שאל או תן משימה בעברית...", color = NexusTextSecondary) },
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          colors =
            OutlinedTextFieldDefaults.colors(
              focusedBorderColor = NexusNeonCyan,
              unfocusedBorderColor = NexusBorderSubtle,
              focusedContainerColor = NexusTitaniumCard,
              unfocusedContainerColor = NexusCharcoal,
              focusedTextColor = NexusTextPrimary,
              unfocusedTextColor = NexusTextPrimary
            )
        )
        IconButton(
          onClick = onSend,
          modifier =
            Modifier
              .size(48.dp)
              .clip(CircleShape)
              .background(NexusElectricBlue)
              .testTag("assistant_send_button")
        ) {
          Icon(Icons.AutoMirrored.Rounded.Send, contentDescription = "שלח פקודה", tint = NexusTextPrimary)
        }
      }
    }
  }
}
