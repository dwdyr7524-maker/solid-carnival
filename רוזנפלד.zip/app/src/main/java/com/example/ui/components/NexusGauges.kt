package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LocalPerformanceMode
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusBorderSubtle
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusNeonCyan
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.example.ui.theme.SpaceGroteskFontFamily
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun NexusSystemHealthRing(
  score: Int,
  statusLabel: String,
  isScanning: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  ringSize: Dp = 224.dp
) {
  val perfMode = LocalPerformanceMode.current
  val animatedScore by animateIntAsState(
    targetValue = score,
    animationSpec = tween(700, easing = FastOutSlowInEasing),
    label = "health_score_int"
  )
  val animatedSweep by animateFloatAsState(
    targetValue = (score.coerceIn(0, 100) / 100f) * 280f,
    animationSpec = tween(850, easing = FastOutSlowInEasing),
    label = "health_sweep"
  )

  val inf = rememberInfiniteTransition(label = "hud_ring_orbit")
  val orbitAngle by
    inf.animateFloat(
      initialValue = 0f,
      targetValue = if (perfMode) 0f else 360f,
      animationSpec = infiniteRepeatable(tween(if (isScanning) 1800 else 8000, easing = LinearEasing)),
      label = "orbit_angle"
    )
  val glowPulse by
    inf.animateFloat(
      initialValue = 0.65f,
      targetValue = 1f,
      animationSpec =
        infiniteRepeatable(
          animation = tween(2200, easing = FastOutSlowInEasing),
          repeatMode = RepeatMode.Reverse
        ),
      label = "glow_pulse"
    )

  val primaryRingColor =
    when {
      score >= 85 -> NexusNeonCyan
      score >= 65 -> NexusAmber
      else -> NexusCrimson
    }

  Box(
    modifier =
      modifier
        .size(ringSize)
        .clip(CircleShape)
        .clickable(onClick = onClick)
        .testTag("system_health_ring"),
    contentAlignment = Alignment.Center
  ) {
    Canvas(modifier = Modifier.fillMaxSize().padding(10.dp)) {
      val w = size.width
      val h = size.height
      val cx = w / 2f
      val cy = h / 2f
      val outerR = size.minDimension / 2f

      // Subtle 3D radial glow backdrop
      drawCircle(
        brush =
          Brush.radialGradient(
            colors =
              listOf(
                primaryRingColor.copy(alpha = 0.22f * glowPulse),
                NexusElectricBlue.copy(alpha = 0.08f),
                Color.Transparent
              ),
            center = Offset(cx, cy),
            radius = outerR
          )
      )

      // Outer calibrated tick marks
      val tickCount = 36
      for (i in 0 until tickCount) {
        val deg = i * (360f / tickCount)
        val rad = deg * (PI.toFloat() / 180f)
        val inner = outerR * if (i % 3 == 0) 0.87f else 0.91f
        val outer = outerR * 0.96f
        drawLine(
          color =
            if (i % 3 == 0) primaryRingColor.copy(alpha = 0.65f)
            else NexusBorderSubtle.copy(alpha = 0.6f),
          start = Offset(cx + cos(rad) * inner, cy + sin(rad) * inner),
          end = Offset(cx + cos(rad) * outer, cy + sin(rad) * outer),
          strokeWidth = if (i % 3 == 0) 2.2.dp.toPx() else 1.2.dp.toPx()
        )
      }

      // Base track arc
      val arcInset = outerR * 0.20f
      val arcSize = Size(w - arcInset * 2f, h - arcInset * 2f)
      drawArc(
        color = NexusBorderSubtle.copy(alpha = 0.45f),
        startAngle = 130f,
        sweepAngle = 280f,
        useCenter = false,
        topLeft = Offset(arcInset, arcInset),
        size = arcSize,
        style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
      )

      // Active health sweep arc
      drawArc(
        brush =
          Brush.sweepGradient(
            colors = listOf(NexusElectricBlue, primaryRingColor, NexusEmerald, primaryRingColor)
          ),
        startAngle = 130f,
        sweepAngle = animatedSweep,
        useCenter = false,
        topLeft = Offset(arcInset, arcInset),
        size = arcSize,
        style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
      )

      // Inner orbital sweeping radar arc
      if (!perfMode) {
        val innerInset = outerR * 0.34f
        drawArc(
          brush = Brush.sweepGradient(listOf(Color.Transparent, primaryRingColor.copy(alpha = 0.7f))),
          startAngle = orbitAngle,
          sweepAngle = 90f,
          useCenter = false,
          topLeft = Offset(innerInset, innerInset),
          size = Size(w - innerInset * 2f, h - innerInset * 2f),
          style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
        )
      }
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Text(
        text = if (isScanning) "סורק..." else "בריאות מערכת",
        style = MaterialTheme.typography.labelSmall,
        color = NexusTextSecondary
      )
      Text(
        text = "$animatedScore%",
        style =
          MaterialTheme.typography.displayLarge.copy(
            fontFamily = SpaceGroteskFontFamily,
            fontWeight = FontWeight.Bold
          ),
        color = NexusTextPrimary
      )
      Text(
        text = statusLabel,
        style = MaterialTheme.typography.labelSmall,
        color = primaryRingColor
      )
    }
  }
}

@Composable
fun NexusMetricArcGauge(
  percent: Int,
  accentColor: Color,
  centerText: String,
  modifier: Modifier = Modifier,
  size: Dp = 68.dp
) {
  val animatedSweep by animateFloatAsState(
    targetValue = (percent.coerceIn(0, 100) / 100f) * 360f,
    animationSpec = tween(700, easing = FastOutSlowInEasing),
    label = "mini_gauge"
  )

  Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
    Canvas(modifier = Modifier.fillMaxSize().padding(4.dp)) {
      drawArc(
        color = NexusBorderSubtle.copy(alpha = 0.45f),
        startAngle = -90f,
        sweepAngle = 360f,
        useCenter = false,
        style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
      )
      drawArc(
        brush = Brush.sweepGradient(listOf(accentColor.copy(alpha = 0.55f), accentColor)),
        startAngle = -90f,
        sweepAngle = animatedSweep,
        useCenter = false,
        style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
      )
    }
    Text(
      text = centerText,
      style = MaterialTheme.typography.labelMedium,
      color = NexusTextPrimary
    )
  }
}

@Composable
fun NexusLiveTrendChart(
  values: List<Float>,
  labels: List<String>,
  lineColor: Color,
  unitSuffix: String,
  modifier: Modifier = Modifier,
  chartHeight: Dp = 156.dp
) {
  val safeValues = if (values.size >= 2) values else listOf(values.firstOrNull() ?: 0f, values.firstOrNull() ?: 0f)
  val minVal = (safeValues.minOrNull() ?: 0f) - 2f
  val maxVal = ((safeValues.maxOrNull() ?: 100f) + 2f).coerceAtLeast(minVal + 5f)

  Column(modifier = modifier.fillMaxWidth()) {
    Canvas(
      modifier =
        Modifier
          .fillMaxWidth()
          .height(chartHeight)
          .padding(vertical = 8.dp, horizontal = 6.dp)
    ) {
      val w = size.width
      val h = size.height
      val stepX = w / (safeValues.size - 1).coerceAtLeast(1)

      // Subtle HUD grid lines
      for (g in 0..3) {
        val gy = h * (g / 3f)
        drawLine(
          color = NexusBorderSubtle.copy(alpha = 0.35f),
          start = Offset(0f, gy),
          end = Offset(w, gy),
          strokeWidth = 1.dp.toPx()
        )
      }

      val points =
        safeValues.mapIndexed { idx, v ->
          val norm = ((v - minVal) / (maxVal - minVal)).coerceIn(0f, 1f)
          Offset(x = idx * stepX, y = h - (norm * h))
        }

      val linePath = Path().apply {
        points.forEachIndexed { idx, pt ->
          if (idx == 0) moveTo(pt.x, pt.y) else lineTo(pt.x, pt.y)
        }
      }

      val fillPath = Path().apply {
        addPath(linePath)
        lineTo(points.last().x, h)
        lineTo(points.first().x, h)
        close()
      }

      drawPath(
        path = fillPath,
        brush =
          Brush.verticalGradient(
            colors = listOf(lineColor.copy(alpha = 0.30f), Color.Transparent)
          )
      )
      drawPath(
        path = linePath,
        color = lineColor,
        style = Stroke(width = 2.6.dp.toPx(), cap = StrokeCap.Round)
      )

      points.forEach { pt ->
        drawCircle(color = NexusObsidian(lineColor), radius = 4.5.dp.toPx(), center = pt)
        drawCircle(color = lineColor, radius = 3.dp.toPx(), center = pt)
      }
    }

    if (labels.isNotEmpty()) {
      Spacer(modifier = Modifier.height(4.dp))
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(
          text = labels.firstOrNull().orEmpty(),
          style = MaterialTheme.typography.labelSmall,
          color = NexusTextSecondary
        )
        Text(
          text = "נוכחי: ${safeValues.last().toInt()}$unitSuffix",
          style = MaterialTheme.typography.labelSmall,
          color = lineColor
        )
        Text(
          text = labels.lastOrNull().orEmpty(),
          style = MaterialTheme.typography.labelSmall,
          color = NexusTextSecondary
        )
      }
    }
  }
}

private fun NexusObsidian(fallback: Color): Color = Color(0xFF050810)
