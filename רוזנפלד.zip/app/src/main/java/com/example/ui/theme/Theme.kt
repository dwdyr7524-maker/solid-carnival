package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.dp

val LocalPerformanceMode = staticCompositionLocalOf { false }

private val NexusDarkColorScheme =
  darkColorScheme(
    primary = NexusNeonCyan,
    onPrimary = NexusObsidian,
    primaryContainer = NexusElectricDeep,
    onPrimaryContainer = NexusTextPrimary,
    secondary = NexusElectricBlue,
    onSecondary = NexusObsidian,
    secondaryContainer = NexusTitaniumElevated,
    onSecondaryContainer = NexusTextPrimary,
    tertiary = NexusEmerald,
    onTertiary = NexusObsidian,
    background = NexusObsidian,
    onBackground = NexusTextPrimary,
    surface = NexusCharcoal,
    onSurface = NexusTextPrimary,
    surfaceVariant = NexusTitaniumCard,
    onSurfaceVariant = NexusTextSecondary,
    surfaceContainerLowest = NexusObsidian,
    surfaceContainerLow = NexusCharcoal,
    surfaceContainer = NexusTitaniumDark,
    surfaceContainerHigh = NexusTitaniumCard,
    surfaceContainerHighest = NexusTitaniumElevated,
    outline = NexusBorderSubtle,
    outlineVariant = NexusBorderGlow.copy(alpha = 0.35f),
    error = NexusCrimson,
    onError = NexusTextPrimary
  )

private val NexusShapes =
  Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp)
  )

@Composable
fun MyApplicationTheme(
  performanceMode: Boolean = false,
  content: @Composable () -> Unit
) {
  CompositionLocalProvider(LocalPerformanceMode provides performanceMode) {
    MaterialTheme(
      colorScheme = NexusDarkColorScheme,
      typography = NexusTypography,
      shapes = NexusShapes,
      content = content
    )
  }
}
