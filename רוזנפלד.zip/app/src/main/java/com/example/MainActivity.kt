package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.model.SystemShortcutId
import com.example.data.system.NexusNotificationHelper
import com.example.data.system.SystemControlHelper
import com.example.ui.components.NexusCommandHeader
import com.example.ui.components.NexusParticleSplash
import com.example.ui.navigation.NexusDestination
import com.example.ui.screens.AppsScreen
import com.example.ui.screens.AssistantScreen
import com.example.ui.screens.AutomationScreen
import com.example.ui.screens.BatteryScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DeepCleanScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SecurityScreen
import com.example.ui.screens.SystemControlScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NexusBorderGlow
import com.example.ui.theme.NexusCharcoal
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusNeonCyan
import com.example.ui.theme.NexusObsidian
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.example.ui.theme.NexusTitaniumCard
import com.example.ui.viewmodel.NexusViewModel

class MainActivity : ComponentActivity() {
  private var externalRouteRequest by mutableStateOf<String?>(null)

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    configureAppCheck(this, intent)
    extractRouteFromIntent(intent)
    enableEdgeToEdge()
    setContent {
      NexusRoot(
        externalRouteRequest = externalRouteRequest,
        onConsumeExternalRoute = { externalRouteRequest = null }
      )
    }
  }

  override fun onNewIntent(intent: Intent) {
    super.onNewIntent(intent)
    setIntent(intent)
    configureAppCheck(this, intent)
    extractRouteFromIntent(intent)
  }

  private fun extractRouteFromIntent(intent: Intent?) {
    val requested = intent?.getStringExtra(NexusNotificationHelper.EXTRA_TARGET_ROUTE)
    if (!requested.isNullOrBlank()) {
      externalRouteRequest = requested
      intent.removeExtra(NexusNotificationHelper.EXTRA_TARGET_ROUTE)
    }
  }
}

@Composable
fun NexusRoot(
  externalRouteRequest: String? = null,
  onConsumeExternalRoute: () -> Unit = {},
  viewModel: NexusViewModel = viewModel()
) {
  val performanceMode by viewModel.performanceMode.collectAsStateWithLifecycle()
  var showSplash by rememberSaveable { mutableStateOf(true) }

  CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
    MyApplicationTheme(performanceMode = performanceMode) {
      AnimatedContent(
        targetState = showSplash,
        transitionSpec = {
          (fadeIn(tween(450)) + scaleIn(initialScale = 0.96f, animationSpec = tween(450))) togetherWith
            fadeOut(tween(350))
        },
        label = "splash_to_main"
      ) { splash ->
        if (splash) {
          NexusParticleSplash(onSplashFinished = { showSplash = false })
        } else {
          NexusCommandShell(
            viewModel = viewModel,
            performanceMode = performanceMode,
            externalRouteRequest = externalRouteRequest,
            onConsumeExternalRoute = onConsumeExternalRoute
          )
        }
      }
    }
  }
}

@Composable
private fun NexusCommandShell(
  viewModel: NexusViewModel,
  performanceMode: Boolean,
  externalRouteRequest: String?,
  onConsumeExternalRoute: () -> Unit
) {
  val context = LocalContext.current
  val navController = rememberNavController()
  val backStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = backStackEntry?.destination?.route ?: NexusDestination.DASHBOARD.route

  val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
  val isRefreshing by viewModel.isRefreshingTelemetry.collectAsStateWithLifecycle()
  val deepCleanState by viewModel.deepCleanState.collectAsStateWithLifecycle()
  val appsState by viewModel.appsState.collectAsStateWithLifecycle()
  val securityReport by viewModel.securityReport.collectAsStateWithLifecycle()
  val assistantState by viewModel.assistantState.collectAsStateWithLifecycle()
  val assistantMessages by viewModel.assistantMessages.collectAsStateWithLifecycle()
  val automations by viewModel.automations.collectAsStateWithLifecycle()
  val pendingAutomation by viewModel.pendingAutomationRun.collectAsStateWithLifecycle()
  val cleanHistory by viewModel.cleanHistory.collectAsStateWithLifecycle()
  val telemetrySnapshots by viewModel.telemetrySnapshots.collectAsStateWithLifecycle()
  val auditLogs by viewModel.actionAuditLogs.collectAsStateWithLifecycle()
  val safFolders by viewModel.safTreeUris.collectAsStateWithLifecycle()
  val ttsEnabled by viewModel.ttsEnabled.collectAsStateWithLifecycle()
  val cloudAiEnabled by viewModel.cloudAiEnabled.collectAsStateWithLifecycle()
  val shareTelemetryWithAi by viewModel.shareTelemetryWithAi.collectAsStateWithLifecycle()
  val transcriptionState by viewModel.transcriptionState.collectAsStateWithLifecycle()
  val liveVoiceState by viewModel.liveVoiceState.collectAsStateWithLifecycle()
  val visualDiagnosisState by viewModel.visualDiagnosisState.collectAsStateWithLifecycle()
  val cloudHealthCheckState by viewModel.cloudHealthCheckState.collectAsStateWithLifecycle()
  val backgroundAlertsEnabled by viewModel.backgroundAlertsEnabled.collectAsStateWithLifecycle()
  val alertIntervalMinutes by viewModel.alertIntervalMinutes.collectAsStateWithLifecycle()
  val centralError by viewModel.centralError.collectAsStateWithLifecycle()
  val lastMaintenance by viewModel.lastMaintenanceMillis.collectAsStateWithLifecycle()
  val bannerMessage by viewModel.uiBannerMessage.collectAsStateWithLifecycle()
  val navigateEvent by viewModel.navigateEvent.collectAsStateWithLifecycle()

  val snackbarHostState = remember { SnackbarHostState() }

  LaunchedEffect(bannerMessage) {
    val msg = bannerMessage
    if (msg != null) {
      snackbarHostState.showSnackbar(msg)
      viewModel.clearBannerMessage()
    }
  }

  val navigateToRoute: (String) -> Unit = { route ->
    if (currentRoute != route) {
      navController.navigate(route) {
        popUpTo(NexusDestination.DASHBOARD.route) { saveState = true }
        launchSingleTop = true
        restoreState = true
      }
    }
  }

  LaunchedEffect(navigateEvent) {
    val target = navigateEvent
    if (target != null) {
      navigateToRoute(target)
      viewModel.consumeNavigateEvent()
    }
  }

  LaunchedEffect(externalRouteRequest) {
    val extRoute = externalRouteRequest
    if (extRoute != null) {
      if (NexusDestination.entries.any { it.route == extRoute }) {
        navigateToRoute(extRoute)
      }
      onConsumeExternalRoute()
    }
  }

  val safFolderPicker =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
      if (uri != null) {
        runCatching {
          context.contentResolver.takePersistableUriPermission(
            uri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
          )
        }
        viewModel.onSafFolderGranted(uri)
      }
    }

  val shortcuts =
    remember(telemetry.device.hasSamsungDeviceCare) {
      SystemControlHelper(context).buildShortcuts(telemetry.device.hasSamsungDeviceCare)
    }

  val currentDest =
    NexusDestination.entries.firstOrNull { it.route == currentRoute } ?: NexusDestination.DASHBOARD

  val compactNavDestinations =
    listOf(
      NexusDestination.DASHBOARD,
      NexusDestination.DEEP_CLEAN,
      NexusDestination.ASSISTANT,
      NexusDestination.SYSTEM_CONTROL,
      NexusDestination.REPORTS
    )

  BoxWithConstraints(
    modifier =
      Modifier
        .fillMaxSize()
        .background(
          Brush.verticalGradient(
            colors = listOf(Color(0xFF071122), NexusObsidian, Color(0xFF060B14))
          )
        )
  ) {
    val isTabletLayout = maxWidth >= 700.dp

    Scaffold(
      containerColor = Color.Transparent,
      contentWindowInsets = WindowInsets.safeDrawing,
      snackbarHost = {
        SnackbarHost(hostState = snackbarHostState) { data ->
          Snackbar(
            snackbarData = data,
            containerColor = NexusTitaniumCard,
            contentColor = NexusTextPrimary,
            shape = RoundedCornerShape(14.dp)
          )
        }
      },
      bottomBar = {
        if (!isTabletLayout) {
          NavigationBar(
            containerColor = NexusCharcoal.copy(alpha = 0.96f),
            modifier = Modifier.border(1.dp, NexusBorderGlow.copy(alpha = 0.22f))
          ) {
            compactNavDestinations.forEach { dest ->
              val selected = currentRoute == dest.route
              NavigationBarItem(
                selected = selected,
                onClick = { navigateToRoute(dest.route) },
                icon = { Icon(dest.icon, contentDescription = dest.labelHe) },
                label = { Text(dest.shortLabelHe) },
                colors =
                  NavigationBarItemDefaults.colors(
                    selectedIconColor = NexusNeonCyan,
                    selectedTextColor = NexusNeonCyan,
                    indicatorColor = NexusElectricBlue.copy(alpha = 0.25f),
                    unselectedIconColor = NexusTextSecondary,
                    unselectedTextColor = NexusTextSecondary
                  ),
                modifier = Modifier.testTag("nav_${dest.route}")
              )
            }
          }
        }
      }
    ) { innerPadding ->
      Row(
        modifier =
          Modifier
            .fillMaxSize()
            .padding(innerPadding)
      ) {
        if (isTabletLayout) {
          NavigationRail(
            containerColor = NexusCharcoal.copy(alpha = 0.92f),
            modifier =
              Modifier
                .fillMaxHeight()
                .width(104.dp)
                .border(1.dp, NexusBorderGlow.copy(alpha = 0.20f))
          ) {
            Column(
              modifier = Modifier.fillMaxHeight().verticalScroll(rememberScrollState()).padding(vertical = 8.dp)
            ) {
              NexusDestination.entries.forEach { dest ->
                val selected = currentRoute == dest.route
                NavigationRailItem(
                  selected = selected,
                  onClick = { navigateToRoute(dest.route) },
                  icon = { Icon(dest.icon, contentDescription = dest.labelHe) },
                  label = { Text(dest.shortLabelHe, maxLines = 1) },
                  colors =
                    NavigationRailItemDefaults.colors(
                      selectedIconColor = NexusNeonCyan,
                      selectedTextColor = NexusNeonCyan,
                      indicatorColor = NexusElectricBlue.copy(alpha = 0.26f),
                      unselectedIconColor = NexusTextSecondary,
                      unselectedTextColor = NexusTextSecondary
                    ),
                  modifier = Modifier.testTag("rail_${dest.route}")
                )
              }
            }
          }
        }

        Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
          NexusCommandHeader(
            title = currentDest.labelHe,
            deviceLabel = "${telemetry.device.manufacturer} ${telemetry.device.model} • Android ${telemetry.device.androidRelease}",
            batteryPercent = telemetry.battery.levelPercent,
            showBackButton = !isTabletLayout && currentRoute != NexusDestination.DASHBOARD.route,
            performanceMode = performanceMode,
            isScanning = isRefreshing,
            onNavigateBack = { navigateToRoute(NexusDestination.DASHBOARD.route) },
            onTogglePerformanceMode = { viewModel.togglePerformanceMode() },
            onRefreshTelemetry = { viewModel.refreshTelemetry(recordSnapshot = true) }
          )

          centralError?.let { err ->
            androidx.compose.material3.Surface(
              color = com.example.ui.theme.NexusCrimson.copy(alpha = 0.16f),
              shape = RoundedCornerShape(12.dp),
              border = androidx.compose.foundation.BorderStroke(1.dp, com.example.ui.theme.NexusCrimson.copy(alpha = 0.7f)),
              modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
              Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
              ) {
                Text(
                  text = err.messageHe,
                  style = MaterialTheme.typography.bodyMedium,
                  color = NexusTextPrimary,
                  modifier = Modifier.weight(1f)
                )
                androidx.compose.material3.TextButton(onClick = { viewModel.refreshTelemetry(recordSnapshot = false); viewModel.dismissCentralError() }) {
                  Text("נסה שוב", color = NexusNeonCyan)
                }
                androidx.compose.material3.TextButton(onClick = { viewModel.dismissCentralError() }) {
                  Text("סגור", color = NexusTextSecondary)
                }
              }
            }
          }

          val animDuration = if (performanceMode) 150 else 300
          NavHost(
            navController = navController,
            startDestination = NexusDestination.DASHBOARD.route,
            enterTransition = {
              fadeIn(tween(animDuration)) + scaleIn(initialScale = 0.975f, animationSpec = tween(animDuration))
            },
            exitTransition = { fadeOut(tween(animDuration)) },
            popEnterTransition = {
              fadeIn(tween(animDuration)) + scaleIn(initialScale = 0.975f, animationSpec = tween(animDuration))
            },
            popExitTransition = { fadeOut(tween(animDuration)) },
            modifier = Modifier.weight(1f).fillMaxWidth()
          ) {
            composable(NexusDestination.DASHBOARD.route) {
              DashboardScreen(
                telemetry = telemetry,
                isRefreshing = isRefreshing,
                lastMaintenanceMillis = lastMaintenance,
                recentCleanHistory = cleanHistory,
                recentAuditLogs = auditLogs,
                onRefreshTelemetry = { viewModel.refreshTelemetry(recordSnapshot = true) },
                onNavigate = navigateToRoute,
                onQuickCleanLaunch = {
                  navigateToRoute(NexusDestination.DEEP_CLEAN.route)
                  viewModel.startDeepCleanScan()
                },
                onAssistantQuickCommand = { cmd ->
                  viewModel.sendAssistantCommand(cmd)
                  navigateToRoute(NexusDestination.ASSISTANT.route)
                }
              )
            }
            composable(NexusDestination.DEEP_CLEAN.route) {
              DeepCleanScreen(
                state = deepCleanState,
                telemetry = telemetry,
                safFolders = safFolders,
                onStartScan = { viewModel.startDeepCleanScan() },
                onToggleCandidate = { viewModel.toggleCleanCandidate(it) },
                onRequestCleanConfirmation = { viewModel.requestCleanConfirmation() },
                onConfirmClean = { viewModel.executeConfirmedClean() },
                onCancelConfirm = { viewModel.cancelCleanConfirmation() },
                onRequestAddSafFolder = { safFolderPicker.launch(null) },
                onRemoveSafFolder = { viewModel.removeSafFolder(it) },
                onOpenUsageAccessSettings = { viewModel.openSystemShortcut(SystemShortcutId.USAGE_ACCESS) },
                onOpenAndroidManageStorage = { viewModel.openSystemShortcut(SystemShortcutId.STORAGE) },
                onOpenAppDetails = { pkg, name -> viewModel.openAppSystemSettings(pkg, name) },
                onOpenSamsungDeviceCare = { viewModel.openSystemShortcut(SystemShortcutId.SAMSUNG_DEVICE_CARE) },
                onBack = { navigateToRoute(NexusDestination.DASHBOARD.route) }
              )
            }
            composable(NexusDestination.ASSISTANT.route) {
              AssistantScreen(
                assistantState = assistantState,
                transcriptionState = transcriptionState,
                liveVoiceState = liveVoiceState,
                visualDiagnosisState = visualDiagnosisState,
                messages = assistantMessages,
                automations = automations,
                ttsEnabled = ttsEnabled,
                cloudAiEnabled = cloudAiEnabled,
                onSendCommand = { viewModel.sendAssistantCommand(it) },
                onRetryAiWithFallback = { q, fallback -> viewModel.sendAssistantCommand(q, forceLocalFallback = fallback) },
                onDismissAiError = { viewModel.dismissAssistantAiError() },
                onToggleTts = { viewModel.toggleTtsEnabled() },
                onToggleCloudAi = { viewModel.toggleCloudAiEnabled() },
                onClearHistory = { viewModel.clearAssistantHistory() },
                onSetListening = { viewModel.setListeningState(it) },
                onConfirmPendingAction = { viewModel.confirmAssistantAction(it) },
                onDismissPendingAction = { viewModel.dismissAssistantAction() },
                onStartTranscribeRecord = { viewModel.startAudioTranscriptionRecording() },
                onStopAndTranscribe = { viewModel.stopAndTranscribeAudio() },
                onCancelTranscribe = { viewModel.cancelAudioTranscription() },
                onRetryTranscribe = { viewModel.retryLastTranscription() },
                onResetTranscribe = { viewModel.resetTranscriptionState() },
                onStartLiveVoice = { viewModel.startLiveVoiceConversation() },
                onStopLiveVoice = { viewModel.stopLiveVoiceConversation() },
                onSendLiveText = { viewModel.sendLiveTextMessage(it) },
                onAnalyzeImage = { uri, question -> viewModel.analyzeDiagnosticImageUri(uri, question) },
                onResetVisualDiagnosis = { viewModel.clearVisualDiagnosis() },
                onVoiceError = { msg -> viewModel.showBanner(msg) },
                onNotifyInfo = { msg -> viewModel.showBanner(msg) },
                onBack = { navigateToRoute(NexusDestination.DASHBOARD.route) }
              )
            }
            composable(NexusDestination.SYSTEM_CONTROL.route) {
              SystemControlScreen(
                shortcuts = shortcuts,
                telemetry = telemetry,
                onOpenShortcut = { viewModel.openSystemShortcut(it) },
                onBack = { navigateToRoute(NexusDestination.DASHBOARD.route) }
              )
            }
            composable(NexusDestination.BATTERY.route) {
              BatteryScreen(
                telemetry = telemetry,
                snapshots = telemetrySnapshots,
                backgroundAlertsEnabled = backgroundAlertsEnabled,
                alertIntervalMinutes = alertIntervalMinutes,
                onToggleBackgroundAlerts = { viewModel.setBackgroundAlertsEnabled(it) },
                onSelectAlertInterval = { viewModel.setAlertIntervalMinutes(it) },
                onRunBackgroundCheckNow = { viewModel.triggerImmediateBackgroundCheck() },
                onOpenBatterySettings = { viewModel.openSystemShortcut(SystemShortcutId.BATTERY) },
                onRecordSnapshotNow = { viewModel.refreshTelemetry(recordSnapshot = true) },
                onBack = { navigateToRoute(NexusDestination.DASHBOARD.route) }
              )
            }
            composable(NexusDestination.APPS.route) {
              AppsScreen(
                state = appsState,
                hasUsageAccess = telemetry.hasUsageAccessPermission,
                onSearchChange = { viewModel.updateAppSearch(it) },
                onSortChange = { viewModel.updateAppSort(it) },
                onFilterChange = { viewModel.updateAppFilter(it) },
                onSelectApp = { viewModel.selectAppPackage(it) },
                onLaunchApp = { pkg, name -> viewModel.launchInstalledApp(pkg, name) },
                onOpenAppSettings = { pkg, name -> viewModel.openAppSystemSettings(pkg, name) },
                onOpenUsageAccess = { viewModel.openSystemShortcut(SystemShortcutId.USAGE_ACCESS) },
                onBack = { navigateToRoute(NexusDestination.DASHBOARD.route) }
              )
            }
            composable(NexusDestination.SECURITY.route) {
              SecurityScreen(
                report = securityReport,
                cloudAiEnabled = cloudAiEnabled,
                shareTelemetryWithAi = shareTelemetryWithAi,
                cloudHealthCheckState = cloudHealthCheckState,
                onToggleCloudAi = { viewModel.toggleCloudAiEnabled() },
                onToggleShareTelemetryWithAi = { viewModel.toggleShareTelemetryWithAi() },
                onRunCloudHealthCheck = { viewModel.runCloudHealthCheck() },
                onDeleteAllUserData = { viewModel.clearAllPersonalData() },
                onRefreshAudit = { viewModel.loadAppsAndSecurity() },
                onOpenPrivacySettings = { viewModel.openSystemShortcut(SystemShortcutId.PERMISSIONS) },
                onOpenAppPermissions = { pkg, name -> viewModel.openAppSystemSettings(pkg, name) },
                onBack = { navigateToRoute(NexusDestination.DASHBOARD.route) }
              )
            }
            composable(NexusDestination.AUTOMATION.route) {
              AutomationScreen(
                automations = automations,
                pendingConfirmation = pendingAutomation,
                onRequestRun = { viewModel.requestRunAutomation(it) },
                onConfirmRun = { viewModel.executeAutomation(it) },
                onDismissConfirm = { viewModel.dismissAutomationConfirmation() },
                onCreateAutomation = { name, phrase, steps, intervalHours ->
                  viewModel.createCustomAutomation(name, phrase, steps, intervalHours)
                },
                onUpdateSchedule = { automation, intervalHours ->
                  viewModel.updateAutomationSchedule(automation, intervalHours)
                },
                onDeleteCustom = { viewModel.deleteCustomAutomation(it) },
                onBack = { navigateToRoute(NexusDestination.DASHBOARD.route) }
              )
            }
            composable(NexusDestination.REPORTS.route) {
              ReportsScreen(
                cleanHistory = cleanHistory,
                snapshots = telemetrySnapshots,
                auditLogs = auditLogs,
                onBuildReportText = { viewModel.buildExportReportText() },
                onExportJsonBackup = { viewModel.exportJsonBackup() },
                onRestoreBackupJson = { json -> viewModel.restoreBackupFromJson(json) },
                onNotifyResult = { msg -> viewModel.showBanner(msg) },
                onBack = { navigateToRoute(NexusDestination.DASHBOARD.route) }
              )
            }
          }
        }
      }
    }
  }
}
