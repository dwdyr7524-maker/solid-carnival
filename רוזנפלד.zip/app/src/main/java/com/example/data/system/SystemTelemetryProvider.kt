package com.example.data.system

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.Process
import android.os.StatFs
import android.os.SystemClock
import android.os.storage.StorageManager
import com.example.data.model.BatteryTelemetry
import com.example.data.model.DeviceIdentity
import com.example.data.model.HealthIssue
import com.example.data.model.HealthSeverity
import com.example.data.model.NetworkTelemetry
import com.example.data.model.RamTelemetry
import com.example.data.model.StorageTelemetry
import com.example.data.model.SystemTelemetry
import java.util.Locale
import kotlin.math.roundToInt

class SystemTelemetryProvider(private val context: Context) {

  fun captureTelemetry(authorizedFolderCount: Int): SystemTelemetry {
    val battery = readBattery()
    val ram = readRam()
    val storage = readStorage()
    val network = readNetwork()
    val device = readDeviceIdentity()
    val hasUsageAccess = hasUsageStatsPermission()

    val issues = mutableListOf<HealthIssue>()
    var score = 100

    if (storage.usedPercent >= 92) {
      score -= 28
      issues +=
        HealthIssue(
          id = "storage_critical",
          title = "אחסון פנימי כמעט מלא (${storage.usedPercent}%)",
          detail = "נותרו ${formatBytes(storage.freeBytes)} פנויים. מומלץ להריץ ניקוי עמוק.",
          severity = HealthSeverity.CRITICAL,
          actionLabel = "פתח ניקוי עמוק",
          targetRoute = "deep_clean"
        )
    } else if (storage.usedPercent >= 82) {
      score -= 15
      issues +=
        HealthIssue(
          id = "storage_warning",
          title = "ניצולת אחסון גבוהה (${storage.usedPercent}%)",
          detail = "פנוי: ${formatBytes(storage.freeBytes)}. בדיקת קבצים גדולים ואפליקציות תסייע.",
          severity = HealthSeverity.WARNING,
          actionLabel = "סרוק אחסון",
          targetRoute = "deep_clean"
        )
    }

    if (ram.isLowMemory || ram.usedPercent >= 88) {
      score -= 18
      issues +=
        HealthIssue(
          id = "ram_pressure",
          title = "עומס גבוה בזיכרון RAM (${ram.usedPercent}%)",
          detail = "זמין כעת: ${formatBytes(ram.availableBytes)} מתוך ${formatBytes(ram.totalBytes)}.",
          severity = HealthSeverity.WARNING,
          actionLabel = "בדוק אפליקציות",
          targetRoute = "apps"
        )
    } else if (ram.usedPercent >= 78) {
      score -= 8
    }

    if (battery.isAbnormal) {
      score -= 18
      issues +=
        HealthIssue(
          id = "battery_abnormal",
          title = "התראת סוללה חריגה",
          detail = battery.alertMessage ?: "זוהתה טמפרטורה או בריאות סוללה חריגה.",
          severity = HealthSeverity.CRITICAL,
          actionLabel = "מרכז סוללה",
          targetRoute = "battery"
        )
    } else if (battery.levelPercent <= 15 && !battery.isCharging) {
      score -= 10
      issues +=
        HealthIssue(
          id = "battery_low",
          title = "סוללה חלשה (${battery.levelPercent}%)",
          detail = "מומלץ לחבר למטען או להפעיל חיסכון בסוללה.",
          severity = HealthSeverity.NOTICE,
          actionLabel = "הגדרות סוללה",
          targetRoute = "battery"
        )
    }

    if (!device.isDeviceSecureLock) {
      score -= 10
      issues +=
        HealthIssue(
          id = "lock_insecure",
          title = "לא מוגדרת נעילת מסך מאובטחת",
          detail = "הגדרת קוד PIN, תבנית או טביעת אצבע מגינה על הטאבלט.",
          severity = HealthSeverity.WARNING,
          actionLabel = "מרכז אבטחה",
          targetRoute = "security"
        )
    }

    if (!hasUsageAccess) {
      issues +=
        HealthIssue(
          id = "usage_access_missing",
          title = "גישה לנתוני שימוש לא הופעלה",
          detail = "כדי לחשב מטמון של אפליקציות ב-Android 10, יש לאשר גישת נתוני שימוש.",
          severity = HealthSeverity.NOTICE,
          actionLabel = "הגדר כעת",
          targetRoute = "deep_clean"
        )
    }

    val boundedScore = score.coerceIn(15, 100)
    val statusLabel =
      when {
        boundedScore >= 88 -> "מערכת יציבה ואופטימלית"
        boundedScore >= 70 -> "מצב תקין — נדרשת תחזוקה קלה"
        boundedScore >= 50 -> "עומס מערכת — מומלץ ניקוי"
        else -> "התראת תחזוקה דחופה"
      }

    return SystemTelemetry(
      battery = battery,
      ram = ram,
      storage = storage,
      network = network,
      device = device,
      healthScore = boundedScore,
      healthStatusLabel = statusLabel,
      issues = issues,
      hasUsageAccessPermission = hasUsageAccess,
      authorizedFolderCount = authorizedFolderCount,
      capturedAtMillis = System.currentTimeMillis()
    )
  }

  fun hasUsageStatsPermission(): Boolean {
    return try {
      val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
      val mode =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
          appOps.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
          )
        } else {
          @Suppress("DEPRECATION")
          appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
          )
        }
      mode == AppOpsManager.MODE_ALLOWED
    } catch (_: Exception) {
      false
    }
  }

  private fun readBattery(): BatteryTelemetry {
    val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
    val percent =
      if (level >= 0 && scale > 0) ((level * 100f) / scale).roundToInt().coerceIn(0, 100)
      else {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100)
      }

    val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
    val isCharging =
      status == BatteryManager.BATTERY_STATUS_CHARGING ||
        status == BatteryManager.BATTERY_STATUS_FULL

    val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
    val chargeSource =
      when (plugged) {
        BatteryManager.BATTERY_PLUGGED_AC -> "מטען קיר (AC)"
        BatteryManager.BATTERY_PLUGGED_USB -> "חיבור USB"
        BatteryManager.BATTERY_PLUGGED_WIRELESS -> "טעינה אלחוטית"
        else -> if (isCharging) "בטעינה" else "פריקה (סוללה)"
      }

    val tempTenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
    val tempC = tempTenths / 10f
    val voltageMv = intent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
    val healthCode =
      intent?.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
        ?: BatteryManager.BATTERY_HEALTH_UNKNOWN
    val technology = intent?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY)?.ifBlank { "Li-ion" } ?: "Li-ion"

    val healthLabel =
      when (healthCode) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "תקינה"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "התחממות יתר"
        BatteryManager.BATTERY_HEALTH_DEAD -> "סוללה פגומה"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "מתח יתר"
        BatteryManager.BATTERY_HEALTH_COLD -> "טמפרטורה נמוכה מדי"
        else -> "תקינה / לא מדווח"
      }

    val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    val isPowerSave = powerManager.isPowerSaveMode

    val alertMessage =
      when {
        healthCode == BatteryManager.BATTERY_HEALTH_OVERHEAT || tempC >= 43f ->
          "טמפרטורת סוללה גבוהה (${String.format(Locale.US, "%.1f", tempC)}°C). יש להפחית עומס ולהימנע מטעינה ישירה."
        healthCode == BatteryManager.BATTERY_HEALTH_DEAD ||
          healthCode == BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE ->
          "מערכת Android מדווחת על מצב סוללה חריג: $healthLabel."
        else -> null
      }

    return BatteryTelemetry(
      levelPercent = percent,
      isCharging = isCharging,
      chargeSource = chargeSource,
      temperatureC = tempC,
      voltageMv = voltageMv,
      healthLabel = healthLabel,
      technology = technology,
      isPowerSaveMode = isPowerSave,
      isAbnormal = alertMessage != null,
      alertMessage = alertMessage
    )
  }

  private fun readRam(): RamTelemetry {
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val memInfo = ActivityManager.MemoryInfo()
    am.getMemoryInfo(memInfo)
    val total = memInfo.totalMem.coerceAtLeast(1L)
    val avail = memInfo.availMem.coerceIn(0L, total)
    val used = (total - avail).coerceAtLeast(0L)
    val usedPct = ((used * 100.0) / total).roundToInt().coerceIn(0, 100)
    return RamTelemetry(
      totalBytes = total,
      availableBytes = avail,
      usedBytes = used,
      usedPercent = usedPct,
      isLowMemory = memInfo.lowMemory
    )
  }

  private fun readStorage(): StorageTelemetry {
    val statFs = StatFs(Environment.getDataDirectory().path)
    val total = statFs.totalBytes.coerceAtLeast(1L)
    val free = statFs.availableBytes.coerceIn(0L, total)
    val used = (total - free).coerceAtLeast(0L)
    val usedPct = ((used * 100.0) / total).roundToInt().coerceIn(0, 100)

    val allocatable =
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        try {
          val sm = context.getSystemService(Context.STORAGE_SERVICE) as StorageManager
          sm.getAllocatableBytes(StorageManager.UUID_DEFAULT)
        } catch (_: Exception) {
          free
        }
      } else {
        free
      }

    return StorageTelemetry(
      totalBytes = total,
      freeBytes = free,
      usedBytes = used,
      usedPercent = usedPct,
      allocatableBytes = allocatable
    )
  }

  private fun readNetwork(): NetworkTelemetry {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val active = cm.activeNetwork
    val caps = active?.let { cm.getNetworkCapabilities(it) }
    val isConnected =
      caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)

    val transportLabel =
      when {
        caps == null -> "לא מחובר"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "רשת סלולרית"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet קווי"
        else -> "רשת פעילה"
      }

    val isMetered = cm.isActiveNetworkMetered
    val downKbps = caps?.linkDownstreamBandwidthKbps ?: 0
    val upKbps = caps?.linkUpstreamBandwidthKbps ?: 0

    var rssi: Int? = null
    var linkSpeed: Int? = null
    if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true) {
      try {
        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION")
        val info = wm.connectionInfo
        if (info != null && info.networkId != -1) {
          rssi = info.rssi
          linkSpeed = info.linkSpeed
        }
      } catch (_: Exception) {
      }
    }

    return NetworkTelemetry(
      isConnected = isConnected,
      transportLabel = transportLabel,
      isMetered = isMetered,
      downstreamKbps = downKbps,
      upstreamKbps = upKbps,
      wifiRssiDbm = rssi,
      wifiLinkSpeedMbps = linkSpeed
    )
  }

  private fun readDeviceIdentity(): DeviceIdentity {
    val manufacturer =
      Build.MANUFACTURER.replaceFirstChar {
        if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString()
      }
    val model = Build.MODEL
    val isSamsung = manufacturer.equals("Samsung", ignoreCase = true)
    val hasDeviceCare =
      isPackageInstalled("com.samsung.android.lool") ||
        isPackageInstalled("com.samsung.android.sm")

    val keyguard = context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
    val isSecure = keyguard.isDeviceSecure

    return DeviceIdentity(
      manufacturer = manufacturer,
      model = model,
      androidRelease = Build.VERSION.RELEASE ?: "10",
      sdkInt = Build.VERSION.SDK_INT,
      securityPatch = Build.VERSION.SECURITY_PATCH ?: "לא זמין",
      uptimeMillis = SystemClock.elapsedRealtime(),
      isSamsungDevice = isSamsung,
      hasSamsungDeviceCare = hasDeviceCare,
      isDeviceSecureLock = isSecure
    )
  }

  private fun isPackageInstalled(pkg: String): Boolean {
    return try {
      context.packageManager.getPackageInfo(pkg, 0)
      true
    } catch (_: PackageManager.NameNotFoundException) {
      false
    }
  }
}

fun formatBytes(bytes: Long): String {
  if (bytes <= 0L) return "0 B"
  val kb = 1024.0
  val mb = kb * 1024.0
  val gb = mb * 1024.0
  return when {
    bytes >= gb -> String.format(Locale.US, "%.2f GB", bytes / gb)
    bytes >= mb -> String.format(Locale.US, "%.1f MB", bytes / mb)
    bytes >= kb -> String.format(Locale.US, "%.0f KB", bytes / kb)
    else -> "$bytes B"
  }
}

fun formatUptime(uptimeMillis: Long): String {
  val totalMinutes = (uptimeMillis / 60_000L).coerceAtLeast(0L)
  val days = totalMinutes / (60 * 24)
  val hours = (totalMinutes % (60 * 24)) / 60
  val mins = totalMinutes % 60
  return when {
    days > 0 -> "${days} ימים, ${hours} שעות"
    hours > 0 -> "${hours} שעות, ${mins} דקות"
    else -> "$mins דקות"
  }
}
