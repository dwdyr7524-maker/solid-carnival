package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CleanHistoryDao {
  @Query("SELECT * FROM clean_history ORDER BY timestampMillis DESC LIMIT 50")
  fun observeHistory(): Flow<List<CleanHistoryEntity>>

  @Query("SELECT * FROM clean_history ORDER BY timestampMillis DESC LIMIT 50")
  suspend fun getHistoryOnce(): List<CleanHistoryEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(entry: CleanHistoryEntity)

  @Query("DELETE FROM clean_history")
  suspend fun clearAll()
}

@Dao
interface TelemetrySnapshotDao {
  @Query("SELECT * FROM telemetry_snapshots ORDER BY timestampMillis DESC LIMIT 40")
  fun observeRecentSnapshots(): Flow<List<TelemetrySnapshotEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(snapshot: TelemetrySnapshotEntity)

  @Query(
    "DELETE FROM telemetry_snapshots WHERE id NOT IN (SELECT id FROM telemetry_snapshots ORDER BY timestampMillis DESC LIMIT 120)"
  )
  suspend fun pruneOld()

  @Query("DELETE FROM telemetry_snapshots")
  suspend fun clearAll()
}

@Dao
interface AssistantMessageDao {
  @Query(
    "SELECT * FROM (SELECT * FROM assistant_messages ORDER BY timestampMillis DESC LIMIT 100) ORDER BY timestampMillis ASC"
  )
  fun observeMessages(): Flow<List<AssistantMessageEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(message: AssistantMessageEntity)

  @Query("DELETE FROM assistant_messages")
  suspend fun clearAll()
}

@Dao
interface AutomationDao {
  @Query("SELECT * FROM automations ORDER BY isBuiltIn DESC, id ASC")
  fun observeAutomations(): Flow<List<AutomationEntity>>

  @Query("SELECT * FROM automations")
  suspend fun getAllOnce(): List<AutomationEntity>

  @Query("SELECT * FROM automations WHERE id = :id LIMIT 1")
  suspend fun getById(id: Long): AutomationEntity?

  @Query("SELECT * FROM automations WHERE scheduleIntervalHours > 0")
  suspend fun getScheduledOnce(): List<AutomationEntity>

  @Query("SELECT * FROM automations WHERE isBuiltIn = 0 ORDER BY id ASC")
  suspend fun getCustomOnce(): List<AutomationEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(automation: AutomationEntity): Long

  @Update
  suspend fun update(automation: AutomationEntity)

  @Query("UPDATE automations SET scheduleIntervalHours = :hours WHERE id = :id")
  suspend fun updateSchedule(id: Long, hours: Int)

  @Query("DELETE FROM automations WHERE id = :id AND isBuiltIn = 0")
  suspend fun deleteCustom(id: Long)

  @Query("DELETE FROM automations WHERE isBuiltIn = 0")
  suspend fun deleteAllCustom()
}

@Dao
interface ActionAuditDao {
  @Query("SELECT * FROM action_audit ORDER BY timestampMillis DESC LIMIT 80")
  fun observeAuditLogs(): Flow<List<ActionAuditEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(audit: ActionAuditEntity)

  @Query("DELETE FROM action_audit")
  suspend fun clearAll()
}
