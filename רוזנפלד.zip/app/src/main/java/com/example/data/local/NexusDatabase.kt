package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
  entities =
    [
      CleanHistoryEntity::class,
      TelemetrySnapshotEntity::class,
      AssistantMessageEntity::class,
      AutomationEntity::class,
      ActionAuditEntity::class
    ],
  version = 2,
  exportSchema = false
)
abstract class NexusDatabase : RoomDatabase() {
  abstract fun cleanHistoryDao(): CleanHistoryDao
  abstract fun telemetrySnapshotDao(): TelemetrySnapshotDao
  abstract fun assistantMessageDao(): AssistantMessageDao
  abstract fun automationDao(): AutomationDao
  abstract fun actionAuditDao(): ActionAuditDao

  companion object {
    @Volatile private var INSTANCE: NexusDatabase? = null

    private val MIGRATION_1_2 =
      object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
          db.execSQL(
            "ALTER TABLE automations ADD COLUMN scheduleIntervalHours INTEGER NOT NULL DEFAULT 0"
          )
        }
      }

    fun getInstance(context: Context): NexusDatabase {
      return INSTANCE
        ?: synchronized(this) {
          INSTANCE
            ?: Room.databaseBuilder(
                context.applicationContext,
                NexusDatabase::class.java,
                "nexus_command_db"
              )
              .addMigrations(MIGRATION_1_2)
              .fallbackToDestructiveMigration(dropAllTables = true)
              .build()
              .also { INSTANCE = it }
        }
    }
  }
}
