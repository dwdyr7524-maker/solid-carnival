package com.example.data.ai

import android.graphics.Bitmap
import com.example.data.local.AutomationEntity
import com.example.data.model.AppDiagnosticInfo
import com.example.data.model.PendingAssistantAction
import com.example.data.model.SecurityAuditReport
import com.example.data.model.SystemTelemetry
import kotlinx.coroutines.flow.StateFlow

/** Centralized error model surfaced cleanly in Hebrew across all NEXUS subsystems. */
data class NexusAppError(
  val source: String,
  val messageHe: String,
  val canRetry: Boolean = true,
  val technicalHint: String? = null
)

sealed interface TranscriptionUiState {
  data object Idle : TranscriptionUiState
  data class Recording(val elapsedSeconds: Int, val amplitude: Float) : TranscriptionUiState
  data object Processing : TranscriptionUiState
  data class Success(val text: String, val modelUsed: String = "gemini-3.5-transcribe") :
    TranscriptionUiState
  data class Error(val error: NexusAppError) : TranscriptionUiState
}

data class VoiceTranscriptTurn(
  val id: Long,
  val isUser: Boolean,
  val text: String
)

sealed interface LiveVoiceUiState {
  data object Idle : LiveVoiceUiState
  data object Connecting : LiveVoiceUiState
  data class Active(
    val isSpeaking: Boolean,
    val isMuted: Boolean,
    val userPartialTranscript: String,
    val modelPartialTranscript: String,
    val turns: List<VoiceTranscriptTurn>
  ) : LiveVoiceUiState
  data class Error(val error: NexusAppError) : LiveVoiceUiState
}

sealed interface VisualDiagnosisUiState {
  data object Idle : VisualDiagnosisUiState
  data object Analyzing : VisualDiagnosisUiState
  data class Success(
    val reply: AiAgentReply,
    val analyzedAtMillis: Long
  ) : VisualDiagnosisUiState
  data class Error(val error: NexusAppError) : VisualDiagnosisUiState
}

sealed interface CloudHealthCheckState {
  data object Idle : CloudHealthCheckState
  data object Checking : CloudHealthCheckState
  data class Healthy(
    val latencyMs: Long,
    val modelChecked: String,
    val summaryHe: String,
    val checkedAtMillis: Long
  ) : CloudHealthCheckState
  data class Unhealthy(
    val error: NexusAppError,
    val latencyMs: Long,
    val checkedAtMillis: Long
  ) : CloudHealthCheckState
}

data class AiAgentReply(
  val replyText: String,
  val actionTag: String,
  val plannedSteps: List<String> = emptyList(),
  val pendingAction: PendingAssistantAction? = null,
  val providerName: String,
  val isCloudEnhanced: Boolean
)

/**
 * Provider-agnostic AI interface so NEXUS supports Firebase AI Logic (Gemini) and offline
 * rule-based fallback cleanly without exposing keys or locking to one backend.
 */
interface NexusAiProvider {
  val providerId: String

  val liveVoiceState: StateFlow<LiveVoiceUiState>

  suspend fun generateAssistantResponse(
    userInput: String,
    recentHistory: List<Pair<Boolean, String>>,
    telemetry: SystemTelemetry?,
    apps: List<AppDiagnosticInfo>,
    securityReport: SecurityAuditReport?,
    customAutomations: List<AutomationEntity>,
    allowDeviceContextSharing: Boolean
  ): Result<AiAgentReply>

  suspend fun analyzeDiagnosticImage(
    bitmap: Bitmap,
    userQuestion: String,
    telemetry: SystemTelemetry?,
    allowDeviceContextSharing: Boolean
  ): Result<AiAgentReply>

  suspend fun runCloudHealthCheck(): CloudHealthCheckState

  suspend fun transcribeAudio(
    audioBytes: ByteArray,
    mimeType: String = "audio/wav",
    languageHint: String = "he-IL"
  ): Result<String>

  suspend fun startLiveVoiceConversation(
    telemetry: SystemTelemetry?,
    apps: List<AppDiagnosticInfo>,
    securityReport: SecurityAuditReport?,
    allowDeviceContextSharing: Boolean
  ): Result<Unit>

  suspend fun sendTextToLiveSession(text: String): Result<Unit>

  suspend fun stopLiveVoiceConversation()
}

object NexusAiErrorMapper {
  fun toHebrewError(source: String, throwable: Throwable): NexusAppError {
    val raw = throwable.localizedMessage.orEmpty()
    val lower = raw.lowercase()
    val msg =
      when {
        throwable is SecurityException ->
          raw.ifBlank { "חסרה הרשאת מיקרופון או הרשאת מערכת מתאימה לביצוע הפעולה." }
        lower.contains("timeout") ->
          "חלף הזמן המותר להמתנה לתשובת הבינה המלאכותית. בדוק חיבור רשת ונסה שוב."
        lower.contains("403") || lower.contains("appcheck") || lower.contains("app check") ->
          "שגיאת אימות App Check מול Firebase. ודא שהאפליקציה רשומה ונסה שנית."
        lower.contains("429") || lower.contains("quota") || lower.contains("resource_exhausted") ->
          "חריגה ממכסת הבקשות או עומס זמני בשירות הענן. המתן מספר שניות ונסה שוב."
        lower.contains("unable to resolve host") ||
          lower.contains("network") ||
          lower.contains("connect") ||
          lower.contains("offline") ||
          lower.contains("socket") ->
          "חיבור הרשת נותק או אינו יציב. ניתן להמשיך במצב סוכן מקומי ללא אינטרנט."
        lower.contains("empty") ->
          "התקבלה תשובה ריקה מהמודל. נסה לנסח את הבקשה מחדש או לדבר קרוב יותר למיקרופון."
        else ->
          if (raw.isNotBlank()) "שגיאה בשירות הבינה המלאכותית: $raw"
          else "אירעה שגיאה לא צפויה בעיבוד הבקשה."
      }
    return NexusAppError(
      source = source,
      messageHe = msg,
      canRetry = true,
      technicalHint = throwable::class.simpleName
    )
  }
}
