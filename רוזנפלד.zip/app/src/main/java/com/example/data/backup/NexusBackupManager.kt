package com.example.data.backup

import com.example.data.local.AutomationEntity
import com.example.data.local.NexusDatabase
import com.example.data.local.PreferencesManager
import com.example.data.model.AutomationStepType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class BackupRestoreSummary(
  val restoredAutomationsCount: Int,
  val restoredPreferences: Boolean
)

class NexusBackupManager(
  private val db: NexusDatabase,
  private val prefs: PreferencesManager
) {

  suspend fun exportJsonBackup(): String =
    withContext(Dispatchers.IO) {
      val root = JSONObject()
      root.put("format", "nexus_command_backup")
      root.put("version", 1)
      root.put("exportedAtMillis", System.currentTimeMillis())

      val prefObj = JSONObject()
      prefObj.put("performanceMode", prefs.performanceModeFlow.first())
      prefObj.put("ttsEnabled", prefs.ttsEnabledFlow.first())
      prefObj.put("cloudAiEnabled", prefs.cloudAiEnabledFlow.first())
      prefObj.put("shareTelemetryWithAi", prefs.shareTelemetryWithAiFlow.first())
      prefObj.put("backgroundAlertsEnabled", prefs.backgroundAlertsEnabledFlow.first())
      prefObj.put("alertIntervalMinutes", prefs.alertIntervalMinutesFlow.first())
      root.put("preferences", prefObj)

      val customAutos = db.automationDao().getCustomOnce()
      val autosArray = JSONArray()
      customAutos.forEach { auto ->
        val obj = JSONObject()
        obj.put("name", auto.name)
        obj.put("voicePhrase", auto.voicePhrase)
        obj.put("description", auto.description)
        obj.put("stepsSerialized", auto.stepsSerialized)
        obj.put("scheduleIntervalHours", auto.scheduleIntervalHours)
        autosArray.put(obj)
      }
      root.put("customAutomations", autosArray)

      val history = db.cleanHistoryDao().getHistoryOnce()
      val histArray = JSONArray()
      history.take(20).forEach { h ->
        val obj = JSONObject()
        obj.put("timestampMillis", h.timestampMillis)
        obj.put("itemsDeleted", h.itemsDeleted)
        obj.put("bytesFreed", h.bytesFreed)
        obj.put("summary", h.summary)
        histArray.put(obj)
      }
      root.put("cleanHistorySummary", histArray)

      root.toString(2)
    }

  suspend fun restoreFromJson(rawJson: String): Result<BackupRestoreSummary> =
    withContext(Dispatchers.IO) {
      runCatching {
        val root = JSONObject(rawJson)
        require(root.optString("format") == "nexus_command_backup") {
          "פורמט קובץ הגיבוי אינו תואם ל-NEXUS."
        }
        val version = root.optInt("version", 0)
        require(version >= 1) { "גרסת גיבוי לא נתמכת." }

        var restoredPrefs = false
        root.optJSONObject("preferences")?.let { p ->
          prefs.restorePreferences(
            performanceMode = p.optBoolean("performanceMode", false),
            ttsEnabled = p.optBoolean("ttsEnabled", true),
            cloudAiEnabled = p.optBoolean("cloudAiEnabled", true),
            shareTelemetryWithAi = p.optBoolean("shareTelemetryWithAi", true),
            backgroundAlertsEnabled = p.optBoolean("backgroundAlertsEnabled", true),
            alertIntervalMinutes = p.optLong("alertIntervalMinutes", 30L)
          )
          restoredPrefs = true
        }

        val validStepNames = AutomationStepType.entries.map { it.name }.toSet()
        val existingNames = db.automationDao().getCustomOnce().map { it.name }.toHashSet()
        var restoredCount = 0

        val autosArray = root.optJSONArray("customAutomations") ?: JSONArray()
        for (i in 0 until autosArray.length()) {
          val obj = autosArray.optJSONObject(i) ?: continue
          val name = obj.optString("name").trim()
          val phrase = obj.optString("voicePhrase").trim()
          val rawSteps = obj.optString("stepsSerialized")
          val intervalHours = obj.optInt("scheduleIntervalHours", 0).coerceAtLeast(0)
          val filteredSteps =
            rawSteps.split(",").map { it.trim() }.filter { it in validStepNames }
          if (name.isNotBlank() && filteredSteps.isNotEmpty() && name !in existingNames) {
            val desc =
              filteredSteps.mapNotNull { token ->
                AutomationStepType.entries.firstOrNull { it.name == token }?.titleHe
              }.joinToString(" ← ")
            db.automationDao().insert(
              AutomationEntity(
                name = name,
                voicePhrase = phrase.ifBlank { name },
                description = desc,
                stepsSerialized = filteredSteps.joinToString(","),
                isBuiltIn = false,
                scheduleIntervalHours = intervalHours
              )
            )
            existingNames += name
            restoredCount++
          }
        }

        BackupRestoreSummary(
          restoredAutomationsCount = restoredCount,
          restoredPreferences = restoredPrefs
        )
      }
    }

  suspend fun clearAllUserData() =
    withContext(Dispatchers.IO) {
      db.assistantMessageDao().clearAll()
      db.actionAuditDao().clearAll()
      db.cleanHistoryDao().clearAll()
      db.telemetrySnapshotDao().clearAll()
      db.automationDao().deleteAllCustom()
      prefs.clearAll()
    }
}
