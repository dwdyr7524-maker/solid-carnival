package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "clean_history")
data class CleanHistoryEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val timestampMillis: Long,
  val itemsDeleted: Int,
  val itemsFailed: Int,
  val bytesFreed: Long,
  val freeBeforeBytes: Long,
  val freeAfterBytes: Long,
  val summary: String,
  val failureReason: String? = null
)

@Entity(tableName = "telemetry_snapshots")
data class TelemetrySnapshotEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val timestampMillis: Long,
  val batteryPercent: Int,
  val batteryTempC: Float,
  val batteryVoltageMv: Int,
  val ramUsedPercent: Int,
  val storageUsedPercent: Int,
  val storageFreeBytes: Long,
  val healthScore: Int
)

@Entity(tableName = "assistant_messages")
data class AssistantMessageEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val timestampMillis: Long,
  val isUser: Boolean,
  val text: String,
  val actionTag: String? = null
)

@Entity(tableName = "automations")
data class AutomationEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val name: String,
  val voicePhrase: String,
  val description: String,
  val stepsSerialized: String,
  val isBuiltIn: Boolean = false,
  val lastRunMillis: Long? = null,
  val scheduleIntervalHours: Int = 0
)

@Entity(tableName = "action_audit")
data class ActionAuditEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val timestampMillis: Long,
  val category: String,
  val actionTitle: String,
  val succeeded: Boolean,
  val details: String,
  val failureReason: String? = null
)
