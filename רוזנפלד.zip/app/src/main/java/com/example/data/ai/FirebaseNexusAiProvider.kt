package com.example.data.ai

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.data.local.AutomationEntity
import com.example.data.model.AppDiagnosticInfo
import com.example.data.model.AssistantActionType
import com.example.data.model.PendingAssistantAction
import com.example.data.model.SecurityAuditReport
import com.example.data.model.SystemTelemetry
import com.example.data.system.formatBytes
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.AudioTranscriptionConfig
import com.google.firebase.ai.type.LiveSession
import com.google.firebase.ai.type.PublicPreviewAPI
import com.google.firebase.ai.type.ResponseModality
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import com.google.firebase.ai.type.liveAudioConversationConfig
import com.google.firebase.ai.type.liveGenerationConfig
import java.util.Locale
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

private const val TAG = "FirebaseNexusAi"

@OptIn(PublicPreviewAPI::class)
class FirebaseNexusAiProvider(private val context: Context) : NexusAiProvider {

  override val providerId: String = "firebase_ai_logic"

  private val liveScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
  private var activeLiveSession: LiveSession? = null

  private val _liveVoiceState = MutableStateFlow<LiveVoiceUiState>(LiveVoiceUiState.Idle)
  override val liveVoiceState: StateFlow<LiveVoiceUiState> = _liveVoiceState.asStateFlow()

  private var turnCounter = 0L
  private val liveTurns = mutableListOf<VoiceTranscriptTurn>()
  private val currentUserBuffer = StringBuilder()
  private val currentModelBuffer = StringBuilder()

  // Lazy model initialization per firebase-ai-logic-android requirements
  private val transcribeModel by lazy {
    Firebase.ai.generativeModel(
      modelName = "gemini-3.5-transcribe",
      systemInstruction =
        content {
          text(
            "You are an accurate Hebrew and English speech-to-text transcriber for NEXUS AI on Android. " +
              "Output only the clean verbatim transcript of the audio in its spoken language, without quotes or extra commentary."
          )
        }
    )
  }

  private val reasoningSchema by lazy {
    Schema.obj(
      properties =
        mapOf(
          "replyText" to
            Schema.string(
              description =
                "Clear, concise, helpful answer in natural Hebrew explaining findings or guiding the user."
            ),
          "plannedSteps" to
            Schema.array(
              items = Schema.string(),
              description = "2 to 4 short actionable steps in Hebrew for executing or solving the request."
            ),
          "actionType" to
            Schema.enumeration(
              values = AssistantActionType.entries.map { it.name },
              description =
                "Optional mapped app action from AssistantActionType, or NONE if purely informational."
            ),
          "actionTitle" to
            Schema.string(description = "Short Hebrew button/confirmation title if actionType != NONE."),
          "actionDescription" to
            Schema.string(description = "Short Hebrew description of what the action opens or runs."),
          "requiresConfirmation" to
            Schema.boolean(
              description =
                "True if launching system settings, cleaning storage, or running automations; false for safe navigation/checks."
            )
        ),
      optionalProperties = listOf("actionTitle", "actionDescription")
    )
  }

  private val reasoningModel by lazy {
    Firebase.ai.generativeModel(
      modelName = "gemini-3.8-flash",
      generationConfig =
        generationConfig {
          responseMimeType = "application/json"
          responseSchema = reasoningSchema
          temperature = 0.25f
        },
      systemInstruction =
        content {
          text(
            """
            אתה NEXUS AI — המוח החכם של מרכז השליטה, האבחון והתחזוקה של טאבלט Android 10 (Samsung Galaxy Tab Active Pro).
            כללי עבודה מחייבים:
            1. ענה תמיד בעברית טבעית, ברורה, תמציתית ומקצועית.
            2. הסתמך אך ורק על נתוני המכשיר האמיתיים המצורפים להקשר; לעולם אל תמציא נתונים ואל תטען שביצעת פעולה ללא אישור המשתמש.
            3. עבור בקשות מורכבות, פרק את הפתרון לשלבים ברורים ב-plannedSteps.
            4. לפני כל פעולה רגישה (ניקוי מערכת, פתיחת הגדרות, הפעלת אוטומציה), הגדר actionType מתאים ו-requiresConfirmation = true.
            5. החזר אך ורק JSON התואם לסכמה.
            """.trimIndent()
          )
        }
    )
  }

  private val healthPingModel by lazy {
    Firebase.ai.generativeModel(
      modelName = "gemini-3.5-flash-lite",
      generationConfig = generationConfig { maxOutputTokens = 16; temperature = 0f }
    )
  }

  override suspend fun generateAssistantResponse(
    userInput: String,
    recentHistory: List<Pair<Boolean, String>>,
    telemetry: SystemTelemetry?,
    apps: List<AppDiagnosticInfo>,
    securityReport: SecurityAuditReport?,
    customAutomations: List<AutomationEntity>,
    allowDeviceContextSharing: Boolean
  ): Result<AiAgentReply> =
    withContext(Dispatchers.IO) {
      try {
        val contextSummary =
          if (allowDeviceContextSharing && telemetry != null) {
            buildDeviceContextBlock(telemetry, apps, securityReport, customAutomations)
          } else {
            "שיתוף נתוני המכשיר עם הענן כבוי לפי הגדרת הפרטיות של המשתמש. ענה באופן כללי ובטיחותי."
          }

        val historyText =
          recentHistory
            .takeLast(6)
            .joinToString("\n") { (isUser, text) ->
              "${if (isUser) "משתמש" else "NEXUS"}: $text"
            }

        val prompt =
          """
          $contextSummary

          היסטוריית שיחה אחרונה:
          ${historyText.ifBlank { "שיחה חדשה" }}

          בקשת המשתמש הנוכחית:
          "$userInput"
          """.trimIndent()

        val response =
          withTimeout(45_000L) {
            reasoningModel.generateContent(prompt)
          }

        val jsonText =
          response.text?.takeIf { it.isNotBlank() }
            ?: return@withContext Result.failure(IllegalStateException("Model returned an empty response."))

        val json = JSONObject(jsonText)
        val replyText = json.optString("replyText").trim()
        if (replyText.isBlank()) {
          return@withContext Result.failure(IllegalStateException("Model returned an empty replyText."))
        }

        val stepsArr = json.optJSONArray("plannedSteps")
        val plannedSteps =
          if (stepsArr != null) {
            (0 until stepsArr.length())
              .mapNotNull { idx -> stepsArr.optString(idx).trim().takeIf { it.isNotEmpty() } }
          } else {
            emptyList()
          }

        val actionName = json.optString("actionType", AssistantActionType.NONE.name)
        val mappedAction =
          AssistantActionType.entries.firstOrNull { it.name == actionName }
            ?: AssistantActionType.NONE

        val pendingAction =
          if (mappedAction != AssistantActionType.NONE) {
            val sensitiveAction =
              mappedAction == AssistantActionType.REQUEST_START_CLEAN ||
                mappedAction == AssistantActionType.OPEN_BATTERY_SETTINGS ||
                mappedAction == AssistantActionType.OPEN_INTERNET_SETTINGS ||
                mappedAction == AssistantActionType.OPEN_STORAGE_SETTINGS ||
                mappedAction == AssistantActionType.RUN_AUTOMATION
            val title =
              json.optString("actionTitle").trim().ifBlank { "הצעת פעולה: ${mappedAction.name}" }
            val desc =
              json.optString("actionDescription").trim().ifBlank { "אשר מעבר או ביצוע במערכת NEXUS." }
            PendingAssistantAction(
              actionType = mappedAction,
              title = title,
              description = desc,
              requiresConfirmation = json.optBoolean("requiresConfirmation", sensitiveAction) || sensitiveAction,
              automationId =
                if (mappedAction == AssistantActionType.RUN_AUTOMATION) {
                  customAutomations.firstOrNull {
                    userInput.contains(it.name, ignoreCase = true) ||
                      userInput.contains(it.voicePhrase, ignoreCase = true)
                  }?.id
                } else null
            )
          } else null

        Result.success(
          AiAgentReply(
            replyText = replyText,
            actionTag = "GEMINI_3_8_FLASH_${mappedAction.name}",
            plannedSteps = plannedSteps,
            pendingAction = pendingAction,
            providerName = "Firebase AI Logic • gemini-3.8-flash",
            isCloudEnhanced = true
          )
        )
      } catch (e: TimeoutCancellationException) {
        Log.e(TAG, "Assistant reasoning timed out", e)
        Result.failure(e)
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        Log.e(TAG, "Assistant reasoning failed", e)
        Result.failure(e)
      }
    }

  override suspend fun analyzeDiagnosticImage(
    bitmap: Bitmap,
    userQuestion: String,
    telemetry: SystemTelemetry?,
    allowDeviceContextSharing: Boolean
  ): Result<AiAgentReply> =
    withContext(Dispatchers.IO) {
      val scaled = scaleBitmapSafely(bitmap, maxDim = 1280)
      try {
        val contextSummary =
          if (allowDeviceContextSharing && telemetry != null) {
            buildDeviceContextBlock(telemetry, emptyList(), null, emptyList())
          } else {
            "שיתוף מדדי מכשיר מושבת. התמקד אך ורק בניתוח התמונה שצורפה."
          }

        val question =
          userQuestion.trim().ifBlank {
            "נתח את צילום המסך או התמונה המצורפת. זהה שגיאות, בעיות אחסון/סוללה/הרשאות ותן צעדי פתרון בעברית."
          }

        val response =
          withTimeout(60_000L) {
            reasoningModel.generateContent(
              content {
                image(scaled)
                text(
                  """
                  $contextSummary

                  בקשת האבחון הוויזואלי של המשתמש:
                  "$question"

                  החזר תשובה מדויקת בעברית בהתאם לסכמת ה-JSON, כולל שלבי פעולה ו-actionType מומלץ אם רלוונטי.
                  """.trimIndent()
                )
              }
            )
          }

        val jsonText =
          response.text?.takeIf { it.isNotBlank() }
            ?: return@withContext Result.failure(IllegalStateException("Model returned an empty visual response."))

        val json = JSONObject(jsonText)
        val replyText = json.optString("replyText").trim()
        if (replyText.isBlank()) {
          return@withContext Result.failure(IllegalStateException("Model returned an empty replyText."))
        }

        val stepsArr = json.optJSONArray("plannedSteps")
        val plannedSteps =
          if (stepsArr != null) {
            (0 until stepsArr.length())
              .mapNotNull { idx -> stepsArr.optString(idx).trim().takeIf { it.isNotEmpty() } }
          } else {
            emptyList()
          }

        val actionName = json.optString("actionType", AssistantActionType.NONE.name)
        val mappedAction =
          AssistantActionType.entries.firstOrNull { it.name == actionName }
            ?: AssistantActionType.NONE

        val pendingAction =
          if (mappedAction != AssistantActionType.NONE) {
            val sensitiveAction =
              mappedAction == AssistantActionType.REQUEST_START_CLEAN ||
                mappedAction == AssistantActionType.OPEN_BATTERY_SETTINGS ||
                mappedAction == AssistantActionType.OPEN_INTERNET_SETTINGS ||
                mappedAction == AssistantActionType.OPEN_STORAGE_SETTINGS ||
                mappedAction == AssistantActionType.RUN_AUTOMATION
            PendingAssistantAction(
              actionType = mappedAction,
              title = json.optString("actionTitle").trim().ifBlank { "פעולה מומלצת מהאבחון" },
              description =
                json.optString("actionDescription").trim().ifBlank { "מעבר למסך או לפעולה הרלוונטית." },
              requiresConfirmation = json.optBoolean("requiresConfirmation", sensitiveAction) || sensitiveAction
            )
          } else null

        Result.success(
          AiAgentReply(
            replyText = replyText,
            actionTag = "GEMINI_VISION_${mappedAction.name}",
            plannedSteps = plannedSteps,
            pendingAction = pendingAction,
            providerName = "Firebase AI Logic • gemini-3.8-flash (Vision)",
            isCloudEnhanced = true
          )
        )
      } catch (e: TimeoutCancellationException) {
        Log.e(TAG, "Visual diagnostics timed out", e)
        Result.failure(e)
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        Log.e(TAG, "Visual diagnostics failed", e)
        Result.failure(e)
      } finally {
        if (scaled !== bitmap) {
          scaled.recycle()
        }
      }
    }

  override suspend fun runCloudHealthCheck(): CloudHealthCheckState =
    withContext(Dispatchers.IO) {
      val startedAt = System.currentTimeMillis()
      try {
        val response =
          withTimeout(18_000L) {
            healthPingModel.generateContent("Reply with OK")
          }
        val latency = (System.currentTimeMillis() - startedAt).coerceAtLeast(1L)
        val text = response.text?.trim().orEmpty()
        if (text.isBlank()) {
          CloudHealthCheckState.Unhealthy(
            error = NexusAiErrorMapper.toHebrewError("health_check", IllegalStateException("Empty response")),
            latencyMs = latency,
            checkedAtMillis = System.currentTimeMillis()
          )
        } else {
          CloudHealthCheckState.Healthy(
            latencyMs = latency,
            modelChecked = "gemini-3.5-flash-lite + App Check",
            summaryHe = "החיבור לשרתי Firebase AI Logic ואימות App Check תקינים (${latency} מ״ש).",
            checkedAtMillis = System.currentTimeMillis()
          )
        }
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        val latency = (System.currentTimeMillis() - startedAt).coerceAtLeast(1L)
        Log.e(TAG, "Cloud AI health check failed", e)
        CloudHealthCheckState.Unhealthy(
          error = NexusAiErrorMapper.toHebrewError("health_check", e),
          latencyMs = latency,
          checkedAtMillis = System.currentTimeMillis()
        )
      }
    }

  private fun scaleBitmapSafely(source: Bitmap, maxDim: Int): Bitmap {
    val w = source.width
    val h = source.height
    if (w <= maxDim && h <= maxDim) return source
    val scale = maxDim.toFloat() / maxOf(w, h).toFloat()
    val targetW = (w * scale).toInt().coerceAtLeast(1)
    val targetH = (h * scale).toInt().coerceAtLeast(1)
    return Bitmap.createScaledBitmap(source, targetW, targetH, true)
  }

  override suspend fun transcribeAudio(
    audioBytes: ByteArray,
    mimeType: String,
    languageHint: String
  ): Result<String> =
    withContext(Dispatchers.IO) {
      if (audioBytes.size <= 44) {
        return@withContext Result.failure(IllegalArgumentException("ההקלטה ריקה או קצרה מדי."))
      }
      if (audioBytes.size > 19 * 1024 * 1024) {
        return@withContext Result.failure(IllegalArgumentException("קובץ השמע חורג ממגבלת 20MB."))
      }
      try {
        val response =
          withTimeout(60_000L) {
            transcribeModel.generateContent(
              content {
                inlineData(audioBytes, mimeType)
                text(
                  "Transcribe this audio accurately in Hebrew ($languageHint) or any spoken language. Return only the transcribed text."
                )
              }
            )
          }
        val transcript = response.text?.trim().orEmpty()
        if (transcript.isBlank()) {
          Result.failure(IllegalStateException("Model returned an empty transcript."))
        } else {
          Result.success(transcript)
        }
      } catch (e: TimeoutCancellationException) {
        Log.e(TAG, "Audio transcription timed out", e)
        Result.failure(e)
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        Log.e(TAG, "Audio transcription failed", e)
        Result.failure(e)
      }
    }

  @SuppressLint("MissingPermission")
  override suspend fun startLiveVoiceConversation(
    telemetry: SystemTelemetry?,
    apps: List<AppDiagnosticInfo>,
    securityReport: SecurityAuditReport?,
    allowDeviceContextSharing: Boolean
  ): Result<Unit> =
    withContext(Dispatchers.IO) {
      if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) !=
        PackageManager.PERMISSION_GRANTED
      ) {
        val err = SecurityException("נדרשת הרשאת מיקרופון (RECORD_AUDIO) לשיחה קולית חיה.")
        _liveVoiceState.value =
          LiveVoiceUiState.Error(NexusAiErrorMapper.toHebrewError("gemini-3.8-live", err))
        return@withContext Result.failure(err)
      }

      stopLiveVoiceConversation()
      _liveVoiceState.value = LiveVoiceUiState.Connecting
      liveTurns.clear()
      currentUserBuffer.clear()
      currentModelBuffer.clear()

      try {
        val contextInfo =
          if (allowDeviceContextSharing && telemetry != null) {
            buildDeviceContextBlock(telemetry, apps, securityReport, emptyList())
          } else {
            "שיתוף מדדי המכשיר מושבת לפי הגדרת פרטיות. סייע בעברית באופן כללי."
          }

        val liveModel =
          Firebase.ai.liveModel(
            modelName = "gemini-3.8-live",
            generationConfig =
              liveGenerationConfig {
                responseModality = ResponseModality.AUDIO
                inputAudioTranscription = AudioTranscriptionConfig()
                outputAudioTranscription = AudioTranscriptionConfig()
              },
            systemInstruction =
              content {
                text(
                  """
                  אתה העוזר הקולי של NEXUS AI — מרכז שליטה, תחזוקה ואבחון של טאבלט Samsung Galaxy Tab Active Pro (Android 10).
                  דבר בעברית טבעית, ברורה וקצרה שמתאימה לשיחה קולית חיה.
                  לעולם אל תמציא פעולות שבוצעו ואל תטען שביצעת מחיקה או שינוי הגדרות ללא אישור המשתמש במסך.
                  נתוני המכשיר העדכניים:
                  $contextInfo
                  """.trimIndent()
                )
              }
          )

        val session =
          withTimeout(30_000L) {
            liveModel.connect()
          }
        activeLiveSession = session

        val config =
          liveAudioConversationConfig {
            enableInterruptions = true
            transcriptHandler = { inputTranscription, outputTranscription ->
              val userText = inputTranscription?.text.orEmpty()
              val modelText = outputTranscription?.text.orEmpty()

              if (userText.isNotEmpty()) {
                if (currentModelBuffer.isNotEmpty()) {
                  flushTurn(isUser = false, buffer = currentModelBuffer)
                }
                currentUserBuffer.append(userText)
              }
              if (modelText.isNotEmpty()) {
                if (currentUserBuffer.isNotEmpty()) {
                  flushTurn(isUser = true, buffer = currentUserBuffer)
                }
                currentModelBuffer.append(modelText)
              }

              _liveVoiceState.value =
                LiveVoiceUiState.Active(
                  isSpeaking = modelText.isNotEmpty(),
                  isMuted = false,
                  userPartialTranscript = currentUserBuffer.toString(),
                  modelPartialTranscript = currentModelBuffer.toString(),
                  turns = liveTurns.toList()
                )
            }
            goAwayHandler = { _ ->
              liveScope.launch {
                stopLiveVoiceConversation()
                _liveVoiceState.value =
                  LiveVoiceUiState.Error(
                    NexusAppError(
                      source = "gemini-3.8-live",
                      messageHe = "החיבור הקולי נסגר על ידי השרת לאחר זמן שיחה ממושך. ניתן להתחיל שיחה חדשה.",
                      canRetry = true
                    )
                  )
              }
            }
          }

        _liveVoiceState.value =
          LiveVoiceUiState.Active(
            isSpeaking = false,
            isMuted = false,
            userPartialTranscript = "",
            modelPartialTranscript = "",
            turns = emptyList()
          )

        liveScope.launch {
          try {
            session.startAudioConversation(config)
          } catch (e: CancellationException) {
            throw e
          } catch (e: Exception) {
            Log.e(TAG, "Live audio conversation loop error", e)
            _liveVoiceState.value =
              LiveVoiceUiState.Error(NexusAiErrorMapper.toHebrewError("gemini-3.8-live", e))
          }
        }

        Result.success(Unit)
      } catch (e: TimeoutCancellationException) {
        Log.e(TAG, "Live connection timed out", e)
        _liveVoiceState.value =
          LiveVoiceUiState.Error(NexusAiErrorMapper.toHebrewError("gemini-3.8-live", e))
        Result.failure(e)
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        Log.e(TAG, "Failed to start Live Voice session", e)
        _liveVoiceState.value =
          LiveVoiceUiState.Error(NexusAiErrorMapper.toHebrewError("gemini-3.8-live", e))
        Result.failure(e)
      }
    }

  override suspend fun sendTextToLiveSession(text: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      val session = activeLiveSession
      if (session == null || session.isClosed()) {
        return@withContext Result.failure(IllegalStateException("אין שיחה קולית חיה פעילה כרגע."))
      }
      try {
        session.send(text)
        liveTurns += VoiceTranscriptTurn(id = ++turnCounter, isUser = true, text = text)
        _liveVoiceState.value =
          LiveVoiceUiState.Active(
            isSpeaking = false,
            isMuted = false,
            userPartialTranscript = "",
            modelPartialTranscript = currentModelBuffer.toString(),
            turns = liveTurns.toList()
          )
        Result.success(Unit)
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        Log.e(TAG, "Failed sending text to live session", e)
        Result.failure(e)
      }
    }

  override suspend fun stopLiveVoiceConversation() {
    withContext(Dispatchers.IO) {
      val session = activeLiveSession
      activeLiveSession = null
      if (session != null) {
        runCatching { session.stopAudioConversation() }
        runCatching { session.close() }
      }
      if (currentUserBuffer.isNotEmpty()) {
        flushTurn(isUser = true, buffer = currentUserBuffer)
      }
      if (currentModelBuffer.isNotEmpty()) {
        flushTurn(isUser = false, buffer = currentModelBuffer)
      }
      _liveVoiceState.value = LiveVoiceUiState.Idle
    }
  }

  fun shutdown() {
    val session = activeLiveSession
    activeLiveSession = null
    if (session != null) {
      runCatching { session.stopAudioConversation() }
    }
    kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
      runCatching { session?.close() }
    }
    liveScope.cancel()
  }

  private fun flushTurn(isUser: Boolean, buffer: StringBuilder) {
    val text = buffer.toString().trim()
    buffer.clear()
    if (text.isNotEmpty()) {
      liveTurns += VoiceTranscriptTurn(id = ++turnCounter, isUser = isUser, text = text)
      if (liveTurns.size > 40) {
        liveTurns.removeAt(0)
      }
    }
  }

  private fun buildDeviceContextBlock(
    telemetry: SystemTelemetry,
    apps: List<AppDiagnosticInfo>,
    securityReport: SecurityAuditReport?,
    customAutomations: List<AutomationEntity>
  ): String {
    val topApps =
      apps.sortedByDescending { it.totalSizeBytes }.take(5).joinToString(", ") {
        "${it.appName} (${formatBytes(it.totalSizeBytes)})"
      }
    val autoNames = customAutomations.joinToString(", ") { "${it.name} [${it.voicePhrase}]" }
    val issues = telemetry.issues.joinToString("; ") { it.title }
    return """
      מכשיר: ${telemetry.device.manufacturer} ${telemetry.device.model} (Android ${telemetry.device.androidRelease})
      ציון בריאות: ${telemetry.healthScore}% (${telemetry.healthStatusLabel})
      סוללה: ${telemetry.battery.levelPercent}% (${telemetry.battery.chargeSource}, ${String.format(Locale.US, "%.1f", telemetry.battery.temperatureC)}°C)
      אחסון פנוי: ${formatBytes(telemetry.storage.freeBytes)} מתוך ${formatBytes(telemetry.storage.totalBytes)} (${telemetry.storage.usedPercent}% בשימוש)
      זיכרון RAM: פנוי ${formatBytes(telemetry.ram.availableBytes)} מתוך ${formatBytes(telemetry.ram.totalBytes)} (${telemetry.ram.usedPercent}% בשימוש)
      רשת: ${telemetry.network.transportLabel} (מחובר: ${telemetry.network.isConnected})
      אפליקציות כבדות מובילות: ${topApps.ifBlank { "נטען" }}
      אבטחה: מצלמה=${securityReport?.cameraAppsCount ?: 0}, מיקרופון=${securityReport?.micAppsCount ?: 0}, מיקום=${securityReport?.locationAppsCount ?: 0}
      התראות מערכת: ${issues.ifBlank { "אין" }}
      אוטומציות זמינות: ${autoNames.ifBlank { "מובנות בלבד" }}
    """.trimIndent()
  }
}
