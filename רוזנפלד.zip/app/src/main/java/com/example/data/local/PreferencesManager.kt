package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.nexusDataStore: DataStore<Preferences> by
  preferencesDataStore(name = "nexus_preferences")

class PreferencesManager(private val context: Context) {

  private object Keys {
    val PERFORMANCE_MODE = booleanPreferencesKey("performance_mode")
    val TTS_ENABLED = booleanPreferencesKey("tts_enabled")
    val CLOUD_AI_ENABLED = booleanPreferencesKey("cloud_ai_enabled")
    val SHARE_TELEMETRY_WITH_AI = booleanPreferencesKey("share_telemetry_with_ai")
    val BACKGROUND_ALERTS_ENABLED = booleanPreferencesKey("background_alerts_enabled")
    val ALERT_INTERVAL_MINUTES = longPreferencesKey("alert_interval_minutes")
    val LAST_THERMAL_ALERT_MILLIS = longPreferencesKey("last_thermal_alert_millis")
    val SAF_TREE_URIS = stringSetPreferencesKey("saf_tree_uris")
    val LAST_MAINTENANCE_MILLIS = longPreferencesKey("last_maintenance_millis")
  }

  val performanceModeFlow: Flow<Boolean> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.PERFORMANCE_MODE] ?: false }

  val ttsEnabledFlow: Flow<Boolean> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.TTS_ENABLED] ?: true }

  val cloudAiEnabledFlow: Flow<Boolean> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.CLOUD_AI_ENABLED] ?: true }

  val shareTelemetryWithAiFlow: Flow<Boolean> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.SHARE_TELEMETRY_WITH_AI] ?: true }

  val backgroundAlertsEnabledFlow: Flow<Boolean> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.BACKGROUND_ALERTS_ENABLED] ?: true }

  val alertIntervalMinutesFlow: Flow<Long> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.ALERT_INTERVAL_MINUTES] ?: 30L }

  val lastThermalAlertMillisFlow: Flow<Long> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.LAST_THERMAL_ALERT_MILLIS] ?: 0L }

  val safTreeUrisFlow: Flow<Set<String>> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.SAF_TREE_URIS] ?: emptySet() }

  val lastMaintenanceMillisFlow: Flow<Long?> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.LAST_MAINTENANCE_MILLIS] }

  suspend fun setPerformanceMode(enabled: Boolean) {
    context.nexusDataStore.edit { it[Keys.PERFORMANCE_MODE] = enabled }
  }

  suspend fun setTtsEnabled(enabled: Boolean) {
    context.nexusDataStore.edit { it[Keys.TTS_ENABLED] = enabled }
  }

  suspend fun setCloudAiEnabled(enabled: Boolean) {
    context.nexusDataStore.edit { it[Keys.CLOUD_AI_ENABLED] = enabled }
  }

  suspend fun setShareTelemetryWithAi(enabled: Boolean) {
    context.nexusDataStore.edit { it[Keys.SHARE_TELEMETRY_WITH_AI] = enabled }
  }

  suspend fun setBackgroundAlertsEnabled(enabled: Boolean) {
    context.nexusDataStore.edit { it[Keys.BACKGROUND_ALERTS_ENABLED] = enabled }
  }

  suspend fun setAlertIntervalMinutes(minutes: Long) {
    context.nexusDataStore.edit { it[Keys.ALERT_INTERVAL_MINUTES] = minutes.coerceAtLeast(15L) }
  }

  suspend fun updateLastThermalAlertMillis(millis: Long) {
    context.nexusDataStore.edit { it[Keys.LAST_THERMAL_ALERT_MILLIS] = millis }
  }

  suspend fun addSafTreeUri(uriString: String) {
    context.nexusDataStore.edit { prefs ->
      val current = prefs[Keys.SAF_TREE_URIS] ?: emptySet()
      prefs[Keys.SAF_TREE_URIS] = current + uriString
    }
  }

  suspend fun removeSafTreeUri(uriString: String) {
    context.nexusDataStore.edit { prefs ->
      val current = prefs[Keys.SAF_TREE_URIS] ?: emptySet()
      prefs[Keys.SAF_TREE_URIS] = current - uriString
    }
  }

  suspend fun updateLastMaintenanceMillis(millis: Long) {
    context.nexusDataStore.edit { it[Keys.LAST_MAINTENANCE_MILLIS] = millis }
  }

  suspend fun restorePreferences(
    performanceMode: Boolean,
    ttsEnabled: Boolean,
    cloudAiEnabled: Boolean,
    shareTelemetryWithAi: Boolean,
    backgroundAlertsEnabled: Boolean = true,
    alertIntervalMinutes: Long = 30L
  ) {
    context.nexusDataStore.edit { prefs ->
      prefs[Keys.PERFORMANCE_MODE] = performanceMode
      prefs[Keys.TTS_ENABLED] = ttsEnabled
      prefs[Keys.CLOUD_AI_ENABLED] = cloudAiEnabled
      prefs[Keys.SHARE_TELEMETRY_WITH_AI] = shareTelemetryWithAi
      prefs[Keys.BACKGROUND_ALERTS_ENABLED] = backgroundAlertsEnabled
      prefs[Keys.ALERT_INTERVAL_MINUTES] = alertIntervalMinutes.coerceAtLeast(15L)
    }
  }

  suspend fun clearAll() {
    context.nexusDataStore.edit { it.clear() }
  }
}
